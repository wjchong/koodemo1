<?php 
  if (!defined('BASEPATH')) exit('No direct script access allowed');
  define("SITE_URL",'http://socialryde.cc/SocialRyde/');

  class Webservice extends CI_Controller{

    public function __construct(){
      parent:: __construct();
      $this->load->model('webservice_model');
      $this->load->library(['form_validation','email']);                        
    }

    public function index(){
      //$this->load->view('home');
    }

    /************* login function *************/


    public function login(){


               	$email = $this->input->get_post('email', TRUE);
		$password = md5($this->input->get_post('password', TRUE));
                $register_id = $this->input->get_post('register_id');

      $arr_get = ['email' => $email,'password' => $password];
		

     

      $login = $this->webservice_model->get_where('users',$arr_get);
      if ($login) {


                       if($login[0]['status'] == 'active'){


                                 $arr_da = ['register_id' => ''];
                                 $arr_da1 = ['register_id' => $register_id];

                                 $arr_chk = "register_id = '".$register_id."'";

				 $this->webservice_model->update_data('users',$arr_da,$arr_chk);
                                 $this->webservice_model->update_data('users',$arr_da1,$arr_get);
                               $login3 = $this->webservice_model->get_where('users',$arr_get);
                               $login3[0]['image']=SITE_URL.'uploads/images/'.$login3[0]['image'];
                               $login3[0]['vari_image']=SITE_URL.'uploads/images/'.$login3[0]['vari_image'];
                               $ressult['result']=$login3[0];
                               $ressult['message']='successfull';
                               $ressult['status']='1';
                               $json = $ressult;
      
                          }else{
                                $ressult['result']='Your account is not verify';
                                $ressult['message']='unsuccessfull';
                                $ressult['status']='0';
                                $json = $ressult; 



                                 }
                 }else{
                                $ressult['result']='Your have entered wrong email & password';
                                $ressult['message']='unsuccessfull';
                                $ressult['status']='0';
                                $json = $ressult;       
      }

      header('Content-type:application/json');
      echo json_encode($json);
    }


  

    /************* signup function *************/

    public function signup(){

         $arr_data = [
            'name'=>$this->input->get_post('name'),
            'email'=>$this->input->get_post('email'),
            'address'=>$this->input->get_post('address'),
            'phone'=>$this->input->get_post('phone'),
            'city_id'=>$this->input->get_post('city_id'),
            'password'=>md5($this->input->get_post('password')),
            'about'=>$this->input->get_post('about'),
            'privacy'=>$this->input->get_post('privacy'),
            'register_id'=>$this->input->get_post('register_id'),
            'ios_register_id'=>$this->input->get_post('ios_register_id')          
            ];


      $arr_get = ['email' => $arr_data['email']];

      $login = $this->webservice_model->get_where('users',$arr_get);
      if ($login) {
        
        $ressult['result']='Email already exist';
        $ressult['message']='unsuccessfull';
        $ressult['status']='0';
        $json = $ressult;
                               
        header('Content-type:application/json');
        echo json_encode($json);
        die;
      }     

      
            if (isset($_FILES['vari_image']))
      {
               $n = rand(0, 100000);
               $img = "VARI_IMG_" . $n . '.png';
               move_uploaded_file($_FILES['vari_image']['tmp_name'], "uploads/images/" . $img);
               $arr_data['vari_image'] = $img;        


      }



                        if (isset($_FILES['image']))
      {
               $n = rand(0, 100000);
               $img = "USER_IMG_" . $n . '.png';
               move_uploaded_file($_FILES['image']['tmp_name'], "uploads/images/" . $img);
               $arr_data['image'] = $img;        
      }


      $id = $this->webservice_model->insert_data('users',$arr_data);

      if ($id=="") {
        $json = ['result'=>'unsuccessfull','status'=>0,'message'=>'data not found'];
      }else{
           //$link = 'http://mobileappdevelop.co/SocialRyde/webservice/verify_email?user_id='.$id;     
    /*    
     $to = $arr_data['email'];
        $subject = "Social Ryde | Verify your account";
        $body = "<div style='max-width: 600px; width: 100%; margin-left: auto; margin-right: auto;'>
        <header style='color: #fff; width: 100%;'>
           <img alt='' src='".SITE_URL."uploads/images/logo.png' width ='120' height='120'/>
        </header>
        
        <div style='margin-top: 10px; padding-right: 10px; 
      padding-left: 125px;
      padding-bottom: 20px;'>
          <hr>
          <h3 style='color: #232F3F;'>Hi, ".$arr_data['email'].",</h3>
          <p>Welcome to Social Ryde please verify your account.</p>
          <a href='http://mobileappdevelop.co/SocialRyde/webservice/verify_email?user_id=$id'> click url to verify your account </a>
          <hr>
          
            <p>Warm Regards<br>Social Ryde <br>Support Team</p>
            
          </div>
        </div>

    </div>";


        $headers = "From: info@mobileappdevelop.co" . "\r\n";
        $headers.= "MIME-Version: 1.0" . "\r\n";
        $headers.= "Content-type:text/html;charset=UTF-8" . "\r\n";


           file_get_contents("http://technorizen.co.in/mail.php?to=".urlencode($to)."&subject=".urlencode($subject)."&body=".urlencode($body)."&headers=".urlencode($headers));
*/
         
              
        $arr_gets = ['id'=>$id];
        $login = $this->webservice_model->get_where('users',$arr_gets);       
        $login[0]['image']=SITE_URL.'uploads/images/'.$login[0]['image'];     
        $login[0]['vari_image']=SITE_URL.'uploads/images/'.$login[0]['vari_image'];
        $ressult['result']=$login[0];
        $ressult['message']='successfull';
        $ressult['status']='1';
        $json = $ressult;
      }

      header('Content-type:application/json');
      echo json_encode($json);

    }

   
/************* verify_email function *************/

    public function verify_email(){

      $arr_get = ['id'=>$this->input->get_post('user_id')];

      $login = $this->webservice_model->get_where('users',$arr_get);
      if ($login[0]['id'] == "")
      {
                          $ressult['result']='Data Not Found';
                          $ressult['message']='unsuccessfull';
                          $ressult['status']='0';
                          $json = $ressult;

                              //  header('Content-type:application/json');
                              //  echo json_encode($json);
                              //  die;
      }



       $arr_data = [
            
            'status'=>'active'
            ];

                     

      $res = $this->webservice_model->update_data('users',$arr_data,$arr_get);
      if ($res)
      {
       $this->load->view('admin/verify_email');
        $data = $this->webservice_model->get_where('users',$arr_get);
      
        $ressult['result']='your account verify successfully';
        $ressult['message']='successfull';
        $ressult['status']='1';
        $json = $ressult;
      }
      else
      {
                          $ressult['result']='Data Not Found';
                          $ressult['message']='unsuccessfull';
                          $ressult['status']='0';
                          $json = $ressult;
      }

    //  header('Content-type: application/json');
    //  echo json_encode($json);

                          

    }


    /************* forgot_password function *************/

    public function forgot_password()
    {
      $email = $this->input->get_post('email', TRUE);
      $arr_login = ['email' => $email];

      $login = $this->webservice_model->get_where('users', $arr_login);
      if ($login)
      {
        $pass = random_string('alnum', 6);

        $to = $email;
        $subject = "Forgot Password";
        $body = "<div style='max-width: 600px; width: 100%; margin-left: auto; margin-right: auto;'>
        <header style='color: #fff; width: 100%;'>
           <img alt='' src='".SITE_URL."uploads/images/logo.png' width ='120' height='120'/>
        </header>
        
        <div style='margin-top: 10px; padding-right: 10px; 
      padding-left: 125px;
      padding-bottom: 20px;'>
          <hr>
          <h3 style='color: #232F3F;'>Hello ".$login[0]['name'].",</h3>
          <p>You have requested a new password for your Social Ryde account.</p>
          <p>Your new password is <span style='background:#2196F3;color:white;padding:0px 5px'>".$pass."</span></p>
          <hr>
          
            <p>Warm Regards<br>Social Ryde<br>Support Team</p>
            
          </div>
        </div>

    </div>";

        $headers = "From: info@mobileappdevelop.co" . "\r\n";
        $headers.= "MIME-Version: 1.0" . "\r\n";
        $headers.= "Content-type:text/html;charset=UTF-8" . "\r\n";

           file_get_contents("http://socialryde.cc/SocialRyde/phpmailer/mail.php?to=".urlencode($to)."&subject=".urlencode($subject)."&body=".urlencode($body)."&headers=".urlencode($headers));
        //mail($to, $subject, $body, $headers);

          $ressult['result']="Forgot password successfuly";
          $ressult['message']='successfull';
          $ressult['status']='1';
          $json = $ressult;

          $this->webservice_model->update_data('users',['password'=>($pass)],$arr_login);
        
      }
      else
      {
          $ressult['result']='Email not exist';
          $ressult['message']='unsuccessfull';
          $ressult['status']='0';
          $json = $ressult;

      }

      header('Content-type: application/json');
      echo json_encode($json);
    }



    /************* change_password function *************/
    public function change_password()
    {
      $password = md5($this->input->get_post('old_password', TRUE));
      $id = $this->input->get_post('user_id', TRUE);

      $arr_login = ['id' => $id ,'password' => $password];
      $login = $this->webservice_model->get_where('users', $arr_login);

      $arr_data = ['password'=>md5($this->input->get_post('password'))];
      
      
      if ($login)
      {     
          $this->webservice_model->update_data('users',$arr_data,$arr_login);
      
          $ressult['result']="Change password successfuly";
          $ressult['message']='successfull';
          $ressult['status']='1';
          $json = $ressult;

        
      }
      else
      {
          $ressult['result']="Data not found";
          $ressult['message']='unsuccessfull';
          $ressult['status']='0';
          $json = $ressult;
      }

      header('Content-type: application/json');
      echo json_encode($json);
    }


               
     /************* social_login function *************/

     public function social_login(){

      
         $arr_data = [
            'name'=>$this->input->get_post('name'),
            'email'=>$this->input->get_post('email'),
            'social_id'=>$this->input->get_post('social_id'),
            'register_id'=>$this->input->get_post('register_id'),
            'ios_register_id'=>$this->input->get_post('ios_register_id')          
            ];

      $image = $this->input->get_post('image');

      if($image!=""){
         $img = "USER_IMG_" . rand(1, 10000) . ".png";
         @file_put_contents('uploads/images/'.$img, file_get_contents($image));
         $arr_data['image'] = $img;

      }

      $arr_get = ['social_id'=>$arr_data['social_id']];

      $login = $this->webservice_model->get_where('users',$arr_get);

      if ($login) {  
     
        $this->webservice_model->update_data('users',$arr_data,$arr_get);
        $data = $this->webservice_model->get_where('users',$arr_get);
        $data[0]['image']=SITE_URL.'uploads/images/'.$data[0]['image'];
       
          $ressult['result']=$data[0];
          $ressult['message']='successfull';
          $ressult['status']='1';
          $json = $ressult;

      }else{

        //$arr_data['user_code'] = $this->webservice_model->generateRandomString(4);

        $id = $this->webservice_model->insert_data('users',$arr_data);
        $data = $this->webservice_model->get_where('users',['id'=>$id]);        
        $data[0]['image']=SITE_URL.'uploads/images/'.$data[0]['image'];

          $ressult['result']=$data[0];
          $ressult['message']='successfull';
          $ressult['status']='1';
          $json = $ressult;

      }

      header('Content-type: application/json');
      echo json_encode($json);
    }


    /************* get_user_profile function *************/

     public function get_user_profile(){

      $arr_get = ['id'=>$this->input->get_post('user_id')];

      $login = $this->webservice_model->get_where('users',$arr_get);

      if ($login) {  
     
        $login[0]['image']=SITE_URL.'uploads/images/'.$login[0]['image'];
        $login[0]['vari_image']=SITE_URL.'uploads/images/'.$login[0]['vari_image'];

          $ressult['result']=$login[0];
          $ressult['message']='successfull';
          $ressult['status']='1';
          $json = $ressult;

      }else{

        $json = ['result'=>'unsuccessfull','status'=>0,'message'=>'Data Not Found'];

      }

      header('Content-type: application/json');
      echo json_encode($json);
    }      

    /************* get_city_status function *************/

     public function get_city_status(){

      $arr_get = ['name'=>$this->input->get_post('city')];

      $login = $this->webservice_model->get_where('city',$arr_get);

      if ($login) {  
     
if($login[0]['status'] == 'active'){

  $city_status = '1';
}else{

    $city_status = '0';

}
          $ressult['result']=$login[0];
          $ressult['message']='successfull';
          $ressult['status']= $city_status;
          $json = $ressult;

      }else{

        $json = ['result'=>'unsuccessfull','status'=>"0",'message'=>'Data Not Found'];

      }

      header('Content-type: application/json');
      echo json_encode($json);
    }      


    /************* user_update function *************/

    public function user_update(){

      $arr_get = ['id'=>$this->input->get_post('user_id')];

      $login = $this->webservice_model->get_where('users',$arr_get);
      if ($login[0]['id'] == "")
      {
                          $ressult['result']='Data Not Found';
                          $ressult['message']='unsuccessfull';
                          $ressult['status']='0';
                          $json = $ressult;

                                header('Content-type:application/json');
                                echo json_encode($json);
                                die;
      }



       $arr_data = [
            'name'=>$this->input->get_post('name'),
            'address'=>$this->input->get_post('address'),
            'city_id'=>$this->input->get_post('city_id'),
            'phone'=>$this->input->get_post('phone'),
            'about'=>$this->input->get_post('about'),
            'privacy'=>$this->input->get_post('privacy'),
            'email'=>$this->input->get_post('email')
            ];

                        if (isset($_FILES['image']))
      {
                       //  unlink('uploads/images/'.$login[0]['image']);
                           $n = rand(0, 100000);
                           $img = "USER_IMG_" . $n . '.png';
                           move_uploaded_file($_FILES['image']['tmp_name'], "uploads/images/" . $img);
                           $arr_data['image'] = $img;        
      }



            if (isset($_FILES['vari_image']))
      {
               $n = rand(0, 100000);
               $img = "VARI_IMG_" . $n . '.png';
               move_uploaded_file($_FILES['vari_image']['tmp_name'], "uploads/images/" . $img);
               $arr_data['vari_image'] = $img;        


      }

      $res = $this->webservice_model->update_data('users',$arr_data,$arr_get);
      if ($res)
      {
        $data = $this->webservice_model->get_where('users',$arr_get);
        $data[0]['image']=SITE_URL.'uploads/images/'.$data[0]['image'];
         $data[0]['vari_image']=SITE_URL.'uploads/images/'.$data[0]['vari_image'];
     
        $ressult['result']=$data[0];
        $ressult['message']='successfull';
        $ressult['status']='1';
        $json = $ressult;
      }
      else
      {
                          $ressult['result']='Data Not Found';
                          $ressult['message']='unsuccessfull';
                          $ressult['status']='0';
                          $json = $ressult;
      }

      header('Content-type: application/json');
      echo json_encode($json);

                          

    }


 /************* update_vari_image function *************/

    public function update_vari_image(){

      $arr_get = ['id'=>$this->input->get_post('user_id')];

      $login = $this->webservice_model->get_where('users',$arr_get);
      if ($login[0]['id'] == "")
      {
                          $ressult['result']='Data Not Found';
                          $ressult['message']='unsuccessfull';
                          $ressult['status']='0';
                          $json = $ressult;

                                header('Content-type:application/json');
                                echo json_encode($json);
                                die;
      }

  $arr_data = [
            'id'=>$this->input->get_post('user_id')
            ];

            if (isset($_FILES['vari_image']))
      {
               $n = rand(0, 100000);
               $img = "VARI_IMG_" . $n . '.png';
               move_uploaded_file($_FILES['vari_image']['tmp_name'], "uploads/images/" . $img);
               $arr_data['vari_image'] = $img;        


      }

      $res = $this->webservice_model->update_data('users',$arr_data,$arr_get);
      if ($res)
      {
        $data = $this->webservice_model->get_where('users',$arr_get);
        $data[0]['image']=SITE_URL.'uploads/images/'.$data[0]['image'];
         $data[0]['vari_image']=SITE_URL.'uploads/images/'.$data[0]['vari_image'];
     
        $ressult['result']=$data[0];
        $ressult['message']='successfull';
        $ressult['status']='1';
        $json = $ressult;
      }
      else
      {
                          $ressult['result']='Data Not Found';
                          $ressult['message']='unsuccessfull';
                          $ressult['status']='0';
                          $json = $ressult;
      }

      header('Content-type: application/json');
      echo json_encode($json);

                          

    }

  /************* driver_login function *************/


    public function driver_login(){


            
               	$email = $this->input->get_post('email', TRUE);
		            $password = md5($this->input->get_post('password', TRUE));
                $register_id = $this->input->get_post('register_id');
		            $where = "password = '$password' AND email='$email'";
		

     


      $login = $this->webservice_model->get_where('drivers',$where);
      if ($login) {
                         if($login[0]['status'] == 'active'){

                                 $arr_da = ['register_id' => ''];
                                 $arr_da1 = ['register_id' => $register_id , 'available_status' => 'online'];

                                 $arr_chk = "register_id = '".$register_id."'";

			       $this->webservice_model->update_data('drivers',$arr_da,$arr_chk);
                               $this->webservice_model->update_data('drivers',$arr_da1,$where);
                               $login3 = $this->webservice_model->get_where('drivers',$where);
                               $login3[0]['image']=SITE_URL.'uploads/images/'.$login3[0]['image'];
                               $ressult['result']=$login3[0];
                               $ressult['message']='successfull';
                               $ressult['status']='1';
                               $json = $ressult;
                           }else{
                               
                                $ressult['result']='Your account is not verify';
                                $ressult['message']='unsuccessfull';
                                $ressult['status']='0';
                                $json = $ressult; 



                                 }



                 }else{
                                $ressult['result']='Your have entered wrong email & password';
                                $ressult['message']='unsuccessfull';
                                $ressult['status']='0';
                                $json = $ressult;       
      }

      header('Content-type:application/json');
      echo json_encode($json);
    }

 /************* driver_signup function *************/

    public function driver_signup(){

         $arr_data = [
            'first_name'=>$this->input->get_post('first_name'),
            'last_name'=>$this->input->get_post('last_name'),
            'email'=>$this->input->get_post('email'),
            'password'=>md5($this->input->get_post('password')),
            'phone'=>$this->input->get_post('phone'),
            'address'=>$this->input->get_post('address'),
            'dob'=>$this->input->get_post('dob'),
            'id_number'=>$this->input->get_post('id_number'),
            'exp_date'=>$this->input->get_post('exp_date'),
            'user'=>$this->input->get_post('user'),
            'city_id'=>$this->input->get_post('city_id'),
            'register_id'=>$this->input->get_post('register_id'),
            'ios_register_id'=>$this->input->get_post('ios_register_id')
            ];


     $arr_get = ['email' => $arr_data['email']];

      $login = $this->webservice_model->get_where('drivers',$arr_get);
      if ($login) {
        
        $ressult['result']='Email already exist';
        $ressult['message']='unsuccessfull';
        $ressult['status']='0';
        $json = $ressult;
                               
        header('Content-type:application/json');
        echo json_encode($json);
        die;
      }     


       $arr_get1 = ['id_number' => $arr_data['id_number'],'id_number' => $arr_data['id_number']];

      $login1 = $this->webservice_model->get_where('drivers',$arr_get1);
      if ($login1) {
        
        $ressult['result']='id number already exist';
        $ressult['message']='unsuccessfull';
        $ressult['status']='0';
        $json = $ressult;
                               
        header('Content-type:application/json');
        echo json_encode($json);
        die;
      }     

                        if (isset($_FILES['image']))
      {
               $n = rand(0, 100000);
               $img = "USER_IMG_" . $n . '.png';
               move_uploaded_file($_FILES['image']['tmp_name'], "uploads/images/" . $img);
               $arr_data['image'] = $img;        
      }


         
                        if (isset($_FILES['license_image']))
      {
               $n1 = rand(0, 100000);
               $img1 = "LICE_IMG_" . $n1 . '.png';
               move_uploaded_file($_FILES['license_image']['tmp_name'], "uploads/images/" . $img1);
               $arr_data['license_image'] = $img1;        
      }


         
                        if (isset($_FILES['police_record_image']))
      {
               $n2 = rand(0, 100000);
               $img2 = "POLICE_IMG_" . $n2 . '.png';
               move_uploaded_file($_FILES['police_record_image']['tmp_name'], "uploads/images/" . $img2);
               $arr_data['police_record_image'] = $img2;        
      }



      $id = $this->webservice_model->insert_data('drivers',$arr_data);

      if ($id=="") {
        $json = ['result'=>'unsuccessfull','status'=>0,'message'=>'data not found'];
      }else{
               

               
        $arr_gets = ['id'=>$id];
        $login = $this->webservice_model->get_where('drivers',$arr_gets);       
        $login[0]['image']=SITE_URL.'uploads/images/'.$login[0]['image'];
        $ressult['result']=$login[0];
        $ressult['message']='successfull';
        $ressult['status']='1';
        $json = $ressult;
      }

      header('Content-type:application/json');
      echo json_encode($json);

    }

 /************* driver_forgot_password function *************/

    public function driver_forgot_password()
    {
      $email = $this->input->get_post('email', TRUE);
      $arr_login = ['email' => $email];

      $login = $this->webservice_model->get_where('drivers', $arr_login);
      if ($login)
      {
        $pass = random_string('alnum', 6);

        $to = $email;
        $subject = "Forgot Password";
        $body = "<div style='max-width: 600px; width: 100%; margin-left: auto; margin-right: auto;'>
        <header style='color: #fff; width: 100%;'>
           <img alt='' src='".SITE_URL."uploads/images/logo.png' width ='120' height='120'/>
        </header>
        
        <div style='margin-top: 10px; padding-right: 10px; 
      padding-left: 125px;
      padding-bottom: 20px;'>
          <hr>
          <h3 style='color: #232F3F;'>Hello ".$login[0]['email'].",</h3>
          <p>You have requested a new password for your Social ryde account.</p>
          <p>Your new password is <span style='background:#2196F3;color:white;padding:0px 5px'>".$pass."</span></p>
          <hr>
          
            <p>Warm Regards<br>Social ryde<br>Support Team</p>
            
          </div>
        </div>

    </div>";

        $headers = "From: info@mobileappdevelop.co" . "\r\n";
        $headers.= "MIME-Version: 1.0" . "\r\n";
        $headers.= "Content-type:text/html;charset=UTF-8" . "\r\n";

        mail($to, $subject, $body, $headers);

          $ressult['result']="Forgot password successfuly";
          $ressult['message']='successfull';
          $ressult['status']='1';
          $json = $ressult;

          $this->webservice_model->update_data('drivers',['password'=>($pass)],$arr_login);
        
      }
      else
      {
          $ressult['result']='Email not exist';
          $ressult['message']='unsuccessfull';
          $ressult['status']='0';
          $json = $ressult;

      }

      header('Content-type: application/json');
      echo json_encode($json);
    }


   /************* get_driver_profile function *************/

     public function get_driver_profile(){

      $arr_get = ['id'=>$this->input->get_post('driver_id')];

      $login = $this->webservice_model->get_where('drivers',$arr_get);

      if ($login) {  
     
        $login[0]['image']=SITE_URL.'uploads/images/'.$login[0]['image'];

          $ressult['result']=$login[0];
          $ressult['message']='successfull';
          $ressult['status']='1';
          $json = $ressult;

      }else{

        $json = ['result'=>'unsuccessfull','status'=>0,'message'=>'Data Not Found'];

      }

      header('Content-type: application/json');
      echo json_encode($json);
    }      




    /************* driver_update function *************/

    public function driver_update(){

      $arr_get = ['id'=>$this->input->get_post('driver_id')];

      $login = $this->webservice_model->get_where('drivers',$arr_get);
      if ($login[0]['id'] == "")
      {
                          $ressult['result']='Data Not Found';
                          $ressult['message']='unsuccessfull';
                          $ressult['status']='0';
                          $json = $ressult;

                                header('Content-type:application/json');
                                echo json_encode($json);
                                die;
      }



        $arr_data = [
            'first_name'=>$this->input->get_post('first_name'),
            'last_name'=>$this->input->get_post('last_name'),
            'email'=>$this->input->get_post('email'),
            'phone'=>$this->input->get_post('phone'),
            'address'=>$this->input->get_post('address'),
            'dob'=>$this->input->get_post('dob'),
            'id_number'=>$this->input->get_post('id_number'),
            'exp_date'=>$this->input->get_post('exp_date'),
            'user'=>$this->input->get_post('user')
           
            ];

         
                        if (isset($_FILES['image']))
      {
               $n = rand(0, 100000);
               $img = "USER_IMG_" . $n . '.png';
               move_uploaded_file($_FILES['image']['tmp_name'], "uploads/images/" . $img);
               $arr_data['image'] = $img;        
      }


         
                        if (isset($_FILES['license_image']))
      {
               $n1 = rand(0, 100000);
               $img1 = "LICE_IMG_" . $n1 . '.png';
               move_uploaded_file($_FILES['license_image']['tmp_name'], "uploads/images/" . $img1);
               $arr_data['license_image'] = $img1;        
      }


         
                        if (isset($_FILES['police_record_image']))
      {
               $n2 = rand(0, 100000);
               $img2 = "POLICE_IMG_" . $n2 . '.png';
               move_uploaded_file($_FILES['police_record_image']['tmp_name'], "uploads/images/" . $img2);
               $arr_data['police_record_image'] = $img2;        
      }


      $res = $this->webservice_model->update_data('drivers',$arr_data,$arr_get);
      if ($res)
      {
        $data = $this->webservice_model->get_where('drivers',$arr_get);
        $data[0]['image']=SITE_URL.'uploads/images/'.$data[0]['image'];
       // $data[0]['license_image']=SITE_URL.'uploads/images/'.$data[0]['license_image'];
       // $data[0]['police_record_image']=SITE_URL.'uploads/images/'.$data[0]['police_record_image'];

        $ressult['result']=$data[0];
        $ressult['message']='successfull';
        $ressult['status']='1';
        $json = $ressult;
      }
      else
      {
                          $ressult['result']='Data Not Found';
                          $ressult['message']='unsuccessfull';
                          $ressult['status']='0';
                          $json = $ressult;
      }

      header('Content-type: application/json');
      echo json_encode($json);

                          

    }

    /************* update_driver_lat_lon function *************/

    public function update_driver_lat_lon(){

      $arr_get = ['id'=>$this->input->get_post('driver_id')];

      $login = $this->webservice_model->get_where('drivers',$arr_get);
      if ($login[0]['id'] == "")
      {
                          $ressult['result']='Data Not Found';
                          $ressult['message']='unsuccessfull';
                          $ressult['status']='0';
                          $json = $ressult;

                                header('Content-type:application/json');
                                echo json_encode($json);
                                die;
      }



        $arr_data = [
            'lat'=>$this->input->get_post('lat'),
            'lon'=>$this->input->get_post('lon')
           
            ];

         

      $res = $this->webservice_model->update_data('drivers',$arr_data,$arr_get);
      if ($res)
      {
        $data = $this->webservice_model->get_where('drivers',$arr_get);
        $data[0]['image']=SITE_URL.'uploads/images/'.$data[0]['image'];
        $data[0]['license_image']=SITE_URL.'uploads/images/'.$data[0]['license_image'];
        $data[0]['police_record_image']=SITE_URL.'uploads/images/'.$data[0]['police_record_image'];

        $ressult['result']=$data[0];
        $ressult['message']='successfull';
        $ressult['status']='1';
        $json = $ressult;
      }
      else
      {
                          $ressult['result']='Data Not Found';
                          $ressult['message']='unsuccessfull';
                          $ressult['status']='0';
                          $json = $ressult;
      }

      header('Content-type: application/json');
      echo json_encode($json);

                          

    }

  /************* update_user_lat_lon function *************/

    public function update_user_lat_lon(){

      $arr_get = ['id'=>$this->input->get_post('user_id')];

      $login = $this->webservice_model->get_where('users',$arr_get);
      if ($login[0]['id'] == "")
      {
                          $ressult['result']='Data Not Found';
                          $ressult['message']='unsuccessfull';
                          $ressult['status']='0';
                          $json = $ressult;

                                header('Content-type:application/json');
                                echo json_encode($json);
                                die;
      }



        $arr_data = [
            'Rlat'=>$this->input->get_post('Rlat'),
            'Rlon'=>$this->input->get_post('Rlon')
           
            ];

         

      $res = $this->webservice_model->update_data('users',$arr_data,$arr_get);
      if ($res)
      {
        $data = $this->webservice_model->get_where('users',$arr_get);
        $data[0]['image']=SITE_URL.'uploads/images/'.$data[0]['image'];
        
        $ressult['result']=$data[0];
        $ressult['message']='successfull';
        $ressult['status']='1';
        $json = $ressult;
      }
      else
      {
                          $ressult['result']='Data Not Found';
                          $ressult['message']='unsuccessfull';
                          $ressult['status']='0';
                          $json = $ressult;
      }

      header('Content-type: application/json');
      echo json_encode($json);

                          

    }


    /*************  get_all_driver_list *************/
    public

    function get_all_driver_list()
    {                     
                          
      $fetch = $this->webservice_model->get_all('drivers');
     
            
      if ($fetch) {

                          foreach($fetch as $val)
                          {
                               $val['image']=SITE_URL.'uploads/images/'.$val['image'];
                               $val['license_image']=SITE_URL.'uploads/images/'.$val['license_image'];
                               $val['police_record_image']=SITE_URL.'uploads/images/'.$val['police_record_image'];
                               $data[] = $val;
        
                          }
                         
                          $ressult['result']=$data;
                          $ressult['message']='successful';
                          $ressult['status']='1';
                          $json = $ressult;                      
                         

      }
      else {
                          $ressult['result']='Data Not Found';
                          $ressult['message']='unsuccessful';
                          $ressult['status']='0';
                          $json = $ressult;
      }

      header('Content-type: application/json');
      echo json_encode($json);

    }



/***************get country code list *****************/

    public

	function get_country_code()
        {  
          $data = $this->db->query("SELECT *FROM qc_country");
		//$this->db->last_query();
		  $fetch = $data->result_array();

		// print_r($fetch);
                 
		$result = $data->num_rows($data);
		if ($result != 0)
			{
			foreach($fetch as $key => $val)
				{
                                $val1['id'] =$val['id'];
                                $arr_gets = ['country_name'=>$val['country']];
                                $login = $this->webservice_model->get_where('country',$arr_gets);       
                                $val1['country_image']=SITE_URL.'uploads/flags/'.$login[0]['images'];
                                $val1['country'] =$val['country'];
                                $val1['country_code'] =$val['itu-t _telephone_code'];
				$val1['result'] = "successful";
				$json[] = $val1;
				}
			}
		  else
			{
			$json = array(
				"result" => "unsuccessful"
			);
			}

		header('Content-type: application/json');
		echo json_encode($json);
		die;
		}


 /*************  country_list *************/
    public

    function country_list()
    {                     
                          
      $fetch = $this->webservice_model->get_all('country');
     
            
      if ($fetch) {

                          foreach($fetch as $val)
                          {
                                   
                            $data[] = $val;
        
                          }
                         
                          $ressult['result']=$data;
                          $ressult['message']='successful';
                          $ressult['status']='1';
                          $json = $ressult;                      
                         

      }
      else {
                          $ressult['result']='Data Not Found';
                          $ressult['message']='unsuccessful';
                          $ressult['status']='0';
                          $json = $ressult;
      }

      header('Content-type: application/json');
      echo json_encode($json);

    }

/************* get_state function *************/

     public function get_state(){

      $arr_get = ['country_id'=>$this->input->get_post('country_id')];

      $fetch = $this->webservice_model->get_where('states',$arr_get);
 if ($fetch) {

                          foreach($fetch as $val)
                          {
                                   
                            $data[] = $val;
        
                          }
                         
                          $ressult['result']=$data;
                          $ressult['message']='successful';
                          $ressult['status']='1';
                          $json = $ressult;                      
                         

      }
      else {
                          $ressult['result']='Data Not Found';
                          $ressult['message']='unsuccessful';
                          $ressult['status']='0';
                          $json = $ressult;
      }

      header('Content-type: application/json');
      echo json_encode($json);

    }

/************* get_city function *************/

     public function get_city(){

      $arr_get = ['state_id'=>$this->input->get_post('state_id')];

      $fetch = $this->webservice_model->get_where('city',$arr_get);
 if ($fetch) {

                          foreach($fetch as $val)
                          {
                                   
                            $data[] = $val;
        
                          }
                         
                          $ressult['result']=$data;
                          $ressult['message']='successful';
                          $ressult['status']='1';
                          $json = $ressult;                      
                         

      }
      else {
                          $ressult['result']='Data Not Found';
                          $ressult['message']='unsuccessful';
                          $ressult['status']='0';
                          $json = $ressult;
      }

      header('Content-type: application/json');
      echo json_encode($json);

    }


    /*************  get_all_event *************/
    public

    function get_all_event()
    {                     
                         
      $fetch = $this->webservice_model->get_where('events',"DATE(event_date) >= CURRENT_DATE()");
     
            
      if ($fetch) {
                       
                          foreach($fetch as $val)
                          {
 
                                  $val['event_image']=SITE_URL.'uploads/images/'.$val['event_image'];
                                  $data[] = $val;
                                  
                         
                         }
                          $ressult['result']=$data;
                          $ressult['message']='successful';
                          $ressult['status']='1';
                          $json = $ressult;                      
                         

      } 
      else {
                          $ressult['result']='Data Not Found';
                          $ressult['message']='unsuccessful';
                          $ressult['status']='0';
                          $json = $ressult;
      }

      header('Content-type: application/json');
      echo json_encode($json);

    }


 /************* get_event function *************/

     public function get_event(){

      $arr_get = ['event_name'=>$this->input->get_post('event_name')];

      $login = $this->webservice_model->get_where('events',$arr_get);

      if ($login) {  
  
     
          $login[0]['event_image']=SITE_URL.'uploads/images/'.$login[0]['event_image'];

          $ressult['result']=$login[0];
          $ressult['message']='successfull';
          $ressult['status']='1';
          $json = $ressult;

      }else{

        $json = ['result'=>'unsuccessfull','status'=>0,'message'=>'Data Not Found'];

      }

      header('Content-type: application/json');
      echo json_encode($json);
    }      


 /************* get_event1 function *************/

     public function get_event1(){

      $arr_get = ['id'=>$this->input->get_post('event_id')];

      $user_id = $this->input->get_post('user_id');

      $login = $this->webservice_model->get_where('events',$arr_get);

      if ($login) {  
  

          $where = ['user_id'=>$user_id,'event_id'=>$login[0]['id']];
          $fetch = $this->webservice_model->get_where('user_attend_event',$where);
if($fetch){

           $login[0]['attending_status']='YES';


}else{

            $login[0]['attending_status']='NO';

}
     
          $login[0]['event_image']=SITE_URL.'uploads/images/'.$login[0]['event_image'];

          $ressult['result']=$login[0];
          $ressult['message']='successfull';
          $ressult['status']='1';
          $json = $ressult;

      }else{

        $json = ['result'=>'unsuccessfull','status'=>0,'message'=>'Data Not Found'];

      }

      header('Content-type: application/json');
      echo json_encode($json);
    }      





/***************get driver list  nearbuy *****************/
    public

	function get_driver_list_nearbuy()
        { 	        
                         $lat = $this->input->get_post('lat', TRUE) ;
			 $lon = $this->input->get_post('lon', TRUE) ;
                         $user_distance = 5;//$this->input->get_post('distance', TRUE);
                        // $vehicle_type = $this->input->get_post('vehicle_type', TRUE) ;
                    $query="SELECT * FROM drivers";
                    $sql = mysql_query($query);
                    $result = mysql_num_rows($sql);
                    
                     if ($result != 0)
                      {

            
			while ($val = mysql_fetch_assoc($sql))
		        {
                                  if(!$val['lat']=="" && !$val['lon']==""){
				  $distance = $this->webservice_model->distance($lat, $lon, $val['lat'], $val['lon'], $miles = false);                       
                                     if($user_distance >= $distance){


                                
                                $val['distance'] = number_format($distance, 2, '.', '');
				$val['estimate_time'] = round($distance * 1.5);
	                        $json[] = $val;
			        }
                             }

                                
                         }
                     

       
                                
                        if(!isset($json))
                          {
                                $ressult['result']='Data Not Found';
	                        $ressult['message']='unsuccessful';
	                        $ressult['status']='0';
	                        $code = $ressult;
                           

                       
                                header('Content-type: application/json');
		                echo json_encode($code);
		                die;


                              }else{

                                $ressult['result']=$json;
	                        $ressult['message']='successful';
	                        $ressult['status']='1';
	                        $code = $ressult;


                               }       

                      } 
		  else
		      {
			        $ressult['result']='Data Not Found';
	                        $ressult['message']='unsuccessful';
	                        $ressult['status']='0';
	                        $code = $ressult;
		      }
        header('Content-type: application/json');
	echo json_encode($code);
	die;
	 }      





/***************request_nearbuy_driver *****************/
    public

	function request_nearbuy_driver()
        { 	        
                         $lat = $this->input->get_post('pickup_lat', TRUE) ;
			                   $lon = $this->input->get_post('pickup_lon', TRUE) ;
                        // $vehicle_type = $this->input->get_post('vehicle_type', TRUE) ;
                         $user_distance = 50;//$this->input->get_post('distance', TRUE);
                       
                         $arr_data = [
					
				                        'user_id' => $this->input->get_post('user_id'),	
				                        'event_id' => $this->input->get_post('event_id'),	
				                        'date' => $this->input->get_post('date'),
                                'time' => $this->input->get_post('time'),
                                'pickup_lat' => $this->input->get_post('pickup_lat'),
                                'pickup_lon' => $this->input->get_post('pickup_lon'),
                                'dropoff_lat' => $this->input->get_post('dropoff_lat'),
                                'dropoff_lon' => $this->input->get_post('dropoff_lon'),
                                'pick_address' => $this->input->get_post('pick_address'),
                                'payment_type' => $this->input->get_post('payment_type'),
                                'pick_city' => $this->input->get_post('city'),
                                'drop_address' => $this->input->get_post('drop_address')
                    			];

                          if (isset($_FILES['item_image']))
                    			{
                                 $n = rand(0, 100000);
                                 $img = "ITEM_IMG_" . $n . '.png';
                                 move_uploaded_file($_FILES['item_image']['tmp_name'], "uploads/images/" . $img);
                                 $arr_data['item_image'] = $img;			   
                    			}
                          $arr_get = ['name'=>$this->input->get_post('city'),'status'=>'Active'];
                          $get_city = $this->webservice_model->get_where('city',$arr_get);
                          if(!$get_city){
                            $json = ['result'=>'city not found','message'=>'unsuccessfull','status'=>'2'];
                            header('Content-type: application/json');
                            echo json_encode($json);
                            die;
                          }


                     $last_id = $this->webservice_model->insert_data('user_request', $arr_data); 



                $query="SELECT * FROM `drivers` WHERE available_status = 'online' AND id NOT IN(select accept_driver_id from user_request where accept_driver_id != '' and status != 'Reject' AND status != 'Complete')"; 
                   //  $query="SELECT * FROM drivers WHERE vehicle_type = '$vehicle_type'"; 
                     $sql = mysql_query($query);
                     $result = mysql_num_rows($sql);
                    
                     if ($result != 0)
                      {

                         $i = 0; $ids = '';

			while ($val = mysql_fetch_assoc($sql))
		        {
                                  if(!$val['lat']=="" && !$val['lon']==""){
				  $distance = $this->webservice_model->distance($lat, $lon, $val['lat'], $val['lon'], $miles = false);                       
                                     if($user_distance >= $distance){
                                        if($ids == ''){
                                            $ids = $val['id'];
                                          }else{

                                         $ids = $ids.','.$val['id'];
                                       }

                             
                             
                                $val['result'] = "successful";
	                              $json[] = $val;
                                $i++;



                             // send notification for Andriod

                 $arr_get1 = ['id'=>$arr_data['user_id']];

                 $login1 = $this->webservice_model->get_where('users',$arr_get1);
               

                   $user_message_apk = array(
                           "message" => array(
                             "result" => "successful",
                             "key" => "Request for booking",
                             "register_id" => $val['register_id'],
                             "pickup_lat" => $arr_data['pickup_lat'],
                             "pickup_lon" => $arr_data['pickup_lon'],
                             "dropoff_lat" => $arr_data['dropoff_lat'],
                             "dropoff_lon" => $arr_data['dropoff_lon'],
                             "name" => $login1[0]['name'],
                             "phone" => $login1[0]['phone'],
                             "user_image" => SITE_URL.'uploads/images/'.$login1[0]['image'],
                             "driver_id" => $val['id'],
                             "request_id" => $last_id,
                             "date"=> date('Y-m-d h:i:s')
                           )
                         );
                  

                        $register_userid = array($val['register_id']);


                        $this->webservice_model->driver_apk_notification($register_userid, $user_message_apk);




              // end send notification for Andriod    

   
                                
                                       $arr_data2 = [
                                                      'driver_id'=>$val['id'],
                                                      'status'=>'Pending' , 
                                                      'user_request_id'=>$last_id
                     
                                                     ];
      
                                       $ride = $this->webservice_model->insert_data('driver_ride_history',$arr_data2);

			        }
                              }
                           }
                     
                      
                          if($i == '0')
                          {
                                $ressult['result']='Data Not Found';
	                              $ressult['message']='unsuccessful';
	                              $ressult['status']='0';
	                              $code = $ressult;
                           
                                $id = $this->webservice_model->delete_data('user_request', ['id'=>$last_id]);
                       
                                header('Content-type: application/json');
		                            echo json_encode($code);
		                            die;


                              }else{ 
                                  $arr_data['driver_id'] = $ids;

                                  $id = $this->webservice_model->update_data('user_request', $arr_data, ['id'=>$last_id]);

                                     if ($id=="") {
                                        $json = ['result'=>'unsuccessfull','status'=>0,'message'=>'data not found'];
                                         }else{
                              
                                             $arr_gets = ['id'=>$last_id];
                                             $login = $this->webservice_model->get_where('user_request',$arr_gets);       
                                             $login[0]['item_image']=SITE_URL.'uploads/images/'.$login[0]['item_image'];
                                             $ressult['result']=$login[0];
                                             $ressult['message']='successfull';
                                             $ressult['status']='1';
                                             $json = $ressult;
                                           }

                                             header('Content-type:application/json');
                                             echo json_encode($json);die;


                                         }       

                      } 
		  else
		      {
			                    $ressult['result']='Data Not Found';
	                        $ressult['message']='unsuccessful';
	                        $ressult['status']='0';
	                        $code = $ressult;
		      }
        header('Content-type: application/json');
	      echo json_encode($code);
	      die;
	 }   


   


/***************get_request *****************/


    public


	function get_request()
        {  
           
			$driver_id = $this->input->get_post('driver_id', TRUE); 
			
		    $query="SELECT * FROM user_request WHERE (driver_id = '$driver_id' OR driver_id LIKE '$driver_id,%' OR driver_id LIKE '%,$driver_id,%' OR driver_id LIKE '%,$driver_id') AND status != 'Accept' AND accept_driver_id != '$driver_id' "; 
                     $sql = mysql_query($query);
                     $result = mysql_num_rows($sql);
                    
	      
		
                 if ($result)
			
                       {
			   while ($val = mysql_fetch_assoc($sql))
		        {
                               $where = ['id'=>$val['user_id']];
                               $login = $this->webservice_model->get_where('users',$where);
                               $val['user_name']=$login[0]['username'];
                               $val['user_phone']=$login[0]['phone'];
                               $val['user_email']=$login[0]['email'];
                               $val['user_image']=SITE_URL.'uploads/images/'.$login[0]['image'];                              
                                $ressult1[]=$val;                               
                               }
                                $data['result']= $ressult1;
                                $data['message']='successfull';
                                $data['status']='1';
                                $json = $data;

                      
			}
 
                                
		  else
			{
			        $data['result']['errorMsg']='No Request Found';
                                $data['message']='unsuccessfull';
                                $data['status']='0';
                                $json = $data; 
			}

		header('Content-type: application/json');
		echo json_encode($json);
		}





    /************* accept_request function *************/

    public function accept_request(){

       $arr_get = ['id'=>$this->input->get_post('request_id')];

      $login = $this->webservice_model->get_where('user_request',$arr_get);
      if ($login[0]['id'] == "")
      {
                          $ressult['result']='Data Not Found';
                          $ressult['message']='unsuccessfull';
                          $ressult['status']='0';
                          $json = $ressult;

                                header('Content-type:application/json');
                                echo json_encode($json);
                                die;
      }

      $arr_get11 = ['id'=>$this->input->get_post('request_id'),'accept_driver_id !='=> '' , 'status'=> 'Accept'];

      $login11 = $this->webservice_model->get_where('user_request',$arr_get11);
      if ($login11)
      {
                          $ressult['result']='Already Accepted';
                          $ressult['message']='unsuccessfull';
                          $ressult['status']='0';
                          $json = $ressult;

                                header('Content-type:application/json');
                                echo json_encode($json);
                                die;
      }

   $arr_get22 = ['id'=>$this->input->get_post('request_id'),'accept_driver_id !='=> '' , 'status'=> 'Complete'];

      $login22= $this->webservice_model->get_where('user_request',$arr_get22);
      if ($login22)
      {
                          $ressult['result']='Already Complete';
                          $ressult['message']='unsuccessfull';
                          $ressult['status']='0';
                          $json = $ressult;

                                header('Content-type:application/json');
                                echo json_encode($json);
                                die;
      }

    
       $arr_get33 = ['id'=>$this->input->get_post('request_id') , 'user_status !='=> ''];

      $login33= $this->webservice_model->get_where('user_request',$arr_get33);
      if ($login33)
      {
                          $ressult['result']='Request Cancel By User';
                          $ressult['message']='unsuccessfull';
                          $ressult['status']='0';
                          $json = $ressult;

                                header('Content-type:application/json');
                                echo json_encode($json);
                                die;
      }
  



       $arr_data = [
            'accept_driver_id'=>$this->input->get_post('accept_driver_id'),
            'status'=>$this->input->get_post('status')
                     
       ];

          $arr_get1 = ['id'=>$login[0]['user_id']];

                  $login1 = $this->webservice_model->get_where('users',$arr_get1);

                  $arr_get2 = ['id'=>$arr_data['accept_driver_id']];

                  $login2 = $this->webservice_model->get_where('drivers',$arr_get2);


                      // send notification for Andriod

 
               

            $user_message_apk = array(
                           "message" => array(
                             "result" => "successful",
                             "key" => "Request for booking",
                             "register_id" => $login1[0]['register_id'],
                             "status" => $arr_data['status'],
                           
                             "driver_id" => $login2[0]['id'],
                             "driver_name" => $login2[0]['first_name'],
                             "driver_phone" =>$login2[0]['phone'],
                             "driver_lat" => $login2[0]['lat'],
                             "driver_lon" => $login2[0]['lon'],
                             "driver_image" => SITE_URL.'uploads/images/'.$login2[0]['image'],
                             "request_id" => $login[0]['id'],
                             "request_type" => $login[0]['request_type'],

                             "date"=> date('Y-m-d h:i:s')
                           )
                         );
                  
                       //print_r($user_message_apk);die;

                        $register_userid = array($login1[0]['register_id']);


                        $this->webservice_model->user_apk_notification($register_userid, $user_message_apk);




              // end send notification for Andriod 

      $res = $this->webservice_model->update_data('user_request',$arr_data,$arr_get);
      if ($res)
      {
  
        $arr_data2 = [
            'driver_id'=>$this->input->get_post('accept_driver_id'),
            'status'=>$this->input->get_post('status') , 
            'user_request_id'=>$this->input->get_post('request_id')
                     
       ];
      
       $ride = $this->webservice_model->insert_data('driver_ride_history',$arr_data2);

                                                
        $arr_get1 = ['id'=>$this->input->get_post('request_id')];
        $data = $this->webservice_model->get_where('user_request',$arr_get1);


        $data[0]['name'] = $login1[0]['name'];
        $data[0]['user_phone'] = $login1[0]['phone'];

        $data[0]['user_image']=SITE_URL.'uploads/images/'.$login1[0]['image'];
        $ressult['result']=$data[0];
        $ressult['message']='successfull';
        $ressult['status']='1';
        $json = $ressult;
      }
      else
      {
                          $ressult['result']='Data Not Found';
                          $ressult['message']='unsuccessfull';
                          $ressult['status']='0';
                          $json = $ressult;
      }

      header('Content-type: application/json');
      echo json_encode($json);

                  

    }



   
  /************* change_driver_status function *************/

    public function change_driver_status(){

      $arr_get = ['id'=>$this->input->get_post('request_id')];

      $login = $this->webservice_model->get_where('user_request',$arr_get);
      if ($login[0]['id'] == "")
      {
                          $ressult['result']='Data Not Found';
                          $ressult['message']='unsuccessfull';
                          $ressult['status']='0';
                          $json = $ressult;

                                header('Content-type:application/json');
                                echo json_encode($json);
                                die;
      }

   
   


       $arr_data = [
            'accept_driver_id'=>$this->input->get_post('accept_driver_id'),
            'status'=>$this->input->get_post('status')
                     
       ];

      
                      // send notification for Andriod

 
                 $arr_get1 = ['id'=>$login[0]['user_id']];

                  $login1 = $this->webservice_model->get_where('users',$arr_get1);

                  $arr_get2 = ['id'=>$arr_data['accept_driver_id']];

                  $login2 = $this->webservice_model->get_where('drivers',$arr_get2);


            $user_message_apk = array(
                           "message" => array(
                             "result" => "successful",
                             "key" => "Request ".$arr_data['status'],
                             "register_id" => $login1[0]['register_id'],
                             "status" => $arr_data['status'],

                             "driver_name" => $login2[0]['first_name'],
                             "driver_phone" =>$login2[0]['phone'],
                             "driver_lat" => $login2[0]['lat'],
                             "driver_lon" => $login2[0]['lon'],
                             "driver_image" => SITE_URL.'uploads/images/'.$login2[0]['image'],
                             "request_id" => $login[0]['id'],

                             "date"=> date('Y-m-d h:i:s')
                           )
                         );
                  
                       //print_r($user_message_apk);die;

                        $register_userid = array($login1[0]['register_id']);


                        $this->webservice_model->user_apk_notification($register_userid, $user_message_apk);




              // end send notification for Andriod   


      $res = $this->webservice_model->update_data('user_request',$arr_data,$arr_get);
      if ($res)
      {

        $arr_data2 = [
            'driver_id'=>$this->input->get_post('accept_driver_id'),
            'status'=>$this->input->get_post('status') , 
            'user_request_id'=>$this->input->get_post('request_id')
                     
       ];
      
       $ride = $this->webservice_model->insert_data('driver_ride_history',$arr_data2);

          $arr_get1 = ['id'=>$login[0]['user_id']];

                  $login1 = $this->webservice_model->get_where('users',$arr_get1);

                  $arr_get2 = ['id'=>$arr_data['accept_driver_id']];

                  $login2 = $this->webservice_model->get_where('drivers',$arr_get2);


                 

        $arr_get1 = ['id'=>$this->input->get_post('request_id')];
        $data = $this->webservice_model->get_where('user_request',$arr_get1);
        $data[0]['name'] = $login1[0]['name'];
        $data[0]['user_phone'] = $login1[0]['phone'];

        $data[0]['user_image']=SITE_URL.'uploads/images/'.$login1[0]['image'];
        $ressult['result']=$data[0];
        $ressult['message']='successfull';
        $ressult['status']='1';
        $json = $ressult;
      }
      else
      {
                          $ressult['result']='Data Not Found';
                          $ressult['message']='unsuccessfull';
                          $ressult['status']='0';
                          $json = $ressult;
      }

      header('Content-type: application/json');
      echo json_encode($json);

                  

    }




/************* update_user_status function *************/

    public function update_user_status(){

      $arr_get = ['id'=>$this->input->get_post('request_id')];

      $login = $this->webservice_model->get_where('user_request',$arr_get);
      if ($login[0]['id'] == "")
      {
                          $ressult['result']='Data Not Found';
                          $ressult['message']='unsuccessfull';
                          $ressult['status']='0';
                          $json = $ressult;

                                header('Content-type:application/json');
                                echo json_encode($json);
                                die;
      }

      

     $arr_data = [
            'user_status'=>$this->input->get_post('user_status') ,
            'status'=>'Reject'
                     
       ];


                 
                 $arr_get2 = ['id'=>$login[0]['accept_driver_id']];

                 $login2 = $this->webservice_model->get_where('drivers',$arr_get2);




                // send notification for ios


                 $arr_get1 = ['id'=>$login[0]['user_id']];

                 $login1 = $this->webservice_model->get_where('users',$arr_get1);
               
                

              // send notification for Andriod

               

                   $user_message_apk = array(
                           "message" => array(
                             "result" => "successful",
                             "key" => "Request for booking Cancel By User",
                             "request_id" => $login[0]['id'],
                             "date"=> date('Y-m-d h:i:s')
                           )
                         );
                  

                        $register_userid = array($login2[0]['register_id']);


                        $this->webservice_model->driver_apk_notification($register_userid, $user_message_apk);

     
 


              // end send notification for Andriod     
               



      $res = $this->webservice_model->update_data('user_request',$arr_data,$arr_get);
      if ($res)
      { 
        

        $arr_get1 = ['id'=>$this->input->get_post('request_id')];
        $data = $this->webservice_model->get_where('user_request',$arr_get1);
      
        $ressult['result']=$data[0];
        $ressult['message']='successfull';
        $ressult['status']='1';
        $json = $ressult;
      }
      else
      {
                          $ressult['result']='Data Not Found';
                          $ressult['message']='unsuccessfull';
                          $ressult['status']='0';
                          $json = $ressult;
      }

      header('Content-type: application/json');
      echo json_encode($json);

    }


    
    /************* user_attend_event function *************/

    public function user_attend_event(){

         $arr_data = [
            'user_id'=>$this->input->get_post('user_id'),
            'event_id'=>$this->input->get_post('event_id')         
            ];


      $arr_get = ['user_id' => $arr_data['user_id'],'event_id' => $arr_data['event_id']];

      $login = $this->webservice_model->get_where('user_attend_event',$arr_get);
      if ($login) {
        
        $ressult['result']='already exist';
        $ressult['message']='unsuccessfull';
        $ressult['status']='0';
        $json = $ressult;
                               
        header('Content-type:application/json');
        echo json_encode($json);
        die;
      }     

      

      $id = $this->webservice_model->insert_data('user_attend_event',$arr_data);

      if ($id=="") {
        $json = ['result'=>'unsuccessfull','status'=>0,'message'=>'data not found'];
      }else{
        
              
        $arr_gets = ['id'=>$id];
        $login = $this->webservice_model->get_where('user_attend_event',$arr_gets);       
        $ressult['result']=$login[0];
        $ressult['message']='successfull';
        $ressult['status']='1';
        $json = $ressult;
      }

      header('Content-type:application/json');
      echo json_encode($json);

    }


    
    /************* user_cancel_event function *************/

    public function user_cancel_event(){

         $arr_data = [
            'user_id'=>$this->input->get_post('user_id'),
            'event_id'=>$this->input->get_post('event_id')         
            ];


      $arr_get = ['user_id' => $arr_data['user_id'],'event_id' => $arr_data['event_id']];

      $login = $this->webservice_model->get_where('user_attend_event',$arr_get);
      if ($login) {
        
        $this->webservice_model->delete_data('user_attend_event',$arr_get);

                          $ressult['result']="Item delete successfull";
                          $ressult['message']='successful';
                          $ressult['status']='1';
                          $json = $ressult;
      }
        else
      {
                          $ressult['result']='Data Not Found';
                          $ressult['message']='unsuccessful';
                          $ressult['status']='0';
                          $json = $ressult;                              
        
      }

        
                     
      header('Content-type: application/json');
      echo json_encode($json);
    }


   

/************* add_event function *************/



    public function add_event(){

         

    $arr_data = [
            'user_id'=>$this->input->get_post('user_id'),
            'event_name'=>$this->input->get_post('event_name') ,
            'address'=>$this->input->get_post('address') ,   
            'description'=>$this->input->get_post('description') ,   
            'lat'=>$this->input->get_post('lat') ,   
            'lon'=>$this->input->get_post('lon') ,   
            'event_date'=>$this->input->get_post('event_date') ,           
            ];
     

                   
        if (isset($_FILES['event_image']))
      {
                           $n = rand(0, 100000);
                           $img = "USER_IMG_" . $n . '.png';
                           move_uploaded_file($_FILES['event_image']['tmp_name'], "uploads/images/" . $img);
                           $arr_data['event_image'] = $img;        
      }

     

      $id = $this->webservice_model->insert_data('events',$arr_data);

      if ($id=="") {
        $json = ['result'=>'unsuccessfull','status'=>0,'message'=>'data not found'];
      }else{
        
              
        $arr_gets = ['id'=>$id];
        $login = $this->webservice_model->get_where('events',$arr_gets);    
        $login[0]['event_image']=SITE_URL.'uploads/images/'.$login[0]['event_image'];
   
        $ressult['result']=$login[0];
        $ressult['message']='successfull';
        $ressult['status']='1';
        $json = $ressult;
      }

      header('Content-type:application/json');
      echo json_encode($json);

    }

    
/*************  get_user_attend_event *************/
    public

    function get_user_attend_event()
    {                     
                          
      $event_id = $this->input->get_post('event_id');
      $user_id = $this->input->get_post('user_id');

      $login = $this->db->query("SELECT * FROM `user_attend_event` WHERE event_id = $event_id AND user_id NOT IN(SELECT CASE WHEN block_by = $user_id THEN block_user_id WHEN block_user_id = $user_id THEN block_by END AS ids FROM block_users WHERE block_by = $user_id OR block_user_id = $user_id group by ids)")->result_array();
               //echo $this->db->last_query();
      if ($login) {
                         
                         foreach($login as  $val)
			 {  
                          
                           $where = ['id'=>$val['user_id']];
                           $fetch = $this->webservice_model->get_where('users',$where);

                           $where1 = ['id'=>$val['event_id']];
                           $fetch1 = $this->webservice_model->get_where('events',$where1);

                           $val['name'] =  $fetch[0]['name'];
                           $val['about'] =  $fetch[0]['about'];

                           $val['user_image'] = SITE_URL.'uploads/images/'.$fetch[0]['image'];
                           if($fetch1[0]['user_id']!=$user_id){
                             $data[] = $val;
                           }
                          }
        
                          
                         
                          $ressult['result']=$data;
                          $ressult['message']='successful';
                          $ressult['status']='1';
                          $json = $ressult;                      
                         

      }
      else {
                          $ressult['result']='Data Not Found';
                          $ressult['message']='unsuccessful';
                          $ressult['status']='0';
                          $json = $ressult;
      }

      header('Content-type: application/json');
      echo json_encode($json);

    }

  
   
/************* total_fare function *************/



     public function total_fare(){

               $arr_get = ['id'=>$this->input->get_post('request_id'),'status'=>'Complete'];

    $arr_data = [

            'distance'=>$this->input->get_post('distance') ,
            'duration'=>$this->input->get_post('duration') ,   
            'waiting_time'=>$this->input->get_post('waiting_time') 
            ];
     
     $login = $this->webservice_model->get_where('user_request',$arr_get);
               
      if ($login) {
                         
                          $id = $this->webservice_model->update_data('user_request',$arr_data,$arr_get);
        
                          $login1 = $this->webservice_model->get_where('user_request',$arr_get);

                          $arr_get11 = ['id'=>$login1[0]['accept_driver_id']];
                          $login11 = $this->webservice_model->get_where('drivers',$arr_get11);

                          $arr_get111 = ['name'=>$login1[0]['pick_city']];
                          $login111 = $this->webservice_model->get_where('city',$arr_get111);

                          $arr_get222 = ['id'=>$login111[0]['state_id']];
                          $login222 = $this->webservice_model->get_where('states',$arr_get222);

                          



                          $login111[0]['RatePerKilometer'];
                          $login111[0]['RatePerMinute'];
                          $login111[0]['WaitTimePerMinute'];
                          $login111[0]['CityFeePerKilometer'];
                          $login111[0]['BaseFeeFlatRate'];
                          $login111[0]['BookingFeeFlatRate'];
                          $login111[0]['RiderFeeFlatRate'];

                          $DriverPercentage = $login111[0]['DriverPercentage'];


                          $login1[0]['duration'];
                          $login1[0]['waiting_time'];
                          $login1[0]['distance'];


                          $aa = $login111[0]['RatePerKilometer'] * $login1[0]['distance'];
                          $bb = $login111[0]['WaitTimePerMinute'] * $login1[0]['waiting_time'];
                          $cc = $login111[0]['RatePerMinute'] * $login1[0]['duration'];
                          $dd = $login111[0]['CityFeePerKilometer'] * $login1[0]['distance'];
                          $ee = $login111[0]['BaseFeeFlatRate'];
                          $ff = $login111[0]['BookingFeeFlatRate'];
                          $gg = $login111[0]['RiderFeeFlatRate'];


                          $login222[0]['PST'];
                          $login222[0]['HST'];
                          $login222[0]['GST'];
                          $login222[0]['FST'];
                          

// Base Fare =  RatePerKilometer + RatePerMinute +  WaitTimePerMinute + BaseFeeFlatRate +  BookingFeeFlatRate

    $Base_Fare =    $aa + $cc + $bb + $ee + $ff;    
         
// Othertaxed = CityFeePerKilometer(40.60) + RiderFeeFlatRate(0.35)

    $Othertaxed = $dd + $gg;

// Value2tax = BaseFare + Othertaxed
  
   $Value2tax = $Base_Fare + $Othertaxed;


// PST Charge : (50  *   98.20) /100  =  49.10


    $pst = ($Value2tax *  $login222[0]['PST'])/100;
    $hst = ($Value2tax *  $login222[0]['HST'])/100;
    $gst = ($Value2tax *  $login222[0]['GST'])/100;
    $fst = ($Value2tax *  $login222[0]['FST'])/100;


// TotalTax =  PST + GST + HST + FST

    $TotalTax = $pst + $hst + $gst + $fst;


// DriverAmount  = (BaseFare * DriverPercentage) / 100

    $DriverAmount = ($Base_Fare * $DriverPercentage)/100;

// AdminAmount  = BaseFare  - DriverAmount

   $AdminAmount = $Base_Fare -  $DriverAmount;

// Admin Amount =   Admin Amount + CityFeePerKilometer + RiderFeeFlatRate

    $AdminAmount = $AdminAmount + $dd + $gg;    

// TotalAmount =  AdminAmount + DriverAmount + TotalTax

    $TotalAmount = $AdminAmount + $DriverAmount + $TotalTax;

// DriverSettlement = DriverAmount + TotalTax

   $DriverSettlement = $DriverAmount + $TotalTax;



                          $ressult['result']=$login1[0];


                          $ressult['result']['total_fare']=number_format($TotalAmount, 2);

                          $ressult['result']['base_fare']=number_format($Base_Fare, 2);

                          $ressult['result']['tax_fare']=number_format($TotalTax, 2);

                          $ressult['result']['driver_fare']=number_format($DriverAmount, 2);

                          $ressult['result']['DriverSettlement']=number_format($DriverSettlement, 2);

                          $ressult['result']['admin_fare']=number_format($AdminAmount, 2);

                          $ressult['result']['RatePerKilometer']=$login111[0]['RatePerKilometer'] .'*'. $login[0]['distance'].' = '.number_format($aa, 2);
                          $ressult['result']['WaitTimePerMinute']=$login111[0]['WaitTimePerMinute'] .'*'. $login[0]['waiting_time'].' = '.number_format($bb, 2);
                          $ressult['result']['RatePerMinute']=$login111[0]['RatePerMinute'] .'*'. $login[0]['duration'].' = '.number_format($cc, 2);
                          $ressult['result']['CityFeePerKilometer']=$login111[0]['CityFeePerKilometer'].'*'. $login[0]['distance'].' = '.number_format($dd, 2);
                          $ressult['result']['BaseFeeFlatRate']=$login111[0]['BaseFeeFlatRate'].' = '.number_format($ee, 2);
                          $ressult['result']['BookingFeeFlatRate']=$login111[0]['BookingFeeFlatRate'].' = '.number_format($ff, 2);
                          $ressult['result']['RiderFeeFlatRate']=$login111[0]['RiderFeeFlatRate'].' = '.number_format($gg, 2);



                          $ressult['result']['PST']=number_format($pst, 2);

                          $ressult['result']['HST']=number_format($hst, 2);

                          $ressult['result']['GST']=number_format($gst, 2);

                          $ressult['result']['FST']=number_format($fst, 2);

                          $ressult['message']='successful';
                          $ressult['status']='1';
                          $json = $ressult;                        
                                     
                         

      }
      else {
                          $ressult['result']='Data Not Found';
                          $ressult['message']='unsuccessful';
                          $ressult['status']='0';
                          $json = $ressult;
      }

      header('Content-type: application/json');
      echo json_encode($json);

    }

   
/************* total_fare1 function *************/



     public function total_fare1(){

               $arr_get = ['id'=>$this->input->get_post('request_id'),'status'=>'Complete'];

    $arr_data = [

            'distance'=>$this->input->get_post('distance') ,
            'duration'=>$this->input->get_post('duration') ,   
            'waiting_time'=>$this->input->get_post('waiting_time') 
            ];
     
     $login = $this->webservice_model->get_where('user_request',$arr_get);
               
      if ($login) {
                         
                          $id = $this->webservice_model->update_data('user_request',$arr_data,$arr_get);
        
                          $login1 = $this->webservice_model->get_where('user_request',$arr_get);

                          $arr_get11 = ['id'=>$login1[0]['accept_driver_id']];
                          $login11 = $this->webservice_model->get_where('drivers',$arr_get11);

                          $arr_get111 = ['name'=>$login1[0]['pick_city']];
                          $login111 = $this->webservice_model->get_where('city',$arr_get111);

                          $arr_get222 = ['id'=>$login111[0]['state_id']];
                          $login222 = $this->webservice_model->get_where('states',$arr_get222);

                          



                          $login111[0]['RatePerKilometer'];
                          $login111[0]['RatePerMinute'];
                          $login111[0]['WaitTimePerMinute'];
                          $login111[0]['CityFeePerKilometer'];
                          $login111[0]['BaseFeeFlatRate'];
                          $login111[0]['BookingFeeFlatRate'];
                          $login111[0]['RiderFeeFlatRate'];

                          $DriverPercentage = $login111[0]['DriverPercentage'];


                          $login1[0]['duration'];
                          $login1[0]['waiting_time'];
                          $login1[0]['distance'];


                          $aa = $login111[0]['RatePerKilometer'] * $login1[0]['distance'];
                          $bb = $login111[0]['WaitTimePerMinute'] * $login1[0]['waiting_time'];
                          $cc = $login111[0]['RatePerMinute'] * $login1[0]['duration'];
                          $dd = $login111[0]['CityFeePerKilometer'] * $login1[0]['distance'];
                          $ee = $login111[0]['BaseFeeFlatRate'];
                          $ff = $login111[0]['BookingFeeFlatRate'];
                          $gg = $login111[0]['RiderFeeFlatRate'];

                          



                         


                          $total = $aa + $bb + $cc  + $ee + $ff ;

                          $total_aft_per = ($total * 0.5)/100 ;

                          $f_total = $total + $total_aft_per;

                         
           
                          $login222[0]['PST'];
                          $login222[0]['HST'];
                          $login222[0]['GST'];
                          $login222[0]['FST'];


                          $pst = ($f_total *  $login222[0]['PST'])/100;
                          $hst = ($f_total *  $login222[0]['HST'])/100;
                          $gst = ($f_total *  $login222[0]['GST'])/100;
                          $fst = ($f_total *  $login222[0]['FST'])/100;

                          $f_total = $f_total + $pst + $hst + $gst + $fst;

                          $driverTotal = ($f_total * $DriverPercentage) / 100 ;
 
                          $admin_fare =  $f_total - $driverTotal;
 
                          $admin_fare =  $admin_fare + $dd + $gg;

$f_total = $f_total + $dd +$gg;

                          $ressult['result']=$login1[0];


                          $ressult['result']['total_fare']=number_format($f_total, 2);

                          $ressult['result']['base_fare']=number_format($total, 2);

                          $ressult['result']['tax_fare']=number_format($total_aft_per, 2);

                          $ressult['result']['driver_fare']=number_format($driverTotal, 2);

                          $ressult['result']['admin_fare']=number_format($admin_fare, 2);

                          $ressult['result']['RatePerKilometer']=$login111[0]['RatePerKilometer'] .'*'. $login[0]['distance'].' = '.number_format($aa, 2);
                          $ressult['result']['WaitTimePerMinute']=$login111[0]['WaitTimePerMinute'] .'*'. $login[0]['waiting_time'].' = '.number_format($bb, 2);
                          $ressult['result']['RatePerMinute']=$login111[0]['RatePerMinute'] .'*'. $login[0]['duration'].' = '.number_format($cc, 2);
                          $ressult['result']['CityFeePerKilometer']=$login111[0]['CityFeePerKilometer'].'*'. $login[0]['distance'].' = '.number_format($dd, 2);
                          $ressult['result']['BaseFeeFlatRate']=$login111[0]['BaseFeeFlatRate'].' = '.number_format($ee, 2);
                          $ressult['result']['BookingFeeFlatRate']=$login111[0]['BookingFeeFlatRate'].' = '.number_format($ff, 2);
                          $ressult['result']['RiderFeeFlatRate']=$login111[0]['RiderFeeFlatRate'].' = '.number_format($gg, 2);



                          $ressult['result']['PST']=number_format($pst, 2);

                          $ressult['result']['HST']=number_format($hst, 2);

                          $ressult['result']['GST']=number_format($gst, 2);

                          $ressult['result']['FST']=number_format($fst, 2);

                          $ressult['message']='successful';
                          $ressult['status']='1';
                          $json = $ressult;                        
                                     
                         

      }
      else {
                          $ressult['result']='Data Not Found';
                          $ressult['message']='unsuccessful';
                          $ressult['status']='0';
                          $json = $ressult;
      }

      header('Content-type: application/json');
      echo json_encode($json);

    }

  
/************* final_user_fare function *************/



     public function final_user_fare(){

               $arr_get = ['id'=>$this->input->get_post('request_id'),'status'=>'Complete'];

    
     $login = $this->webservice_model->get_where('user_request',$arr_get);
               
      if ($login) {
                         

                          $arr_get11 = ['id'=>$login[0]['accept_driver_id']];
                          $login11 = $this->webservice_model->get_where('drivers',$arr_get11);

                          $arr_get111 = ['name'=>$login[0]['pick_city']];
                          $login111 = $this->webservice_model->get_where('city',$arr_get111);

                          $arr_get222 = ['id'=>$login111[0]['state_id']];
                          $login222 = $this->webservice_model->get_where('states',$arr_get222);

                          $login111[0]['RatePerKilometer'];
                          $login111[0]['RatePerMinute'];
                          $login111[0]['WaitTimePerMinute'];
                          $login111[0]['CityFeePerKilometer'];
                          $login111[0]['BaseFeeFlatRate'];
                          $login111[0]['BookingFeeFlatRate'];
                          $login111[0]['RiderFeeFlatRate'];

                          $DriverPercentage = $login111[0]['DriverPercentage'];


                          $login[0]['duration'];
                          $login[0]['waiting_time'];
                          $login[0]['distance'];


                          $aa = $login111[0]['RatePerKilometer'] * $login[0]['distance'];
                          $bb = $login111[0]['WaitTimePerMinute'] * $login[0]['waiting_time'];
                          $cc = $login111[0]['RatePerMinute'] * $login[0]['duration'];
                          $dd = $login111[0]['CityFeePerKilometer'] * $login[0]['distance'];
                          $ee = $login111[0]['BaseFeeFlatRate'];
                          $ff = $login111[0]['BookingFeeFlatRate'];
                          $gg = $login111[0]['RiderFeeFlatRate'];

                          $login222[0]['PST'];
                          $login222[0]['HST'];
                          $login222[0]['GST'];
                          $login222[0]['FST'];
                          

// Base Fare =  RatePerKilometer + RatePerMinute +  WaitTimePerMinute + BaseFeeFlatRate +  BookingFeeFlatRate

    $Base_Fare =    $aa + $cc + $bb + $ee + $ff;    
         
// Othertaxed = CityFeePerKilometer(40.60) + RiderFeeFlatRate(0.35)

    $Othertaxed = $dd + $gg;

// Value2tax = BaseFare + Othertaxed
  
   $Value2tax = $Base_Fare + $Othertaxed;


// PST Charge : (50  *   98.20) /100  =  49.10


    $pst = ($Value2tax *  $login222[0]['PST'])/100;
    $hst = ($Value2tax *  $login222[0]['HST'])/100;
    $gst = ($Value2tax *  $login222[0]['GST'])/100;
    $fst = ($Value2tax *  $login222[0]['FST'])/100;


// TotalTax =  PST + GST + HST + FST

    $TotalTax = $pst + $hst + $gst + $fst;


// DriverAmount  = (BaseFare * DriverPercentage) / 100

    $DriverAmount = ($Base_Fare * $DriverPercentage)/100;

// AdminAmount  = BaseFare  - DriverAmount

   $AdminAmount = $Base_Fare -  $DriverAmount;

// Admin Amount =   Admin Amount + CityFeePerKilometer + RiderFeeFlatRate

    $AdminAmount = $AdminAmount + $dd + $gg;    

// TotalAmount =  AdminAmount + DriverAmount + TotalTax

    $TotalAmount = $AdminAmount + $DriverAmount + $TotalTax;

// DriverSettlement = DriverAmount + TotalTax

   $DriverSettlement = $DriverAmount + $TotalTax;



                          $ressult['result']=$login[0];


                          $ressult['result']['total_fare']=number_format($TotalAmount, 2);

                          $ressult['result']['base_fare']=number_format($Base_Fare, 2);

                          $ressult['result']['tax_fare']=number_format($TotalTax, 2);

                          $ressult['result']['driver_fare']=number_format($DriverAmount, 2);

                          $ressult['result']['DriverSettlement']=number_format($DriverSettlement, 2);

                          $ressult['result']['admin_fare']=number_format($AdminAmount, 2);

                          $ressult['result']['RatePerKilometer']=$login111[0]['RatePerKilometer'] .'*'. $login[0]['distance'].' = '.number_format($aa, 2);
                          $ressult['result']['WaitTimePerMinute']=$login111[0]['WaitTimePerMinute'] .'*'. $login[0]['waiting_time'].' = '.number_format($bb, 2);
                          $ressult['result']['RatePerMinute']=$login111[0]['RatePerMinute'] .'*'. $login[0]['duration'].' = '.number_format($cc, 2);
                          $ressult['result']['CityFeePerKilometer']=$login111[0]['CityFeePerKilometer'].'*'. $login[0]['distance'].' = '.number_format($dd, 2);
                          $ressult['result']['BaseFeeFlatRate']=$login111[0]['BaseFeeFlatRate'].' = '.number_format($ee, 2);
                          $ressult['result']['BookingFeeFlatRate']=$login111[0]['BookingFeeFlatRate'].' = '.number_format($ff, 2);
                          $ressult['result']['RiderFeeFlatRate']=$login111[0]['RiderFeeFlatRate'].' = '.number_format($gg, 2);



                          $ressult['result']['PST']=number_format($pst, 2);

                          $ressult['result']['HST']=number_format($hst, 2);

                          $ressult['result']['GST']=number_format($gst, 2);

                          $ressult['result']['FST']=number_format($fst, 2);

                          $ressult['result']['RequestPay']=$login111[0]['RequestPay'];

                          $ressult['message']='successful';
                          $ressult['status']='1';
                          $json = $ressult;                      
                                     
                         

      }
      else {
                          $ressult['result']='Data Not Found';
                          $ressult['message']='unsuccessful';
                          $ressult['status']='0';
                          $json = $ressult;
      }

      header('Content-type: application/json');
      echo json_encode($json);

    }
  
    

/************* add_fianl_payment function *************/



    public function add_fianl_payment(){

         

    $arr_data = [
            'request_id'=>$this->input->get_post('request_id'),
            'driver_id'=>$this->input->get_post('driver_id') ,  
            'total_fare'=>$this->input->get_post('total_fare') ,
            'driver_fare'=>$this->input->get_post('driver_fare') , 
            'PST'=>$this->input->get_post('PST') , 
            'HST'=>$this->input->get_post('HST') , 
            'GST'=>$this->input->get_post('GST') , 
            'FST'=>$this->input->get_post('FST') ,   
            'tax'=>$this->input->get_post('tax') ,   
            'DriverSettlement'=>$this->input->get_post('DriverSettlement') ,   
            'admin_fare'=>$this->input->get_post('admin_fare')         
            ];
     

      

      $id = $this->webservice_model->insert_data('final_payment',$arr_data);

      if ($id=="") {
        $json = ['result'=>'unsuccessfull','status'=>0,'message'=>'data not found'];
      }else{
        
              
        $arr_gets = ['id'=>$id];
        $login = $this->webservice_model->get_where('final_payment',$arr_gets);    

        $ressult['result']=$login[0];
        $ressult['message']='successfull';
        $ressult['status']='1';
        $json = $ressult;
      }

      header('Content-type:application/json');
      echo json_encode($json);

    }



/************* estimate_fare function *************/



     public function estimate_fare(){

               $arr_get = ['name'=>$this->input->get_post('city')];

    $arr_data = [

            'distance'=>$this->input->get_post('distance') ,
            'duration'=>$this->input->get_post('duration') ,   
            'waiting_time'=>$this->input->get_post('waiting_time') 
            ];
     
     $login111 = $this->webservice_model->get_where('city',$arr_get);
               
      if ($login111) {
                         
                          $arr_get222 = ['id'=>$login111[0]['state_id']];
                          $login222 = $this->webservice_model->get_where('states',$arr_get222);
        
                          $login111[0]['RatePerKilometer'];
                          $login111[0]['RatePerMinute'];
                          $login111[0]['WaitTimePerMinute'];
                          $login111[0]['CityFeePerKilometer'];
                          $login111[0]['BaseFeeFlatRate'];
                          $login111[0]['BookingFeeFlatRate'];
                          $login111[0]['RiderFeeFlatRate'];

                          $DriverPercentage = $login111[0]['DriverPercentage'];

                          $aa = $login111[0]['RatePerKilometer'] * $arr_data['distance'];
                          $bb = $login111[0]['WaitTimePerMinute'] * $arr_data['waiting_time'];
                          $cc = $login111[0]['RatePerMinute'] * $arr_data['duration'];
                          $dd = $login111[0]['CityFeePerKilometer'] *$arr_data['distance'];
                          $ee = $login111[0]['BaseFeeFlatRate'];
                          $ff = $login111[0]['BookingFeeFlatRate'];
                          $gg = $login111[0]['RiderFeeFlatRate'];

                       


// Base Fare =  RatePerKilometer + RatePerMinute +  WaitTimePerMinute + BaseFeeFlatRate +  BookingFeeFlatRate

    $Base_Fare =    $aa + $cc + $bb + $ee + $ff;    
         
// Othertaxed = CityFeePerKilometer(40.60) + RiderFeeFlatRate(0.35)

    $Othertaxed = $dd + $gg;

// Value2tax = BaseFare + Othertaxed
  
   $Value2tax = $Base_Fare + $Othertaxed;


// PST Charge : (50  *   98.20) /100  =  49.10


    $pst = ($Value2tax *  $login222[0]['PST'])/100;
    $hst = ($Value2tax *  $login222[0]['HST'])/100;
    $gst = ($Value2tax *  $login222[0]['GST'])/100;
    $fst = ($Value2tax *  $login222[0]['FST'])/100;


// TotalTax =  PST + GST + HST + FST

    $TotalTax = $pst + $hst + $gst + $fst;


// DriverAmount  = (BaseFare * DriverPercentage) / 100

    $DriverAmount = ($Base_Fare * $DriverPercentage)/100;

// AdminAmount  = BaseFare  - DriverAmount

   $AdminAmount = $Base_Fare -  $DriverAmount;

// Admin Amount =   Admin Amount + CityFeePerKilometer + RiderFeeFlatRate

    $AdminAmount = $AdminAmount + $dd + $gg;    

// TotalAmount =  AdminAmount + DriverAmount + TotalTax

    $TotalAmount = $AdminAmount + $DriverAmount + $TotalTax;

// DriverSettlement = DriverAmount + TotalTax

   $DriverSettlement = $DriverAmount + $TotalTax;



                          $ressult['result']['total_fare']=number_format($TotalAmount, 2);
                          $ressult['result']['RatePerKilometer']=number_format($aa, 2);
                          $ressult['result']['WaitTimePerMinute']=number_format($bb, 2);
                          $ressult['result']['RatePerMinute']=number_format($cc, 2);
                          $ressult['result']['CityFeePerKilometer']=number_format($dd, 2);
                          $ressult['result']['BaseFeeFlatRate']=number_format($ee, 2);
                          $ressult['result']['BookingFeeFlatRate']=number_format($ff, 2);
                          $ressult['result']['RiderFeeFlatRate']=number_format($gg, 2);

                          $ressult['result']['PST']=number_format($pst, 2);

                          $ressult['result']['HST']=number_format($hst, 2);

                          $ressult['result']['GST']=number_format($gst, 2);

                          $ressult['result']['FST']=number_format($fst, 2);

                          $ressult['message']='successful';
                          $ressult['status']='1';
                          $json = $ressult;                      
                         

      }
      else {
                          $ressult['result']='Data Not Found';
                          $ressult['message']='unsuccessful';
                          $ressult['status']='0';
                          $json = $ressult;
      }

      header('Content-type: application/json');
      echo json_encode($json);

    }




/************* get_share_ride_estimate_fare function *************/



     public function get_share_ride_estimate_fare(){

               $arr_get = ['name'=>$this->input->get_post('country_name')];

    $arr_data = [

            'distance'=>$this->input->get_post('distance') 
            ];
     
     $login111 = $this->webservice_model->get_where('country',$arr_get);
               
      if ($login111) {
                         
                          $arr_get222 = ['Country'=>$login111[0]['id']];
                          $login222 = $this->webservice_model->get_where('travelrate',$arr_get222);
        
                          

                        
                          $RatePerKM = $login222[0]['RatePerKM'];
                          $distance = $arr_data['distance'];
                       
                          $Fare =    $RatePerKM * $distance;    


                          $ressult['result']['Fare']=number_format($Fare, 2);

                          $ressult['message']='successful';
                          $ressult['status']='1';
                          $json = $ressult;                      
                         

      }
      else {
                          $ressult['result']='Data Not Found';
                          $ressult['message']='unsuccessful';
                          $ressult['status']='0';
                          $json = $ressult;
      }

      header('Content-type: application/json');
      echo json_encode($json);

    }




function get_paykey($fields) {

       $curl = curl_init();
       

      curl_setopt_array($curl, array(
        CURLOPT_URL => "https://api-3t.paypal.com/nvp",
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_ENCODING => "",
        CURLOPT_MAXREDIRS => 10,
        CURLOPT_TIMEOUT => 30,
        CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
        CURLOPT_CUSTOMREQUEST => "POST",
        CURLOPT_POSTFIELDS => $fields,
        CURLOPT_HTTPHEADER => array(
          "cache-control: no-cache",
          "content-type: application/x-www-form-urlencoded",
          "postman-token: b38cc362-9b33-082b-c86b-4623affaee64"
        ),
      ));

      $response = curl_exec($curl);
      $err = curl_error($curl);

      curl_close($curl);

      if ($err) {
        return "error";
      } else {
        return $response;
      }


  }



/************* get_ride_estimate_by_seat function *************/



     public function get_ride_estimate_by_seat(){

               $user_id = $this->input->get_post('user_id', TRUE);
               $ride_id = $this->input->get_post('ride_id', TRUE);

               $arr_get = ['id'=>$ride_id];

    $arr_data = [

            'no_of_seat'=>$this->input->get_post('no_of_seat') 
            ];
     
     $login111 = $this->webservice_model->get_where('travel',$arr_get);
               
      if ($login111) {
                         


                          $PaySocialRydeAccount = $this->webservice_model->get_where('PaySocialRydeAccount',['country'=>$login111[0]['country_name']]);
                          $per = $PaySocialRydeAccount[0]['percentage2socialryde'];
                          $AmtPerSeat = $login111[0]['AmtPerSeat'];
                          
                          $no_of_seat = $arr_data['no_of_seat'];
                       
                          $riderFare =    $no_of_seat * $AmtPerSeat;  

                          $adminFare = ($riderFare * $per)/100;

                          $totalFare =    $riderFare + $adminFare;    



                     /*
                          $AmtPerSeat = $login111[0]['AmtPerSeat'];
                          
                          $no_of_seat = $arr_data['no_of_seat'];
                       
                          $totalFare =    $no_of_seat * $AmtPerSeat;    

                          $adminFare = ($totalFare * 20)/100;
                          $riderFare = ($totalFare * 80)/100;*/

                          $userAcount = $this->webservice_model->get_where('PaymentAccount',['user_id'=>$login111[0]['user_id']]);
                          $userAcount = $userAcount[0]['email'];
   $retun_success = 'http://socialryde.cc/SocialRyde/payment.php?adminFare='.$adminFare.'&riderFare='.$riderFare.'&totalFare='.$totalFare.''; 
       if($login111[0]['country_name'] == 'Canada') {                 

$marchantId =  "weeconnectu@live.com";
    $fields =  "USER=weeconnectu_api1.live.com&PWD=K3XV7486EYZQ7K5S&SIGNATURE=AKCIk0EU.Nrneq7UzItCsZb2kmrYA7cursbo-IFpUQdqspjD6TncLWOn&METHOD=SetExpressCheckout&CANCELURL=http://shopinhome.com/cancel.php&RETURNURL=http://socialryde.cc/SocialRyde/payment.php&VERSION=93&PAYMENTREQUEST_0_AMT=".$adminFare."&PAYMENTREQUEST_0_PAYMENTACTION=Order&PAYMENTREQUEST_0_SELLERPAYPALACCOUNTID=".$marchantId."&PAYMENTREQUEST_0_PAYMENTREQUESTID=0&PAYMENTREQUEST_0_CURRENCYCODE=USD";

}else {

$marchantId =  "ttloads@outlook.com";
    $fields =  "USER=ttloads_api1.outlook.com&PWD=PKKF3Q6NLLXD6QCT&SIGNATURE=ANoCqoLac3osCpiMZvq1GoIReW1vANt2SFTMwcZZg7N0KfoPE-gPcSCA&METHOD=SetExpressCheckout&CANCELURL=http://shopinhome.com/cancel.php&RETURNURL=http://socialryde.cc/SocialRyde/payment.php&VERSION=93&PAYMENTREQUEST_0_AMT=".$adminFare."&PAYMENTREQUEST_0_PAYMENTACTION=Order&PAYMENTREQUEST_0_SELLERPAYPALACCOUNTID=".$marchantId."&PAYMENTREQUEST_0_PAYMENTREQUESTID=0&PAYMENTREQUEST_0_CURRENCYCODE=USD";

  
}
  $i=1;
  
        $fields = $fields."&PAYMENTREQUEST_pay_".$i."_AMT=".$riderFare."&PAYMENTREQUEST_pay_".$i."_PAYMENTACTION=Order&PAYMENTREQUEST_pay_".$i."_SELLERPAYPALACCOUNTID=".$userAcount."&PAYMENTREQUEST_pay_".$i."_PAYMENTREQUESTID=pay_".$i."&PAYMENTREQUEST_pay_".$i."_CURRENCYCODE=USD";  


  $fetch = $this->get_paykey($fields);
 
 //



      //echo urldecode($fetch); die;

  $exp = explode("&", $fetch); 
  $exp1 = explode("=", $exp[0]); 
 

   
  $key = $exp1[1];

  
  



                          $ressult['result']['retun_success']=$retun_success;
                          $ressult['result']['payKey']=$key;
                          $ressult['result']['country_name']=$login111[0]['country_name'];

                          $ressult['result']['totalFare']=number_format($totalFare, 2);
                          $ressult['result']['adminFare']=number_format($adminFare, 2);
                          $ressult['result']['riderFare']=number_format($riderFare, 2);

                          $ressult['message']='successful';
                          $ressult['status']='1';
                          $json = $ressult;                      
                         

      }
      else {
                          $ressult['result']='Data Not Found';
                          $ressult['message']='unsuccessful';
                          $ressult['status']='0';
                          $json = $ressult;
      }

      header('Content-type: application/json');
      echo json_encode($json);

    }


/*************************** chat model start here for two table *****************************/



  /************************ insert_chat_driver ************************/
  public function insert_chat_driver()
  {


    $arr_data = array(
      'sender_id' =>$this->input->get_post('sender_id', TRUE),
      'receiver_id'=>$this->input->get_post('receiver_id', TRUE),
      'chat_message' =>$this->input->get_post('chat_message',TRUE),
      'user_id'=>$this->input->get_post('user_id',TRUE),
      'driver_id'=>$this->input->get_post('driver_id',TRUE),


      'type'=>$this->input->get_post('type',TRUE)
    );
   $type = $arr_data['type'];
       // print_r($arr_data);die;



                if(isset($_FILES['chat_image']))
               {
                  
                    $user_img = "CHAT_IMG_" . rand(1, 10000) . ".png";
                    move_uploaded_file($_FILES['chat_image']['tmp_name'], "assets/images/" . $user_img);
                    $arr_data['chat_image'] = $user_img;

                }





if($type == 'driver')
     
{
//echo"driver";
             
$user_r = $this->webservice_model->get_where('users', ['id'=>$arr_data['receiver_id']]);
$user = $this->webservice_model->get_where('drivers', ['id'=>$arr_data['sender_id']]);

}

 if($type == 'user')
{
 
//echo"user";
 $user = $this->webservice_model->get_where('users', ['id'=>$arr_data['sender_id']]);
 $user_r = $this->webservice_model->get_where('drivers', ['id'=>$arr_data['receiver_id']]);
}

 $res = $this->webservice_model->insert_data('chat_detail',$arr_data);

    if ($res != "") {
      $single_data = array(
        'id' => $res
      );
      $fetch = $this->webservice_model->get_where('chat_detail', $single_data);

     //print_r($fetch);die;

     
      $fetch[0]['chat_image'] = $fetch[0]['chat_image'];
      
      $user_message_apk = array(
            "message" => array(
              "result" => "successful",
              "key" => "You have a new chat message",
              "message" => $arr_data['chat_message'],
              "userid" => $user[0]['id'],
              //"username" => $user_r[0]['user_name'],
              //"userimage" => $user_r[0]['user_image'],
              "chat_image" => $fetch[0]['chat_image']
                                                        //"date"=> date('Y-m-d h:i:s')
            )
          );


 $register_userid = array($user_r[0]['register_id']);

            $this->webservice_model->driver_apk_notification($register_userid, $user_message_apk);

          //  print_r($register_userid);

      $fetch[0]['result'] = "successful";
      $json = $fetch[0];
    }
    else {
      $json = array(
        "result" => "unsuccessful"
      );
    }
                
     header('Content-type: application/json');
     echo json_encode($json);

  }


  /************* get_chat_driver *************/
  public

  function get_chat_driver()
  {

       
        $sender_id = $this->input->get_post('sender_id', TRUE);
        $receiver_id = $this->input->get_post('receiver_id', TRUE);        
        $type=$this->input->get_post('type', TRUE);



      $this->db->where('sender_id', $sender_id);
      $this->db->where('receiver_id', $receiver_id);
      $this->db->or_where('sender_id', $receiver_id); 
      $this->db->or_where('receiver_id', $sender_id);
      $this->db->order_by('id', 'DESC');
                        
      $info = $this->db->get('chat_detail');
                       
      $chat = $info->result_array();
       

  // print_r($chat);die;
    if ($chat)
    {
             foreach($chat as $val)
             {
                        
                    if($type=="driver")
                     {

                        $sender = $this->webservice_model->get_where('drivers',['id'=>$val['sender_id']]);
                         $receiver = $this->webservice_model->get_where('users',['id'=>$val['receiver_id']]);
                      
                      $val['result'] = "successful";
                      $val['sender_detail'] = $sender[0];
                      $val['receiver_detail'] = $receiver[0];
                      $json[] = $val;
                      $arr_where = ['sender_id'=>$sender_id,'receiver_id'=>$receiver_id]; 
                        $this->webservice_model->update_data('chat_detail', ['status'=>'SEEN'], $arr_where);
                     }
                     else
                     {

                        $sender = $this->webservice_model->get_where('users', ['id'=>$val['sender_id']]);
                        $receiver = $this->webservice_model->get_where('drivers', ['id'=>$val['receiver_id']]);
                        
                         $val['chat_image']=$val['chat_image'];

                        $val['result'] = "successful";
                        $val['sender_detail'] = $sender[0];
                        $receiver[0]['image1']=SITE_URL.'uploads/images/'.$receiver[0]['image1'];

                        $val['receiver_detail'] = $receiver[0];
                        $json[] = $val;
                        $arr_where = ['sender_id'=>$sender_id,'receiver_id'=>$receiver_id]; 
                        $this->webservice_model->update_data('chat_detail', ['status'=>'SEEN'], $arr_where);

                    }

 
      
            }
                      

                     


    }
    else
    {
      $json[] = array(
        "result" => "unsuccessful"
      );
    }

    header('Content-type: application/json');
    echo json_encode($json);
  }





   function  getchat_driver()
   {

     
        $sender_id = $this->input->get_post('sender_id', TRUE);
        $receiver_id = $this->input->get_post('receiver_id', TRUE);
        $driver_id= $this->input->get_post('driver_id', TRUE);
        $user_id= $this->input->get_post('user_id', TRUE);        
        $type=$this->input->get_post('type', TRUE);

           

      
       $users="users as t1";
       $drivers="drivers as t2";
       $chat="chat_detail as t3";


       
      $Rt= $this->webservice_model->update_data('chat_detail',['status'=>'SEEN'],['driver_id'=>$driver_id,"user_id"=>$user_id]);


       

     $info=$this->webservice_model->get($chat,"t3.*",['t3.driver_id'=>$driver_id,"t3.user_id"=>$user_id],2,[$users,$drivers],["t1.id=t3.user_id","t2.id=t3.driver_id"]);

   for($i=0;$i<count($info);$i++)
     {

              

   if($info[$i]['sender_id']==$driver_id)
   {
   $sender=$this->webservice_model->get('drivers',"*",["id"=>$info[$i]['driver_id']]);
   for($j=0;$j<count($sender);$j++)
    {
      
        $info[$i]['driver']=$sender[0]; 


    }
   }

   else
   {

   $sender=$this->webservice_model->get('users',"*",["id"=>$info[$i]['user_id']]);
 for($j=0;$j<count($sender);$j++)
    {
      
        $info[$i]['user']=$sender[0];


    }

   }

 
   

  if($info[$i]['receiver_id']==$user_id)
   {
   $rec=$this->webservice_model->get('users',"*",["id"=>$info[$i]['user_id']]);
   for($k=0;$k<count($rec);$k++)
    {
      
        $info[$i]['user']=$rec[0]; 


    }

  }
 else
  {
   $rec=$this->webservice_model->get('drivers',"*",["id"=>$info[$i]['driver_id']]);
    for($k=0;$k<count($rec);$k++)
    {
      
        $info[$i]['driver']=$rec[0]; 


    }


  }

   

  }


   if($info)

     {
       $json['result'] =$info;
      
        $json['message'] = 'successful';
        $json['status']=1;
      
  }

   else
  {

         $json['result'] = "data not found";
        $json['message'] = 'unsuccessful';
        $json['status']=0;
     

   }

  echo json_encode($json);
      


   }


        /************* get_conversation_driver *************/
  public

  function get_conversation_driver()
  {

        $receiver_id = $this->input->get_post('receiver_id', TRUE);
        $type= $this->input->get_post('type', TRUE);
        $this->db->where("(receiver_id= '$receiver_id') OR (sender_id = '$receiver_id')");
      
                        
        $info = $this->db->get('chat_detail');
       
                       
        $chat = $info->result_array();

        $arr = [];

    if ($chat)
    {
      foreach($chat as $val)
      {
        if($type=="driver")
		 {
        if ($val['sender_id']==$receiver_id) 
		{
          if (in_array($val['receiver_id'], $arr)) {
            
          }else{
            $arr[] = $val['receiver_id'];
            $user = $this->webservice_model->get_where('drivers', ['id'=>$val['receiver_id']]);
        
           // $user[0]['image'] =$user[0]['user_image'];
            $json[] = $user[0];
          }

        }
		else
		{
          if (in_array($val['sender_id'], $arr)) {
            
          }else{
                                              
            $arr[] = $val['sender_id'];
            $user = $this->webservice_model->get_where('users', ['id'=>$val['sender_id']]);
            
            //$user[0]['image'] = SITE_URL . "uploads/images/" . $user[0]['user_image'];
            $json[] = $user[0];
          }
        }
        }
		else 
		{
		
		if ($val['sender_id']==$receiver_id) 
		{
          if (in_array($val['receiver_id'], $arr)) {
            
          }else{
            $arr[] = $val['receiver_id'];
            $user = $this->webservice_model->get_where('users', ['id'=>$val['receiver_id']]);
        
            //$user[0]['image'] =$user[0]['user_image'];
            $json[] = $user[0];
          }

        }
		else
		{
          if (in_array($val['sender_id'], $arr)) {
            
          }else
            {
                                              
            $arr[] = $val['sender_id'];
            $user = $this->webservice_model->get_where('drivers', ['id'=>$val['sender_id']]);
            
            //$user[0]['image'] =$user[0]['user_image'];
            $json[] = $user[0];
          }
        }
		
		
		
		
		
		}
        
        
      }

      
    }
    else
    {
      $json = array(
        "result" => "data not found",
        "message" => "unsuccess",
        "status" => "0"
      );
      header('Content-type: application/json');
      echo json_encode($json);
      die;
    }

                
                foreach($json as $key){    
                    
                   $where = "sender_id = '".$key['id']."' AND receiver_id = '".$receiver_id."' AND status = 'NOTSEEN' ORDER BY id DESC";

                    $msg = $this->webservice_model->get_where('chat_detail', $where);
if($msg){
  $key['no_of_message'] = count($msg);
}else{
  $key['no_of_message'] = 0;
}

                 $where1 = "(sender_id = '".$key['id']."' AND receiver_id = '".$receiver_id."') OR (receiver_id = '".$key['id']."' AND sender_id = '".$receiver_id."') ORDER BY id DESC";

                    $msg1 = $this->webservice_model->get_where('chat_detail', $where1);
                     
                      
                  if($user){
                    //$key['no_of_message'] = count($msg);
                    $key['last_message'] = $msg1[0]['chat_message'];
                    $key['date'] = $msg1[0]['date'];
                    //$key['time_ago'] = $this->webservice_model->humanTiming(strtotime($msg1[0]['date']))." ago";
                    $key['sender_id'] = $key['id'];
                    $key['receiver_id'] = $receiver_id;
                    $message[] = $key;
                  }else{
                    //$key['no_of_message'] = 0;
                    $message[] = $key;
                  }

                    
                }
 
                $data['result'] = $message;
                $data['message'] = "success";
                $data['status'] = 1;


    header('Content-type: application/json');
    echo json_encode($data);
  }



   function  getconversation123() 
   {
    
    $teacher_id= $this->input->get_post('teacher_id', TRUE);

    
       $childtable="chc_childrens as t1";
       $teachertable="chc_teachers as t2";
       $chat="chat_detail as t3";
  

$info=$this->webservice_model->get($chat,'t3.child_id,t3.chat_message,t3.chat_image,t3.date,t3.type,t1.child_name,t1.parentname,t1.email,t1.image',['t3.teacher_id'=>$teacher_id],2,[$childtable,$teachertable],["t1.child_id=t3.child_id","t2.id=t3.teacher_id"],"","","","t3.child_id");


  
  
echo json_encode($info);
   
 }



/*************************** for two table chat model end ************************************/


 /*/////////////////////////start chating module for single table /////////////////////////////////////////*/

/************************ insert chat ************************/
/* http://socialryde.cc/SocialRyde/webservice/insert_chat?sender_id=1&receiver_id=2&chat_message=qqqqqqqqq */
public

function insert_chat()
	{
	$arr_data = array(
		'sender_id' => $this->input->get_post('sender_id', TRUE) ,
		'receiver_id' => $this->input->get_post('receiver_id', TRUE) ,
		'chat_message' => $this->input->get_post('chat_message', TRUE)
	);
	if (isset($_FILES['chat_image']))
		{
		$user_img = "CHAT_IMG_" . rand(1, 10000) . ".png";
		move_uploaded_file($_FILES['chat_image']['tmp_name'], "uploads/images/" . $user_img);
		$arr_data['chat_image'] = $user_img;
		}

$receiver_id = $arr_data['receiver_id'];
$sender_id = $arr_data['sender_id'];

$fetch123 = $this->db->query("select * from block_users WHERE (block_by = '$receiver_id' AND block_user_id = '$sender_id') OR (block_by = '$sender_id' AND block_user_id = '$receiver_id') ")->result_array();

if($fetch123){

$json = array(
			"result" => "blocked"

		);
		

	header('Content-type: application/json');
	echo json_encode($json);die;

}

	$res = $this->webservice_model->insert_data('kaise_chat_detail', $arr_data);

	// print_r($arr_data);

	if ($res != "")
		{
		$single_data = array(
			'id' => $res
		);

                 
	$user = $this->webservice_model->get_where('users', ['id' => $arr_data['receiver_id']]);
	$user_r = $this->webservice_model->get_where('users', ['id' => $arr_data['sender_id']]);
	$user_message_apk = array(
		"message" => array(
			"result" => "successful",
			"key" => "You have a new message",
			"message" => $arr_data['chat_message'],
			"chat_image" => $res[0]['chat_image'],
			"userid" => $user_r[0]['id'],
			"reciever_userid" => $user[0]['id'],
			"username" => $user_r[0]['name'] ,
			"userimage" => SITE_URL . "uploads/images/" . $user_r[0]['image'],
			"date" => date('Y-m-d h:i:s')
		)
	);
	$register_userid = array(
		$user[0]['register_id']
	);
	$this->webservice_model->user_apk_notification($register_userid, $user_message_apk);


		$fetch = $this->webservice_model->get_where('kaise_chat_detail', $single_data);
		$fetch[0]['chat_image'] = SITE_URL . "uploads/images/" . $fetch[0]['chat_image'];
		$fetch[0]['result'] = "successful";
		$json = $fetch[0];
		}
	  else
		{
		$json = array(
			"result" => "unsuccessful"
		);
		}

	header('Content-type: application/json');
	echo json_encode($json);
	}


/************* get chat *************/

/* http://socialryde.cc/SocialRyde/webservice/get_chat?sender_id=2&receiver_id=1 */

public

function get_chat()
	{
	$sender_id = $this->input->get_post('sender_id', TRUE);
	$receiver_id = $this->input->get_post('receiver_id', TRUE);
	$this->db->where('sender_id', $sender_id);
	$this->db->where('receiver_id', $receiver_id);
	$this->db->or_where('sender_id', $receiver_id);
	$this->db->where('receiver_id', $sender_id);
	$this->db->order_by('id', 'DESC');
	$info = $this->db->get('kaise_chat_detail');
	$chat = $info->result_array();
	if ($chat)
		{
		$i = 0;
		foreach($chat as $val)
			{
			$sender = $this->webservice_model->get_where('users', ['id' => $val['sender_id']]);
			$receiver = $this->webservice_model->get_where('users', ['id' => $val['receiver_id']]);
			$sender[0]['sender_image'] = SITE_URL . 'uploads/images/' . $sender[0]['image'];
			$receiver[0]['receiver_image'] = SITE_URL . 'uploads/images/' . $receiver[0]['image'];
			$val['chat_image'] = SITE_URL . 'uploads/images/' . $val['chat_image'];
			$val['result'] = "successful";
			$val['sender_detail'] = $sender[0];
			$val['receiver_detail'] = $receiver[0];
			$exp1 = $exp2 = "";
			$clr_id = $val['clear_chat'];
			$exp = explode(',', $clr_id);
			if (isset($exp[0]))
				{
				$exp1 = $exp[0];
				}

			if (isset($exp[1]))
				{
				$exp2 = $exp[1];
				}

			if ($exp1 != $receiver_id && $exp2 != $receiver_id)
				{
				$i++;
				$json[] = $val;
				} //end if
			}

		if ($i == 0)
			{
			$json[] = array(
				"result" => "unsuccessful"
			);
			}

		$arr_where = ['sender_id' => $sender_id, 'receiver_id' => $receiver_id]; //print_r($arr_where);
		$this->webservice_model->update_data('kaise_chat_detail', ['status' => 'SEEN'], $arr_where);
		}
	  else
		{
		$json[] = array(
			"result" => "unsuccessful"
		);
		}

	header('Content-type: application/json');
	echo json_encode($json);
	}

/************* get conversation *************/

/* http://socialryde.cc/SocialRyde/webservice/get_conversation?receiver_id=2 */

public

function get_conversation()
	{
	$receiver_id = $this->input->get_post('receiver_id', TRUE);
	$this->db->where("(receiver_id = '$receiver_id') OR (sender_id = '$receiver_id') ");
	$info = $this->db->get('kaise_chat_detail');
	$chat = $info->result_array();
	$arr = [];
	if ($chat)
		{
		foreach($chat as $val)
			{
			if ($val['sender_id'] == $receiver_id)
				{
				if (in_array($val['receiver_id'], $arr))
					{
					}
				  else
					{
					$exp1 = $exp2 = "";
					$clr_id = $val['clear_chat'];
					$exp = explode(',', $clr_id);
					if (isset($exp[0]))
						{
						$exp1 = $exp[0];
						}

					if (isset($exp[1]))
						{
						$exp2 = $exp[1];
						}

					if ($exp1 != $receiver_id && $exp2 != $receiver_id)
						{
						$arr[] = $val['receiver_id'];
						$user = $this->webservice_model->get_where('users', ['id' => $val['receiver_id']]);
						$user[0]['image'] = SITE_URL . "uploads/images/" . $user[0]['image'];
						$json[] = $user[0];
						} //end if
					}
				}
			  else
				{
				if (in_array($val['sender_id'], $arr))
					{
					}
				  else
					{
					$exp1 = $exp2 = "";
					$clr_id = $val['clear_chat'];
					$exp = explode(',', $clr_id);
					if (isset($exp[0]))
						{
						$exp1 = $exp[0];
						}

					if (isset($exp[1]))
						{
						$exp2 = $exp[1];
						}

					if ($exp1 != $receiver_id && $exp2 != $receiver_id)
						{
						$arr[] = $val['sender_id'];
						$user = $this->webservice_model->get_where('users', ['id' => $val['sender_id']]);
						$user[0]['image'] = SITE_URL . "uploads/images/" . $user[0]['image'];
						$json[] = $user[0];
						} //end if
					}
				}
			} // end foreach
		}
	  else
		{
		$json = array(
			"result" => "data not found",
			"message" => "unsuccess",
			"status" => "0"
		);
		header('Content-type: application/json');
		echo json_encode($json);
		die;
		}

	if (!isset($json))
		{
		$json = array(
			"result" => "data not found",
			"message" => "unsuccess",
			"status" => "0"
		);
		header('Content-type: application/json');
		echo json_encode($json);
		die;
		}

	foreach($json as $key)
		{
		$where = "sender_id = '" . $key['id'] . "' AND receiver_id = '" . $receiver_id . "' AND status = 'NOTSEEN' ORDER BY id DESC";
		$msg = $this->webservice_model->get_where('kaise_chat_detail', $where);
		if ($msg)
			{
			$key['no_of_message'] = count($msg);
			}
		  else
			{
			$key['no_of_message'] = 0;
			}

		$where1 = "(sender_id = '" . $key['id'] . "' AND receiver_id = '" . $receiver_id . "') OR (receiver_id = '" . $key['id'] . "' AND sender_id = '" . $receiver_id . "') ORDER BY id DESC";
		$msg1 = $this->webservice_model->get_where('kaise_chat_detail', $where1);
		if ($user)
			{

			// $key['no_of_message'] = count($msg);

			$date_time = explode(" ", $msg1[0]['date']);
			$key['last_message'] = $msg1[0]['chat_message'];
			$key['last_image'] = SITE_URL . "uploads/images/" . $msg1[0]['chat_image'];
			$key['lon'] = $msg1[0]['lon'];
			$key['name'] = $msg1[0]['name'];
			$key['contact'] = $msg1[0]['contact'];
			$key['date'] = $date_time[0];
			$key['time'] = $date_time[1];
			$key['time_ago'] = $this->webservice_model->humanTiming(strtotime($msg1[0]['date'])) . " ago";
			$key['sender_id'] = $key['id'];
			$key['receiver_id'] = $receiver_id;
			$message[] = $key;
			}
		  else
			{

			// $key['no_of_message'] = 0;

			$message[] = $key;
			}
		}

	$data['result'] = $message;
	$data['message'] = "success";
	$data['status'] = 1;
	header('Content-type: application/json');
	echo json_encode($data);
	}

/*************** clear_conversation *****************/

/* http://socialryde.cc/SocialRyde/webservice/clear_conversation?sender_id=1&receiver_id=2  */

public

function clear_conversation()
	{
	$sender_id = $this->input->get_post('sender_id', TRUE);
	$receiver_id = $this->input->get_post('receiver_id', TRUE);
	$this->db->where('sender_id', $sender_id);
	$this->db->where('receiver_id', $receiver_id);
	$this->db->or_where('sender_id', $receiver_id);
	$this->db->where('receiver_id', $sender_id);
	$info = $this->db->get('kaise_chat_detail');
	$chat = $info->result_array();
	if ($chat)
		{
		foreach($chat as $val)
			{
			$exp1 = $exp2 = "";
			$clr_id = $val['clear_chat'];
			$exp = explode(',', $clr_id);
			if (isset($exp[0]))
				{
				$exp1 = $exp[0];
				}

			if (isset($exp[1]))
				{
				$exp2 = $exp[1];
				}

			if ($clr_id == "")
				{
				$arr_where = ['id' => $val['id']];
				$this->webservice_model->update_data('kaise_chat_detail', ['clear_chat' => $receiver_id], $arr_where);
				}
			  else
			if ($exp1 == $receiver_id)
				{
				}
			  else
			if ($exp2 == $receiver_id)
				{
				}
			  else
				{
				$arr_where = ['id' => $val['id']];
				$this->webservice_model->update_data('kaise_chat_detail', ['clear_chat' => $exp1 . ',' . $receiver_id], $arr_where);
				}
			}

		$json[] = array(
			"result" => "successful"
		);
		}
	  else
		{
		$json[] = array(
			"result" => "unsuccessful"
		);
		}

	header('Content-type: application/json');
	echo json_encode($json);
	}

/***************delete_conversation *****************/

/* http://socialryde.cc/SocialRyde/webservice/delete_conversation? */

public

function delete_conversation()
	{
	$receiver_id = $this->input->get_post('receiver_id', TRUE);
	$this->db->where('sender_id', $receiver_id);
	$this->db->or_where('receiver_id', $receiver_id);
	$info = $this->db->get('kaise_chat_detail');
	$chat = $info->result_array();
	if ($chat)
		{
		foreach($chat as $val)
			{
			$exp1 = $exp2 = "";
			$clr_id = $val['clear_chat'];
			$exp = explode(',', $clr_id);
			if (isset($exp[0]))
				{
				$exp1 = $exp[0];
				}

			if (isset($exp[1]))
				{
				$exp2 = $exp[1];
				}

			if ($clr_id == "")
				{
				$arr_where = ['id' => $val['id']];
				$this->webservice_model->update_data('kaise_chat_detail', $arr_where, ['clear_chat' => $receiver_id]);
				}
			  else
			if ($exp1 == $receiver_id)
				{
				}
			  else
			if ($exp2 == $receiver_id)
				{
				}
			  else
				{
				$arr_where = ['id' => $val['id']];
				$this->webservice_model->update_data('kaise_chat_detail', $arr_where, ['clear_chat' => $exp1 . ',' . $receiver_id]);
				}
			}

		$json[] = array(
			"result" => "successful"
		);
		}
	  else
		{
		$json[] = array(
			"result" => "unsuccessful"
		);
		}

	header('Content-type: application/json');
	echo json_encode($json);
	}

/**************count seen *****************/

/* http://socialryde.cc/SocialRyde/webservice/get_unseen_count?user_id=6  */
public

function get_unseen_count()
	{
	$id = $this->input->get_post('user_id', TRUE);

	//  $data = $this->db->query("SELECT * FROM users WHERE id = '$id'");

	$query = "SELECT * FROM users WHERE id = '$id' ";
	$sql = mysql_query($query);
	$result = mysql_num_rows($sql);
	if ($result != 0)
		{
		while ($val = mysql_fetch_assoc($sql))
			{
			$query4 = "SELECT * FROM `kaise_chat_detail` WHERE receiver_id = '" . $val['id'] . "' AND `status` = 'NOTSEEN' ";
			$que4 = mysql_query($query4);
			$user_fetch4 = mysql_num_rows($que4);
			$val['unseen_count'] = "$user_fetch4";
			$val['result'] = "successful";
			$json = $val;
			}
		}
	  else
		{
		$json = array(
			"result" => "unsuccessful"
		);
		}

	header('Content-type: application/json');
	echo json_encode($json);
	die;
	}

/*////////////////////////////end chating module for single table///////////////////////////////*/

/*************  get_all_user_ride *************/
    public

    function get_all_user_ride()
    {                     
                          
      $arr_get = ['user_id'=>$this->input->get_post('user_id')];

      $login = $this->webservice_model->get_where('user_request',$arr_get);
               
      if ($login) {
                         
                         foreach($login as  $val)
			 {   
                           
                           $where = ['id'=>$val['accept_driver_id']];
                           $fetch = $this->webservice_model->get_where('drivers',$where);

                           $where1 = ['request_id'=>$val['id']];
                           $fetch1 = $this->webservice_model->get_where('final_payment',$where1);
                          if($fetch1){
                           $val['total_fare'] =  $fetch1[0]['total_fare'];
                           }else{
                           $val['total_fare'] =  '';
                           }

                           $val['driver_name'] =  $fetch[0]['first_name'];
                           $val['driver_phone'] = $fetch[0]['phone'];
                           $val['driver_email'] = $fetch[0]['email'];
                           $val['vehicle_type'] = $fetch[0]['vehicle_type'];

                           $val['driver_image'] = SITE_URL.'uploads/images/'.$fetch[0]['image'];

                           $data[] = $val;

                          }
        
                          
                         
                          $ressult['result']=$data;
                          $ressult['message']='successful';
                          $ressult['status']='1';
                          $json = $ressult;                      
                         

      }
      else {
                          $ressult['result']='Data Not Found';
                          $ressult['message']='unsuccessful';
                          $ressult['status']='0';
                          $json = $ressult;
      }

      header('Content-type: application/json');
      echo json_encode($json);

    }


/*************  get_all_user_ride *************/
    public

    function get_all_driver_ride()
    {                     
                          
      $arr_get = ['accept_driver_id'=>$this->input->get_post('driver_id')];

      $login = $this->webservice_model->get_where('user_request',$arr_get);
               
      if ($login) {
                         
                         foreach($login as  $val)
			 {   
                           
                           $where = ['id'=>$val['user_id']];
                           $fetch = $this->webservice_model->get_where('users',$where);

                           $where1 = ['request_id'=>$val['id']];
                           $fetch1 = $this->webservice_model->get_where('final_payment',$where1);
                          if($fetch1){
                           $val['total_fare'] =  $fetch1[0]['total_fare'];
                           }else{
                           $val['total_fare'] =  '';
                           }

                           $val['user_name'] =  $fetch[0]['name'];
                           $val['user_phone'] = $fetch[0]['phone'];
                           $val['user_email'] = $fetch[0]['email'];


                           $val['user_image'] = SITE_URL.'uploads/images/'.$fetch[0]['image'];

                           $data[] = $val;

                          }
        
                          
                         
                          $ressult['result']=$data;
                          $ressult['message']='successful';
                          $ressult['status']='1';
                          $json = $ressult;                      
                         

      }
      else {
                          $ressult['result']='Data Not Found';
                          $ressult['message']='unsuccessful';
                          $ressult['status']='0';
                          $json = $ressult;
      }

      header('Content-type: application/json');
      echo json_encode($json);

    }

 /************* add_tip function *************/

    public function add_tip(){

      $arr_get = ['id'=>$this->input->get_post('request_id')];

      $login = $this->webservice_model->get_where('user_request',$arr_get);
      if ($login[0]['id'] == "")
      {
                          $ressult['result']='Data Not Found';
                          $ressult['message']='unsuccessfull';
                          $ressult['status']='0';
                          $json = $ressult;

                                header('Content-type:application/json');
                                echo json_encode($json);
                                die;
      }


  $arr_get1 = ['request_id'=>$this->input->get_post('request_id')];

      $login1 = $this->webservice_model->get_where('final_payment',$arr_get1);
      if ($login1[0]['id'] == "")
      {
                          $ressult['result']='wait for driver submition';
                          $ressult['message']='unsuccessfull';
                          $ressult['status']='0';
                          $json = $ressult;

                                header('Content-type:application/json');
                                echo json_encode($json);
                                die;
      }


       $arr_data = [
            'tip_amount'=>$this->input->get_post('tip_amount')
            ];

                      
      $arr_get1 = ['request_id'=>$this->input->get_post('request_id')];     

      $res = $this->webservice_model->update_data('user_request',$arr_data,$arr_get);

      $res = $this->webservice_model->update_data('final_payment',$arr_data,$arr_get1);

      if ($res)
      {
        $data = $this->webservice_model->get_where('user_request',$arr_get);



	$driver_r = $this->webservice_model->get_where('drivers', ['id' => $data[0]['accept_driver_id']]);
	$user_r = $this->webservice_model->get_where('users', ['id' => $data[0]['user_id']]);

        $user_message_apk = array(
            "message" => array(
              "result" => "successful",
              "key" => "You have Got Tip",

              "userid" => $user_r[0]['id'],
              "username" => $user_r[0]['name'],
              "userimage" => $user_r[0]['image']


            )
          );


 $register_userid = array($driver_r[0]['register_id']);

            $this->webservice_model->driver_apk_notification($register_userid, $user_message_apk);

      
        $ressult['result']=$data[0];
        $ressult['message']='successfull';
        $ressult['status']='1';
        $json = $ressult;
      }
      else
      {
                          $ressult['result']='Data Not Found';
                          $ressult['message']='unsuccessfull';
                          $ressult['status']='0';
                          $json = $ressult;
      }

      header('Content-type: application/json');
      echo json_encode($json);

                          

    }

/************* add_rating_review *************/
  public

  function add_rating_review()
    {
    $arr_data = [

         'request_id' => $this->input->get_post('request_id') ,
         'user_id' => $this->input->get_post('user_id') ,
         'driver_id' => $this->input->get_post('driver_id') ,
         'review' => $this->input->get_post('review') ,
         'rating' => $this->input->get_post('rating') 

    ];
    $id = $this->webservice_model->insert_data('rating_review', $arr_data);
    if ($id == "")
      {
      $json = ['result' => 'unsuccessfull', 'status' => 0, 'message' => 'data not found'];
      }
      else
      {
      $arr_gets = ['id' => $id];
      $login = $this->webservice_model->get_where('rating_review', $arr_gets);
      $ressult['result'] = $login[0];
      $ressult['message'] = 'successfull';
      $ressult['status'] = '1';
      $json = $ressult;
      }

    header('Content-type:application/json');
    echo json_encode($json);
    }
/*************  get_request_details *************/
    public

    function get_request_details()
    {                     
                          
      $arr_get = ['id'=>$this->input->get_post('request_id')];

      $login = $this->webservice_model->get_where('user_request',$arr_get);
               
      if ($login) {
                         
                         foreach($login as  $val)
			 {   
                           
                           $where = ['id'=>$val['accept_driver_id']];
                           $fetch = $this->webservice_model->get_where('drivers',$where);

                           $val['driver_name'] =  $fetch[0]['first_name'];
                           $val['driver_phone'] = $fetch[0]['phone'];
                           $val['driver_email'] = $fetch[0]['email'];
                           $val['vehicle_type'] = $fetch[0]['vehicle_type'];

                           $val['driver_image'] = SITE_URL.'uploads/images/'.$fetch[0]['image'];

                           $data = $val;

                          }
        
                          
                         
                          $ressult['result']=$data;
                          $ressult['message']='successful';
                          $ressult['status']='1';
                          $json = $ressult;                      
                         

      }
      else {
                          $ressult['result']='Data Not Found';
                          $ressult['message']='unsuccessful';
                          $ressult['status']='0';
                          $json = $ressult;
      }

      header('Content-type: application/json');
      echo json_encode($json);

    }

/*************  get_admin_table *************/
    public

    function get_admin_table()
    {                     
                          


      $login = $this->webservice_model->get_all('admin');
               
      if ($login) {
                         
                        
        
                          $ressult['result']='successful';
                          $ressult['Eula']=$login[0]['Eula'];
                          $ressult['About']=$login[0]['About'];

                          $ressult['message']='successful';
                          $ressult['status']='1';
                          $json = $ressult;                      
                         

      }
      else {
                          $ressult['result']='Data Not Found';
                          $ressult['message']='unsuccessful';
                          $ressult['status']='0';
                          $json = $ressult;
      }

      header('Content-type: application/json');
      echo json_encode($json);

    }


  /************* add_user_paypal function *************/

    public function add_user_paypal(){

         $arr_data = [
          
            'user_id'=>$this->input->get_post('user_id'),
            'email'=>$this->input->get_post('email'),
            'account'=>$this->input->get_post('account')     
            ];


      $arr_get = ['user_id' => $arr_data['user_id']];

      $login = $this->webservice_model->get_where('PaymentAccount',$arr_get);
      if ($login) {
        
        $ressult['result']='already exist';
        $ressult['message']='unsuccessfull';
        $ressult['status']='0';
        $json = $ressult;
                               
        header('Content-type:application/json');
        echo json_encode($json);
        die;
      }     

      
      
      $id = $this->webservice_model->insert_data('PaymentAccount',$arr_data);

      if ($id=="") {
        $json = ['result'=>'unsuccessfull','status'=>0,'message'=>'data not found'];
      }else{

   
        $arr_gets = ['id'=>$id];
        $login = $this->webservice_model->get_where('PaymentAccount',$arr_gets);       
        $ressult['result']=$login[0];
        $ressult['message']='successfull';
        $ressult['status']='1';
        $json = $ressult;
      }

      header('Content-type:application/json');
      echo json_encode($json);

    }


 /************* check_account_detail function *************/

    public function check_account_detail(){

         $arr_data = [
          
            'user_id'=>$this->input->get_post('user_id')   
            ];


      $arr_get = ['user_id' => $arr_data['user_id']];

      $login = $this->webservice_model->get_where('PaymentAccount',$arr_get);
      if ($login) {
        
        $ressult['result']='already exist';
        $ressult['message']='successfull';
        $ressult['status']='1';
        $json = $ressult;
                               
        header('Content-type:application/json');
        echo json_encode($json);
        die;
      }     

      
      
      else{


        $ressult['result']='Not exist';
        $ressult['message']='unsuccessfull';
        $ressult['status']='0';
        $json = $ressult;
      }

      header('Content-type:application/json');
      echo json_encode($json);

    }


  /************* block_user function *************/

    public function block_user(){

         $arr_data = [
          
            'block_by'=>$this->input->get_post('block_by'),
            'block_user_id'=>$this->input->get_post('block_user_id')
            ];


      $arr_get = ['block_by' => $arr_data['block_by'],'block_user_id' => $arr_data['block_user_id']];

      $login = $this->webservice_model->get_where('block_users',$arr_get);
      if ($login) {
        
        $ressult['result']='already exist';
        $ressult['message']='unsuccessfull';
        $ressult['status']='0';
        $json = $ressult;
                               
        header('Content-type:application/json');
        echo json_encode($json);
        die;
      }     

      
      
      $id = $this->webservice_model->insert_data('block_users',$arr_data);

      if ($id=="") {
        $json = ['result'=>'unsuccessfull','status'=>0,'message'=>'data not found'];
      }else{

   
        $arr_gets = ['id'=>$id];
        $login = $this->webservice_model->get_where('block_users',$arr_gets);       
        $ressult['result']=$login[0];
        $ressult['message']='successfull';
        $ressult['status']='1';
        $json = $ressult;
      }

      header('Content-type:application/json');
      echo json_encode($json);

    }

 /*************  get_blocked_user *************/
	public

	function get_blocked_user()
		{
       $arr_get = [

                   'block_by'=>$this->input->get_post('user_id')

                ];

		$fetch = $this->webservice_model->get_where('block_users',$arr_get);
		if ($fetch)
			{
			foreach($fetch as $val)
				{
                                $arr_gets = ['id' => $val['block_user_id']];
				$login = $this->webservice_model->get_where('users', $arr_gets);

                                $login[0]['image'] = SITE_URL.'uploads/images/'.$login[0]['image'];
                                $val1 = $login[0];


				$data[] = $val1;
				}

			$ressult['result'] = $data;
			$ressult['message'] = 'successful';
			$ressult['status'] = '1';
			$json = $ressult;
			}
		  else
			{
			$ressult['result'] = 'Data Not Found';
			$ressult['message'] = 'unsuccessful';
			$ressult['status'] = '0';
			$json = $ressult;
			}

		header('Content-type: application/json');
		echo json_encode($json);
		}

	/************** unblock_user ****************/
	public

	function unblock_user()
		{
	
		$arr_get = ['block_user_id' => $this->input->get_post('block_user_id', TRUE) ,'block_by' => $this->input->get_post('block_by', TRUE) ];
		$res = $this->webservice_model->delete_data('block_users', $arr_get);
		if ($res)
			{

			$ressult['result'] = ' unblock successfully';
			$ressult['message'] = 'successfull';
			$ressult['status'] = '1';
			$json = $ressult;
			}
		  else
			{
			$ressult['result'] = 'Data Not Found';
			$ressult['message'] = 'unsuccessfull';
			$ressult['status'] = '0';
			$json = $ressult;
			}

		header('Content-type: application/json');
		echo json_encode($json);
		}


/*************  send_noti_to_driver *************/
    public

    function send_noti_to_driver()
    {                     
                          
      $arr_get = ['name'=>$this->input->get_post('city')];
        
	$driver_id = $this->input->get_post('driver_id', TRUE);

      $login = $this->webservice_model->get_where('city',$arr_get);
               
      if ($login) {
                         
                $msg = $login[0]['MsgAllDrivers'];        
        
                          
                             // send notification for Andriod

               $arr_get1 = ['id'=>$driver_id];

                 $login1 = $this->webservice_model->get_where('drivers',$arr_get1);
               

                   $user_message_apk = array(
                           "message" => array(
                             "result" => "successful",
                             "key" => "driver infornmation",
                             "message" => $msg,
                             
                             "date"=> date('Y-m-d h:i:s')
                           )
                         );
                  

                        $register_userid = array($login1[0]['register_id']);


                        $this->webservice_model->driver_apk_notification($register_userid, $user_message_apk);




              // end send notification for Andriod  
                         
                          $ressult['result']=$msg;
                          $ressult['message']='successful';
                          $ressult['status']='1';
                          $json = $ressult;                      
                         

      }
      else {
                          $ressult['result']='Data Not Found';
                          $ressult['message']='unsuccessful';
                          $ressult['status']='0';
                          $json = $ressult;
      }

      header('Content-type: application/json');
      echo json_encode($json);

    }


/*************  send_noti_to_user *************/
    public

    function send_noti_to_user()
    {                     
                          
      $arr_get = ['name'=>$this->input->get_post('city')];
        
	$user_id = $this->input->get_post('user_id', TRUE);

      $login = $this->webservice_model->get_where('city',$arr_get);
               
      if ($login) {
                         
                $msg = $login[0]['MsgAllRiders'];        
        
                          
                             // send notification for Andriod

               $arr_get1 = ['id'=>$user_id];

                 $login1 = $this->webservice_model->get_where('users',$arr_get1);
               

                   $user_message_apk = array(
                           "message" => array(
                             "result" => "successful",
                             "key" => "user infornmation",
                             "message" => $msg,
                             
                             "date"=> date('Y-m-d h:i:s')
                           )
                         );
                  

                        $register_userid = array($login1[0]['register_id']);


                        $this->webservice_model->user_apk_notification($register_userid, $user_message_apk);




              // end send notification for Andriod  
                         
                          $ressult['result']=$msg;
                          $ressult['message']='successful';
                          $ressult['status']='1';
                          $json = $ressult;                      
                         

      }
      else {
                          $ressult['result']='Data Not Found';
                          $ressult['message']='unsuccessful';
                          $ressult['status']='0';
                          $json = $ressult;
      }

      header('Content-type: application/json');
      echo json_encode($json);

    }



/***************get distance *****************/
    public

	function get_distance()
        { 	        
                         $pic_lat = $this->input->get_post('pic_lat', TRUE) ;
			 $pic_lon = $this->input->get_post('pic_lon', TRUE) ;
			 $drop_lat = $this->input->get_post('drop_lat', TRUE) ;
			 $drop_lon = $this->input->get_post('drop_lon', TRUE) ;



			$distance = $this->webservice_model->distance($pic_lat, $pic_lon, $drop_lat, $drop_lon, $miles = false);                       


                                $val['distance'] = number_format($distance, 2, '.', '');
				$val['estimate_time'] = round($distance * 1.5);
                           //   $val['result'] = "successful";
	                        $json[] = $val;
			       

                        if(!isset($json))
                          {
                                $ressult['result']='Data Not Found';
	                        $ressult['message']='unsuccessful';
	                        $ressult['status']='0';
	                        $code = $ressult;
                           

                       
                                header('Content-type: application/json');
		                echo json_encode($code);
		                die;


                              }else{

                                $ressult['result']=$json;
	                        $ressult['message']='successful';
	                        $ressult['status']='1';
	                        $code = $ressult;
         header('Content-type: application/json');
	echo json_encode($code);
	die;

                               }       

                      
       
	 }      


 /*************update_drive_status function *************/

    public function update_drive_status(){

      $arr_get = ['id'=>$this->input->get_post('request_id')];

      $login = $this->webservice_model->get_where('user_request',$arr_get);
      if ($login[0]['id'] == "")
      {
                          $ressult['result']='Data Not Found';
                          $ressult['message']='unsuccessfull';
                          $ressult['status']='0';
                          $json = $ressult;

                                header('Content-type:application/json');
                                echo json_encode($json);
                                die;
      }

      

       $arr_data = [
            'driver_status'=>$this->input->get_post('driver_status')
                  
            ];

                   

      $res = $this->webservice_model->update_data('user_request',$arr_data,$arr_get);
      if ($res)
      {
        $data = $this->webservice_model->get_where('user_request',$arr_get);
       
      
        $ressult['result']='Status Update Successfull';
         $ressult['driver_status']=$data[0]['driver_status'];
        $ressult['message']='successfull';
        $ressult['status']='1';
        $json = $ressult;
      }
      else
      {
                          $ressult['result']='Data Not Found';
                          $ressult['message']='unsuccessfull';
                          $ressult['status']='0';
                          $json = $ressult;
      }

      header('Content-type: application/json');
      echo json_encode($json);

                          

    }




/*************  get_letter_ride *************/
    public

    function get_share_ride()
    {                     


                         $lat = $this->input->get_post('lat', TRUE) ;
                         $lon = $this->input->get_post('lon', TRUE) ;
                         $user_distance = $this->input->get_post('user_distance', TRUE) ;
                          

     /* $where = "SeatsLeft != 0";
      $login = $this->webservice_model->get_where('travel',$where);

*/
      $login = $this->webservice_model->get_where('travel',['status'=>'Pending']);
               
      if ($login) {
                         
                         foreach($login as  $val)
                       {   
                            $distance = $this->webservice_model->distance($lat, $lon, $val['pickup_lat'], $val['pickup_lon'], $miles = false);                       
                                     if($user_distance >= $distance){

               
                           $where = ['id'=>$val['user_id']];
                           $fetch = $this->webservice_model->get_where('users',$where);

                           

                           $val['user_name'] =  $fetch[0]['name'];
                           $val['user_phone'] = $fetch[0]['phone'];
                           $val['user_email'] = $fetch[0]['email'];
                           $val['status'] = $fetch[0]['about'];


                           $val['user_image'] = SITE_URL.'uploads/images/'.$fetch[0]['image'];
                           $val['vari_image'] = SITE_URL.'uploads/images/'.$fetch[0]['vari_image'];

                           $rat = $this->db->select_avg("rating", "rating")->where(['user_id' => $val['user_id']])->get('user_rating')->result_array();
                           $rating = ($rat[0]['rating'] == '') ? "5.0" : $rat[0]['rating'];
                           $val['rating'] = $rating;

$r_id = $val['id'];
                           $where1 = ['ride_id'=>$r_id];
                           $fetch1 = $this->webservice_model->get_where('booking_details',$where1);
if($fetch1){


 foreach($fetch1 as  $val1)
                       { 
                           $where2 = ['id'=>$val1['user_id']];
                           $fetch2 = $this->webservice_model->get_where('users',$where2);
                           $fetch2[0]['user_image'] = SITE_URL.'uploads/images/'.$fetch2[0]['vari_image'];

                          // $fetch2[0]['user_image'] = SITE_URL.'uploads/images/'.$val1['martin_security'];
                           $val['a_user_details'][] = $fetch2[0];
                       }



}else{

                           $val['a_user_details'] = [];

}
$where123 = ['rider_id'=>$val['user_id']];
$fetch123 = $this->webservice_model->get_where('user_rating',$where123);
if ($fetch123) {

foreach($fetch123 as  $val123)
                       { 
   $where2123 = ['id'=>$val123['user_id']];
   $fetch2123 = $this->webservice_model->get_where('users',$where2123);
   $val123['username'] = $fetch2123[0]['name'];
   $val123['user_image'] = SITE_URL.'uploads/images/'.$fetch2123[0]['image'];

$val['rider_comment'][] = $val123;
}
}else{
  $val['rider_comment'] =[];

}


                           $data[] = $val;

                          }
       }
                          
                          if(!isset($data)){
                                   $ressult['result']='Data Not Found';
                                   $ressult['message']='unsuccessful';
                                   $ressult['status']='0';
                                   $json = $ressult;
                                   header('Content-type: application/json');
                                   echo json_encode($json); die;
                         
                                }else{
                                       $dis = array();
                                       foreach ($data as $key => $row)
                                       {
                                        $dis[$key] = $row['PickUpCity'];
                                       }
                                        array_multisort($dis, SORT_ASC, $data);

                                  $ressult['result']=$data;
                                  $ressult['message']='successful';
                                  $ressult['status']='1';
                                  $json = $ressult;
                                   header('Content-type: application/json');
                                   echo json_encode($json); die;    


                                }
                                           
                         

      }
      else {
                          $ressult['result']='Data Not Found';
                          $ressult['message']='unsuccessful';
                          $ressult['status']='0';
                          $json = $ressult;
      }

      header('Content-type: application/json');
      echo json_encode($json);

    }



/***************add_share_ride *****************/
    public

     function add_share_ride()
        {           
                         $lat = $this->input->get_post('pickup_lat', TRUE) ;
                         $lon = $this->input->get_post('pickup_lon', TRUE) ;
                         $user_distance = 50;
                       
                         $arr_data = [
          
                                'user_id' => $this->input->get_post('user_id'), 
                                'SeatsLeft' => $this->input->get_post('SeatsLeft'), 
                                'total_seats' => $this->input->get_post('SeatsLeft'), 
                                'PickUpCity' => $this->input->get_post('PickUpCity'), 
                                'DropCity' => $this->input->get_post('DropCity'), 
                                'date' => $this->input->get_post('date'),
                                'time' => $this->input->get_post('time'),
                                'pickup_lat' => $this->input->get_post('pickup_lat'),
                                'pickup_lon' => $this->input->get_post('pickup_lon'),
                                'dropoff_lat' => $this->input->get_post('dropoff_lat'),
                                'dropoff_lon' => $this->input->get_post('dropoff_lon'),
                                'pick_address' => $this->input->get_post('pick_address'),
                                'drop_address' => $this->input->get_post('drop_address'),
                                'AmtPerSeat' => $this->input->get_post('AmtPerSeat'),
                                'country_name' => $this->input->get_post('country_name'),
                                'Instructions' => $this->input->get_post('Instructions')
                           ];

   

                     $last_id = $this->webservice_model->insert_data('travel', $arr_data); 


                     $arr_get = ['id !=' => $arr_data['user_id']];                   


                     $fetch = $this->webservice_model->get_where('users',$arr_get);
  




                        if (isset($_FILES['vari_image']))
      {
               $n = rand(0, 100000);
               $img = "VARI_IMG_" . $n . '.png';
               move_uploaded_file($_FILES['vari_image']['tmp_name'], "uploads/images/" . $img);
               $arr_data123['vari_image'] = $img;        

                $this->webservice_model->update_data('users',$arr_data123,['id'=>$arr_data['user_id']]);

      }




              if ($fetch){
                   
                  foreach($fetch as $val){
                    
                    $distance = $this->webservice_model->distance($lat, $lon, $val['Rlat'], $val['Rlon'], $miles = false);    
                    if($user_distance >= $distance){
                    
                   // send notification for Andriod

                 
                        $user_message_apk = array(
                           "message" => array(
                             "result" => "successful",
                             "key" => "Request for share booking",
                             "pickup_lat" => $arr_data['pickup_lat'],
                             "pickup_lon" => $arr_data['pickup_lon'],
                             "dropoff_lat" => $arr_data['dropoff_lat'],
                             "dropoff_lon" => $arr_data['dropoff_lon'],
                             "driver_id" => $arr_data['user_id'],
                             "request_id" => $last_id,
                             "date"=> date('Y-m-d h:i:s')
                           )
                         );
                  

                        $register_userid = array($val['register_id']);


                        $this->webservice_model->user_apk_notification($register_userid, $user_message_apk);


                         // end send notification for Andriod    


                     }                 
                                 
                  }

                $ressult['result'] = $last_id;
                $ressult['message'] = 'successful';
                $ressult['status'] = '1';
                $json = $ressult;
                }
                else
                {
                $ressult['result'] = 'Data Not Found';
                $ressult['message'] = 'unsuccessful';
                $ressult['status'] = '0';
                $json = $ressult;
                }

            header('Content-type: application/json');
            echo json_encode($json);
            }
 

    /************* get_share_ride_details function *************/

     public function get_share_ride_details(){

      $arr_get = ['id'=>$this->input->get_post('ride_id')];

      $login = $this->webservice_model->get_where('travel',$arr_get);

      if ($login) {  
     
      //  $login[0]['image']=SITE_URL.'uploads/images/'.$login[0]['image'];

          $ressult['result']=$login[0];
          $ressult['message']='successfull';
          $ressult['status']='1';
          $json = $ressult;

      }else{

        $json = ['result'=>'unsuccessfull','status'=>0,'message'=>'Data Not Found'];

      }

      header('Content-type: application/json');
      echo json_encode($json);
    }         




/*************  get_all_user_order *************/
    public

    function get_all_user_rides()
    {                     
                          
      $arr_get = ['user_id'=>$this->input->get_post('user_id')];

      $login = $this->webservice_model->get_where('travel',$arr_get);
               
      if ($login) {
                         
                     foreach($login as  $val)
                     {   
                           
                      $arr_country = ['name'=>$val['country_name']];

                      $get_country = $this->webservice_model->get_where('country',$arr_country);
               
     // SELECT SUM(amount)FROM booking_details WHERE ride_id = 1
                         

                          $arr_rate = ['Country'=>$get_country[0]['id']];
                          $rate = $this->webservice_model->get_where('travelrate',$arr_rate);
        if($val['total_seats'] != $val['SeatsLeft']){
                          
                          $seats = $val['total_seats'] - $val['SeatsLeft'];
                          $ride_id = $val['id'];
                          $totalAmount = $this->db->query("SELECT sum(amount) AS amount FROM booking_details WHERE ride_id = '$ride_id'")->result_array();
                          $totalAmount = $totalAmount[0]['amount'];
                         //echo $this->db->last_query();die;
                         //$totalAmount = $seats * $val['AmtPerSeat'];

                          $RatePerKM = $rate[0]['RatePerKM'];
                          $Paypalfixedfee = $rate[0]['Paypalfixedfee'];
                          $Paypalpercentage = $rate[0]['Paypalpercentage'];

                          $pay = ($totalAmount * $Paypalpercentage)/100;
                          $aa = $pay + $Paypalfixedfee;

                          $finalAmount = $totalAmount - $aa;


                          $val['total_amount'] = $totalAmount;
                          $val['network_fee'] = $aa;

                          $val['host_fee'] = $finalAmount;
}else{
                          $val['total_amount'] = 0.0;
                          $val['network_fee'] = 0.0;

                          $val['host_fee'] = 0.0;
}
                           $data[] = $val;

                          }
        
                          
                         
                          $ressult['result']=$data;
                          $ressult['message']='successful';
                          $ressult['status']='1';
                          $json = $ressult;                      
                         

      }
      else {
                          $ressult['result']='Data Not Found';
                          $ressult['message']='unsuccessful';
                          $ressult['status']='0';
                          $json = $ressult;
      }

      header('Content-type: application/json');
      echo json_encode($json);

    }







  public

  function dashboard()
  {
    $this->load->view('admin/dashboard');
  }


/************* book_seats function *************/

    public function book_seats(){

         $arr_data = [
            'ride_id'=>$this->input->get_post('ride_id'),
            'user_id'=>$this->input->get_post('user_id'),
            'no_seat'=>$this->input->get_post('no_seat'),
            'amount'=>$this->input->get_post('amount'),  
            'AdminFee'=>$this->input->get_post('AdminFee'),  
            'HostFee'=>$this->input->get_post('HostFee'),   
            'country'=>$this->input->get_post('country'),  
            'transation_id'=>$this->input->get_post('transation_id')
            ];


                        if (isset($_FILES['martin_security']))
      {
               $n = rand(0, 100000);
               $img = "SECURITY_IMG_" . $n . '.png';
               move_uploaded_file($_FILES['martin_security']['tmp_name'], "uploads/images/" . $img);
               $arr_data['martin_security'] = $img;        
      }




      $id = $this->webservice_model->insert_data('booking_details',$arr_data);

      if ($id=="") {
        $json = ['result'=>'unsuccessfull','status'=>0,'message'=>'data not found'];
      }else{
                  

                        if (isset($_FILES['martin_security']))
      {
               $n = rand(0, 100000);
               $img = "VARI_IMG_1" . $n . '.png';
               move_uploaded_file($_FILES['martin_security']['tmp_name'], "uploads/images/" . $img);
               $arr_data123['vari_image'] = $img;        

                $this->webservice_model->update_data('users',$arr_data123,['id'=>$arr_data['user_id']]);

      }


        $arr_gets = ['id'=>$id];
        $login = $this->webservice_model->get_where('booking_details',$arr_gets);     


        $arr_seat = ['id'=>$login[0]['ride_id']];
        $seat = $this->webservice_model->get_where('travel',$arr_seat);     

        $rem = $seat[0]['SeatsLeft'] - $login[0]['no_seat'];

        $arr_rem = ['SeatsLeft'=>$rem];

        $this->webservice_model->update_data('travel',$arr_rem,$arr_seat);


                                        
        $arr_user = ['id'=>$seat[0]['user_id']];
        $user = $this->webservice_model->get_where('users',$arr_user);     

 // send notification for Andriod

                 
                        $user_message_apk = array(
                           "message" => array(
                             "result" => "successful",
                             "key" => "New booking",
                             "pickup_lat" => $seat[0]['pickup_lat'],
                             "pickup_lon" => $seat[0]['pickup_lon'],
                             "dropoff_lat" => $seat[0]['dropoff_lat'],
                             "dropoff_lon" => $seat[0]['dropoff_lon'],
                             "user_id" => $seat[0]['user_id'],
                             "request_id" => $seat[0]['id'],
                             "date"=> date('Y-m-d h:i:s')
                           )
                         );
                  

                        $register_userid = array($user[0]['register_id']);


                        $this->webservice_model->user_apk_notification($register_userid, $user_message_apk);


                         // end send notification for Andriod 


/*header("Location: http://socialryde.cc/SocialRyde/payment.html");
die();
*/
        $ressult['result']=$login[0];
        $ressult['message']='successfull';
        $ressult['status']='1';
        $json = $ressult;
       // return redirect('admin/invoice.html');   

      }

      header('Content-type:application/json');
      echo json_encode($json);

    }


/*************update_share_ride_status function *************/

    public function update_share_ride_status(){

      $arr_get = ['id'=>$this->input->get_post('ride_id')];

      $login = $this->webservice_model->get_where('travel',$arr_get);
      if ($login[0]['id'] == "")
      {
                          $ressult['result']='Data Not Found';
                          $ressult['message']='unsuccessfull';
                          $ressult['status']='0';
                          $json = $ressult;

                                header('Content-type:application/json');
                                echo json_encode($json);
                                die;
      }

      

       $arr_data = [
            'status'=>'Complete'
                  
            ];

                   

      $res = $this->webservice_model->update_data('travel',$arr_data,$arr_get);
      if ($res)
      {
        $data = $this->webservice_model->get_where('travel',$arr_get);

        $arr_book = ['ride_id'=>$data[0]['id']];
        $book = $this->webservice_model->get_where('booking_details',$arr_book); 
if($book){
     foreach ($book as $value) {
 
        $arr_user = ['id'=>$value['user_id']];
        $users = $this->webservice_model->get_where('users',$arr_user);     
    

 // send notification for Andriod

                 
                        $user_message_apk = array(
                           "message" => array(
                             "result" => "successful",
                             "key" => "Ride Completeed",
                             "ride_id" => $data[0]['id'],
                             "user_id" => $data[0]['user_id'],
                             "status" => $data[0]['status'],
                             "date"=> date('Y-m-d h:i:s')
                           )
                         );
                  

                        $register_userid = array($users[0]['register_id']);


                        $this->webservice_model->user_apk_notification($register_userid, $user_message_apk);


                         // end send notification for Andriod 
             }

     }


       


      
        $ressult['result']='Status Update Successfull';
        $ressult['message']='successfull';
        $ressult['status']='1';
        $json = $ressult;
      }
      else
      {
                          $ressult['result']='Data Not Found';
                          $ressult['message']='unsuccessfull';
                          $ressult['status']='0';
                          $json = $ressult;
      }

      header('Content-type: application/json');
      echo json_encode($json);

                          

    }
   


/************* add_rating_by_rider function *************/

    public function add_rating_by_rider(){

         $arr_data = [
            'trip_id'=>$this->input->get_post('trip_id'),
            'user_id'=>$this->input->get_post('user_id'),
            'rider_id'=>$this->input->get_post('rider_id'),
            'rating'=>$this->input->get_post('rating'),  
            'comment'=>$this->input->get_post('comment')
            ];


      $id = $this->webservice_model->insert_data('user_rating',$arr_data);

      if ($id=="") {
        $json = ['result'=>'unsuccessfull','status'=>0,'message'=>'data not found'];
      }else{
                                                
                               
        $arr_user = ['id'=>$arr_data['user_id']];
        $user = $this->webservice_model->get_where('users',$arr_user);     

 // send notification for Andriod

                 
                        $user_message_apk = array(
                           "message" => array(
                             "result" => "successful",
                             "key" => "New Rating By Rider",
                             "rider_id" => $arr_data['rider_id'],
                             "trip_id" => $arr_data['trip_id'],
                             "rating" => $arr_data['rating'],
                             "comment" => $arr_data['comment'],
                             "date"=> date('Y-m-d h:i:s')
                           )
                         );
                  

                        $register_userid = array($user[0]['register_id']);


                        $this->webservice_model->user_apk_notification($register_userid, $user_message_apk);


                         // end send notification for Andriod 


        $ressult['result']="add Rating successfull";
        $ressult['message']='successfull';
        $ressult['status']='1';
        $json = $ressult;
      }

      header('Content-type:application/json');
      echo json_encode($json);

    }



  /************** delete_share_ride ****************/
  public

  function delete_share_ride()
    {
  
    $arr_get = ['ride_id' => $this->input->get_post('ride_id', TRUE)];
    $res = $this->webservice_model->get_where('booking_details', $arr_get);
    if ($res)
      {

      $ressult['result'] = 'unable to remove';
      $ressult['message'] = 'unsuccessfull';
      $ressult['status'] = '0';
      $json = $ressult;
      }
      else
      {

         $this->webservice_model->delete_data('travel',['id'=>$arr_get['ride_id']]);

                          $ressult['result']="Ride delete successfull";
                          $ressult['message']='successful';
                          $ressult['status']='1';
                          $json = $ressult;
     
      }

    header('Content-type: application/json');
    echo json_encode($json);die;
    }

  /************* update_share_ride function *************/

    public function update_share_ride(){

      $arr_get = ['id'=>$this->input->get_post('ride_id')];

      $login = $this->webservice_model->get_where('travel',$arr_get);
      if ($login[0]['id'] == "")
      {
                                $ressult['result']='Data Not Found';
                                $ressult['message']='unsuccessfull';
                                $ressult['status']='0';
                                $json = $ressult;

                                header('Content-type:application/json');
                                echo json_encode($json);
                                die;
      }

        
                         $arr_data = [
          
                                'user_id' => $this->input->get_post('user_id'), 
                                'SeatsLeft' => $this->input->get_post('SeatsLeft'), 
                                'total_seats' => $this->input->get_post('SeatsLeft'), 
                                'PickUpCity' => $this->input->get_post('PickUpCity'), 
                                'DropCity' => $this->input->get_post('DropCity'), 
                                'date' => $this->input->get_post('date'),
                                'time' => $this->input->get_post('time'),
                                'pickup_lat' => $this->input->get_post('pickup_lat'),
                                'pickup_lon' => $this->input->get_post('pickup_lon'),
                                'dropoff_lat' => $this->input->get_post('dropoff_lat'),
                                'dropoff_lon' => $this->input->get_post('dropoff_lon'),
                                'pick_address' => $this->input->get_post('pick_address'),
                                'drop_address' => $this->input->get_post('drop_address'),
                                'AmtPerSeat' => $this->input->get_post('AmtPerSeat'),
                                'country_name' => $this->input->get_post('country_name'),
                                'Instructions' => $this->input->get_post('Instructions')
                           ];



      $res = $this->webservice_model->update_data('travel',$arr_data,$arr_get);
      if ($res)
      {
                                
                                $ressult['result']='update successfull';
                                $ressult['message']='successfull';
                                $ressult['status']='1';
                                $json = $ressult;
      }
      else
        {
                                $ressult['result']='Data Not Found';
                                $ressult['message']='unsuccessfull';
                                $ressult['status']='0';
                                $json = $ressult;
      }

                                header('Content-type: application/json');
                                echo json_encode($json);

                          

    }


/***************payment_request *****************/
    public

     function payment_request()
        {           
                     
                         $arr_data = [
          
                                'user_id' => $this->input->get_post('user_id'), 
                                'ride_id' => $this->input->get_post('ride_id'),
                                'host_fee' => $this->input->get_post('host_fee')
                           ];

   

                     $last_id = $this->webservice_model->insert_data('payment_request', $arr_data); 


  

              if ($last_id){
                   
                $ressult['result'] = $last_id;
                $ressult['message'] = 'successful';
                $ressult['status'] = '1';
                $json = $ressult;
                }
                else
                {
                $ressult['result'] = 'Data Not Found';
                $ressult['message'] = 'unsuccessful';
                $ressult['status'] = '0';
                $json = $ressult;
                }

            header('Content-type: application/json');
            echo json_encode($json);
            }
 

/************************************* old function here *********************************************/


  /*************update_drdiver_status function *************/

    public function update_drdiver_status(){

      $arr_get = ['id'=>$this->input->get_post('driver_id')];

      $login = $this->webservice_model->get_where('drivers',$arr_get);
      if ($login[0]['id'] == "")
      {
                          $ressult['result']='Data Not Found';
                          $ressult['message']='unsuccessfull';
                          $ressult['status']='0';
                          $json = $ressult;

                                header('Content-type:application/json');
                                echo json_encode($json);
                                die;
      }

      

       $arr_data = [
            'available_status'=>$this->input->get_post('available_status')
                  
            ];

                   

      $res = $this->webservice_model->update_data('drivers',$arr_data,$arr_get);
      if ($res)
      {
        $data = $this->webservice_model->get_where('drivers',$arr_get);
       
      
        $ressult['result']='Status Update Successfull';
         $ressult['available_status']=$data[0]['available_status'];
        $ressult['message']='successfull';
        $ressult['status']='1';
        $json = $ressult;
      }
      else
      {
                          $ressult['result']='Data Not Found';
                          $ressult['message']='unsuccessfull';
                          $ressult['status']='0';
                          $json = $ressult;
      }

      header('Content-type: application/json');
      echo json_encode($json);

                          

    }

/*************  get_all_user_order *************/
    public

    function get_all_user_order()
    {                     
                          
      $arr_get = ['user_id'=>$this->input->get_post('user_id')];

      $login = $this->webservice_model->get_where('user_request',$arr_get);
               
      if ($login) {
                         
                         foreach($login as  $val)
			 {   
                           
                           $where = ['id'=>$val['accept_driver_id']];
                           $fetch = $this->webservice_model->get_where('drivers',$where);

                           $val['driver_name'] =  $fetch[0]['first_name'];
                           $val['driver_phone'] = $fetch[0]['phone'];
                           $val['driver_email'] = $fetch[0]['email'];
                           $val['vehicle_type'] = $fetch[0]['vehicle_type'];

                           $val['driver_image'] = SITE_URL.'uploads/images/'.$fetch[0]['image'];
                           $val['item_image'] = SITE_URL.'uploads/images/'.$val['item_image'];
                           $data[] = $val;

                          }
        
                          
                         
                          $ressult['result']=$data;
                          $ressult['message']='successful';
                          $ressult['status']='1';
                          $json = $ressult;                      
                         

      }
      else {
                          $ressult['result']='Data Not Found';
                          $ressult['message']='unsuccessful';
                          $ressult['status']='0';
                          $json = $ressult;
      }

      header('Content-type: application/json');
      echo json_encode($json);

    }


    /*************  get_all_driver_order *************/
    public

    function get_all_driver_order()
    {                     
                          
      $arr_get = ['accept_driver_id'=>$this->input->get_post('driver_id')];

      $login = $this->webservice_model->get_where('user_request',$arr_get);
               
      if ($login) {
                         
                         foreach($login as  $val)
			 {   
                           
                           $where = ['id'=>$val['user_id']];
                           $fetch = $this->webservice_model->get_where('users',$where);

                           $val['username'] =  $fetch[0]['username'];
                           $val['user_phone'] = $fetch[0]['phone'];
                           $val['user_email'] = $fetch[0]['email'];
                           //$val['vehicle_type'] = $fetch[0]['vehicle_type'];

                           //$val['driver_image'] = SITE_URL.'uploads/images/'.$fetch[0]['image'];
                           $val['item_image'] = SITE_URL.'uploads/images/'.$val['item_image'];
                           $data[] = $val;

                          }
        
                          
                         
                          $ressult['result']=$data;
                          $ressult['message']='successful';
                          $ressult['status']='1';
                          $json = $ressult;                      
                         

      }
      else {
                          $ressult['result']='Data Not Found';
                          $ressult['message']='unsuccessful';
                          $ressult['status']='0';
                          $json = $ressult;
      }

      header('Content-type: application/json');
      echo json_encode($json);

    }


  /************* get_driver_accept_ride function *************/


    public function get_driver_accept_ride(){


            
               	$accept_driver_id = $this->input->get_post('driver_id', TRUE);
		
		$where = "accept_driver_id = '$accept_driver_id' AND status = 'Accept'";
		

     


      $login = $this->webservice_model->get_where('user_request',$where);
      if ($login) {

			       $arr_get = ['id' => $login[0]['user_id']];
                               $fetch = $this->webservice_model->get_where('users',$arr_get);
                               $login[0]['user_image']=SITE_URL.'uploads/images/'.$fetch[0]['image'];
                               $login[0]['name']=$fetch[0]['name'];
                               $login[0]['user_phone']=$fetch[0]['phone'];

                               $ressult['result']=$login;
                               $ressult['message']='successfull';
                               $ressult['status']='1';
                               $json = $ressult;

                 }else{
                                $ressult['result']='No Request Accepted';
                                $ressult['message']='unsuccessfull';
                                $ressult['status']='0';
                                $json = $ressult;       
      }

      header('Content-type:application/json');
      echo json_encode($json);
    }



/*************  get_canceled_order_by_user *************/
    public

    function get_canceled_order_by_user()
    {                     
                          
      $arr_get = ['user_id'=>$this->input->get_post('user_id'),'user_status'=>'Reject'];

      $login = $this->webservice_model->get_where('user_request',$arr_get);
               
      if ($login) {
                         
                         foreach($login as  $val)
       {   
                           
                          

                           $data[] = $val;

                          }
        
                          
                         
                          $ressult['result']=$data;
                          $ressult['message']='successful';
                          $ressult['status']='1';
                          $json = $ressult;                      
                         

      }
      else {
                          $ressult['result']='Data Not Found';
                          $ressult['message']='unsuccessful';
                          $ressult['status']='0';
                          $json = $ressult;
      }

      header('Content-type: application/json');
      echo json_encode($json);

    }


/*************  get_canceled_order_by_driver *************/
    public

    function get_canceled_order_by_driver()
    {                     
                          
      $arr_get = ['driver_id'=>$this->input->get_post('driver_id'),'status'=>'Reject'];

      $login = $this->webservice_model->get_where('driver_ride_history',$arr_get);
               
      if ($login) {
                         
                         foreach($login as  $val)
                      {   
                           $where = ['id'=>$val['user_request_id']];
                           $fetch = $this->webservice_model->get_where('user_request',$where);
                           
                           $where1 = ['id'=>$fetch[0]['user_id']];
                           $fetch1 = $this->webservice_model->get_where('users',$where1);

                           $fetch[0]['item_image'] = SITE_URL.'uploads/images/'.$fetch[0]['item_image']; 
        
                           $fetch[0]['username'] = $fetch1[0]['username']; 
                           $fetch[0]['user_phone'] = $fetch1[0]['phone']; 
                           $fetch[0]['user_image'] = SITE_URL.'uploads/images/'.$fetch1[0]['image']; 

                           $val['user_request_details'] = $fetch[0]; 
                           $data[] = $val;

                          }
        
                          
                         
                          $ressult['result']=$data;
                          $ressult['message']='successful';
                          $ressult['status']='1';
                          $json = $ressult;                      
                         

      }
      else {
                          $ressult['result']='Data Not Found';
                          $ressult['message']='unsuccessful';
                          $ressult['status']='0';
                          $json = $ressult;
      }

      header('Content-type: application/json');
      echo json_encode($json);

    }





                /************* get_nearest_list *************/
    public

    function get_nearest_list()
    {
                  $type = $this->input->get_post('type');
                        $lat = $this->input->get_post('lat');
                        $lon = $this->input->get_post('lon');
                        
                        if($type=='restaurant'){
                             $list = $this->webservice_model->get_all('restaurant');
                        }else{
                             $list = $this->webservice_model->get_all('shop');
                        }
  
      if ($list)
      {
        foreach($list as $val)
        {
                                
                                $videos = $reviews = array();

                                $distance = $this->webservice_model->distance($lat, $lon, $val['lat'], $val['lon'], $miles = false);
                                if($type=='restaurant'){
                                    $get = $this->db->select_avg("rating", "rating")->where(['restaurant_id'=>$val['id']])->get('restaurant_review')->result_array();
                                    $get_review = $this->db->where(['restaurant_id'=>$val['id']])->get('restaurant_review')->result_array();
                                }else{
                                   $get = $this->db->select_avg("rating", "rating")->where(['shop_id'=>$val['id']])->get('shop_review')->result_array();
                                   $get_review = $this->db->where(['shop_id'=>$val['id']])->get('shop_review')->result_array();
                                   $get_video = $this->db->where(['item_id'=>$val['id']])->get('shop_video')->result_array();                                
                                   //echo $this->db->last_query(); die;
                                   foreach($get_video as $vid)
                                   {
                                       $vid['video']=SITE_URL.'uploads/images/'.$vid['video'];
                                       $videos[] = $vid;                     
                                   }

                                   $val['image1']=SITE_URL.'uploads/images/'.$val['image1'];
                                   $val['image2']=SITE_URL.'uploads/images/'.$val['image2'];
                                   $val['image3']=SITE_URL.'uploads/images/'.$val['image3'];
                                   $val['image4']=SITE_URL.'uploads/images/'.$val['image4'];
                                   
                                   
                                   
                                }

                                $val['discount_img']=SITE_URL.'uploads/images/'.$val['discount_img'];


                                
                                foreach($get_review as $rev)
                                {
                                  
                                  if($rev['review']!=''){
                                    $user_id = $rev['user_id'];
                                    $users = $this->webservice_model->get_where('users',['id'=>$user_id]);
                                    $reviews[] = ['username'=>$users[0]['username'],'review'=>$rev['review']];
                                  }
                                }
        
                                $rating = ($get[0]['rating']=='') ?  0 : $get[0]['rating'];   
          
                                $val['videos'] = $videos;
                                $val['rating'] = $rating;
                                $val['review'] = $reviews;
                                $val['distance'] = number_format($distance,2);
                                $val['image']=SITE_URL.'uploads/images/'.$val['image'];            
                                $data[] = $val;
        
        }

                                $dis = array();
                    foreach ($data as $key => $row)
                    {
                 $dis[$key] = $row['distance'];
                    }
                    array_multisort($dis, SORT_ASC, $data);

                          $ressult['result']=$data;
                          $ressult['message']='successful';
                          $ressult['status']='1';
                          $json = $ressult;
      }
        else
      {
                          $ressult['result']='Data Not Found';
                          $ressult['message']='unsuccessful';
                          $ressult['status']='0';
                          $json = $ressult;                              
        
      }

        
                     
      header('Content-type: application/json');
      echo json_encode($json);
    }

                /************* restaurant_category *************/
    public

    function restaurant_category()
    {
                  $res_id = $this->input->get_post('res_id');
      $list = $this->webservice_model->get_where('restaurant_cat',['restaurant_id'=>$res_id]);

      //print_r($lis);

      if ($list)
      {
        foreach($list as $val)
        {
                                
                                
                          $val['image']=SITE_URL.'uploads/images/'.$val['image'];            
                          $data[] = $val;
        
        }

                          $ressult['result']=$data;
                          $ressult['message']='successful';
                          $ressult['status']='1';
                          $json = $ressult;
      }
        else
      {
                          $ressult['result']='Data Not Found';
                          $ressult['message']='unsuccessful';
                          $ressult['status']='0';
                          $json = $ressult;                              
        
      }

        
                     
      header('Content-type: application/json');
      echo json_encode($json);
    }

                /************* restaurant_sub_category *************/
    public

    function restaurant_sub_category()
    {
                        $res_id = $this->input->get_post('res_id');
                        $res_cat_id = $this->input->get_post('res_cat_id');
                        $list = $this->webservice_model->get_where('restaurant_sub_cat',['restaurant_id'=>$res_id,'restaurant_cat_id'=>$res_cat_id]);

      //print_r($lis);

      if ($list)
      {
        foreach($list as $val)
        {
                                
                                
                          $val['image']=SITE_URL.'uploads/images/'.$val['image'];            
                          $data[] = $val;
        
        }

                          $ressult['result']=$data;
                          $ressult['message']='successful';
                          $ressult['status']='1';
                          $json = $ressult;
      }
        else
      {
                          $ressult['result']='Data Not Found';
                          $ressult['message']='unsuccessful';
                          $ressult['status']='0';
                          $json = $ressult;                              
        
      }

        
                     
      header('Content-type: application/json');
      echo json_encode($json);
    }


                /************* shop_category *************/
    public

    function shop_category()
    {
                  $shop_id = $this->input->get_post('shop_id');
                  $list = $this->webservice_model->get_where('shop_cat',['shop_id'=>$shop_id]);

      //print_r($lis);

      if ($list)
      {
        foreach($list as $val)
        {
                                
                                
                          $val['image']=SITE_URL.'uploads/images/'.$val['image'];            
                          $data[] = $val;
        
        }

                          $ressult['result']=$data;
                          $ressult['message']='successful';
                          $ressult['status']='1';
                          $json = $ressult;
      }
        else
      {
                          $ressult['result']='Data Not Found';
                          $ressult['message']='unsuccessful';
                          $ressult['status']='0';
                          $json = $ressult;                              
        
      }

        
                     
      header('Content-type: application/json');
      echo json_encode($json);
    }


                /************* shop_sub_category *************/
    public

    function shop_sub_category()
    {
                        $shop_id = $this->input->get_post('shop_id');
                        $shop_cat_id = $this->input->get_post('shop_cat_id');
                        $list = $this->webservice_model->get_where('shop_sub_cat',['shop_id'=>$shop_id,'shop_cat_id'=>$shop_cat_id]);

      //print_r($lis);

      if ($list)
      {
        foreach($list as $val)
        {
                                
                                $get_data = $this->db->where('item_id',$val['id'])->get('shop_color')->result_array();
                                $val['cours'] = $get_data;
                                $get_data = $this->db->where('item_id',$val['id'])->get('shop_size')->result_array();
                                $val['size'] = $get_data;
                                $val['image']=SITE_URL.'uploads/images/'.$val['image'];
                                $val['image1']=SITE_URL.'uploads/images/'.$val['image1'];
                                $val['image2']=SITE_URL.'uploads/images/'.$val['image2'];
                                $val['image3']=SITE_URL.'uploads/images/'.$val['image3'];
                                $val['image4']=SITE_URL.'uploads/images/'.$val['image4'];
                                           
                                $data[] = $val;
        
        }

                          $ressult['result']=$data;
                          $ressult['message']='successful';
                          $ressult['status']='1';
                          $json = $ressult;
      }
        else
      {
                          $ressult['result']='Data Not Found';
                          $ressult['message']='unsuccessful';
                          $ressult['status']='0';
                          $json = $ressult;                              
        
      }

        
                     
      header('Content-type: application/json');
      echo json_encode($json);
    }


                /************** delete_image ****************/
                public function delete_image(){

    
                $table = $this->input->get_post('table', TRUE);

                $position = $this->input->get_post('position', TRUE);
    
                $arr_id = ['id'=>$this->input->get_post('id', TRUE)];

                $list = $this->webservice_model->get_where($table,$arr_id);
                
                $arr_data = [$position=>''];

                  unlink("uploads/images/" . $list[0][$position]);
    
                $res = $this->webservice_model->update_data($table, $arr_data, $arr_id);
  
                  //echo $this->db->last_query();
                if($res){
             
                  $message = array(
                                    "result" => "successful"
      );
                  }else{
           
                  $message = array(
                                    "result" => "unsuccessful"
      );
            }

    
      echo json_encode($message);
      
         }
                
               /************* add_to_cart function *************/

    public function add_to_cart(){

                        $user_id = $this->input->get_post('user_id');
                        $item_id = $this->input->get_post('item_id');
                        $quantity = $this->input->get_post('quantity');
                        $color = $this->input->get_post('color');
                        $size = $this->input->get_post('size');
                        $type = $this->input->get_post('type');
                        $date = date('Y-m-d');
                        $time = date('h:i:s');
                        $arr_get = ['user_id' => $user_id,'item_id' => $item_id, 'status' => 'Pending'];
                        $arr_data = ['user_id' => $user_id,'item_id' => $item_id, 'quantity' => $quantity, 'date' => $date, 'time' => $time, 'color' => $color, 'size' => $size, 'type' => $type];

      $login = $this->webservice_model->get_where('add_to_cart',$arr_get);
                        //echo $this->db->last_query();
      if ($login) {                                

                                $this->webservice_model->update_data('add_to_cart',$arr_data,$arr_get);
                                $ressult['result']='cart update successfull';
                                $ressult['message']='successfull';
                                $ressult['status']='1';
                                $json = $ressult;

      }else{
                                $this->webservice_model->insert_data('add_to_cart',$arr_data);
                                $ressult['result']='add to cart successfull';
                                $ressult['message']='successfull';
                                $ressult['status']='1';
                                $json = $ressult;       
      }

      header('Content-type:application/json');
      echo json_encode($json);
    }


                /************* get_cart function *************/

    public function get_cart(){

                        $user_id = $this->input->get_post('user_id');
                        $arr_get = ['user_id' => $user_id, 'status' => 'Pending'];
                        
                        $fetch = $this->webservice_model->get_where('add_to_cart',$arr_get);
                        //echo $this->db->last_query();
      if ($fetch) {                                
                             
                                foreach($fetch as $val)
        {
                                
                                if($val['type']=='shop'){
                                  $get = $this->webservice_model->get_where('shop_sub_cat',['id'=>$val['item_id']]);
                                }else{
                                  $get = $this->webservice_model->get_where('restaurant_sub_cat',['id'=>$val['item_id']]);
                                }

                                
                                $total[] = ($get[0]['price']*$val['quantity']);

                                $val['price'] = $get[0]['price'];
                                $val['item_name'] = $get[0]['name'];
                                $val['image'] = SITE_URL.'uploads/images/'.$get[0]['image'];            
                                $data[] = $val;
        
        }

                                $user_address = [];

                                $address = $this->webservice_model->get_where('user_address',['user_id'=>$user_id]);
                                if($address){ $user_address =  $address[0]; }

                                $ressult['user_address'] = $user_address;
                                $ressult['total'] = array_sum($total);
                                $ressult['result']=$data;
                                $ressult['message']='successfull';
                                $ressult['status']='1';
                                $json = $ressult;

      }else{
                                
                                $ressult['result']='no data found';
                                $ressult['message']='unsuccessfull';
                                $ressult['status']='0';
                                $json = $ressult;       
      }

      header('Content-type:application/json');
      echo json_encode($json);
    }

                /************* get_filter_list *************/
    public

    function get_filter_list()
    {
                        $type = $this->input->get_post('type');
                        $lat = $this->input->get_post('lat');
                        $lon = $this->input->get_post('lon');
                        $nearby = $this->input->get_post('nearby');
                        $review = $this->input->get_post('review');
                        $price = $this->input->get_post('price');

                        
                        
                        if($type=='restaurant'){
                             $list = $this->webservice_model->get_all('restaurant');
                             if($price!=''){
                            
                                $this->get_restaurant_item($price);    
                                die;
                             }                             
                        }else{
                             $list = $this->webservice_model->get_all('shop');
                             if($price!=''){

                                 $this->get_shop_item($price);                                 
                                 die;
                             }                             
                        }
  
      if ($list)
      {
        foreach($list as $val)
        {
                                
                                $distance = $this->webservice_model->distance($lat, $lon, $val['lat'], $val['lon'], $miles = false);
                                if($type=='restaurant'){
                                    $get = $this->db->select_avg("rating", "rating")->where(['restaurant_id'=>$val['id']])->get('restaurant_review')->result_array();
                                    $get_review = $this->db->where(['restaurant_id'=>$val['id']])->get('restaurant_review')->result_array();
                                    $review_count = $this->db->where(['restaurant_id'=>$val['id']])->get('restaurant_review')->num_rows();
                                }else{
                                   $get = $this->db->select_avg("rating", "rating")->where(['shop_id'=>$val['id'],'review'=>''])->get('shop_review')->result_array();
                                   $get_review = $this->db->where(['shop_id'=>$val['id']])->get('shop_review')->result_array();
                                   $review_count = $this->db->where(['shop_id'=>$val['id']])->get('shop_review')->num_rows();
                                   $val['image1']=SITE_URL.'uploads/images/'.$val['image1'];
                                   $val['image2']=SITE_URL.'uploads/images/'.$val['image2'];
                                   $val['image3']=SITE_URL.'uploads/images/'.$val['image3'];
                                   $val['image4']=SITE_URL.'uploads/images/'.$val['image4'];
                                   
                                }
                                
                                $reviews = array();
                                foreach($get_review as $rev)
        {
                                  
                                  if($rev['review']!=''){
                                    $user_id = $rev['user_id'];
                                    $users = $this->webservice_model->get_where('users',['id'=>$user_id]);
                                    $reviews[] = ['username'=>$users[0]['username'],'review'=>$rev['review']];
                                  }
                                }
        
                                $rating = ($get[0]['rating']=='') ?  0 : $get[0]['rating'];   
                                $val['review_count'] = $review_count;
                                $val['rating'] = $rating;
                                $val['review'] = $reviews;
                                $val['distance'] = number_format($distance,2);
                                $val['image']=SITE_URL.'uploads/images/'.$val['image'];  

                                if($nearby=='filter' && $distance<=5){
                                  $data[] = $val;
                                }else if($review=='filter'){
                                  $data[] = $val;
                                }

        
        }

                                if(!isset($data)){
                             $ressult['result']='Data Not Found';
                             $ressult['message']='unsuccessful';
                             $ressult['status']='0';
                             $json = $ressult;
                 header('Content-type: application/json');
                 echo json_encode($json); die;
                         
                                }


                                if($review=='filter'){

                                  $dis = array();
                      foreach ($data as $key => $row)
                      {
                   $dis[$key] = $row['review_count'];
                      }
                      array_multisort($dis, SORT_DESC, $data);                                  
                      
                                }else{

                                  $dis = array();
                      foreach ($data as $key => $row)
                      {
                   $dis[$key] = $row['distance'];
                      }
                      array_multisort($dis, SORT_ASC, $data);

                                }



                          $ressult['result']=$data;
                          $ressult['message']='successful';
                          $ressult['status']='1';
                          $json = $ressult;
      }
        else
      {
                          $ressult['result']='Data Not Found';
                          $ressult['message']='unsuccessful';
                          $ressult['status']='0';
                          $json = $ressult;                              
        
      }

        
                     
      header('Content-type: application/json');
      echo json_encode($json);
    }


                /************* get_shop_item *************/
    public

    function get_shop_item($price)
    {
                  $list = $this->webservice_model->get_where('shop_sub_cat',"price <= $price");
                        //echo $this->db->last_query(); die;

      //print_r($lis);

      if ($list)
      {
        foreach($list as $val)
        {
                                
                                $get_data = $this->db->where('item_id',$val['id'])->get('shop_color')->result_array();
                                $val['cours'] = $get_data;
                                $get_data = $this->db->where('item_id',$val['id'])->get('shop_size')->result_array();
                                $val['size'] = $get_data;
                          $val['image']=SITE_URL.'uploads/images/'.$val['image'];
                          $val['image1']=SITE_URL.'uploads/images/'.$val['image1'];
                          $val['image2']=SITE_URL.'uploads/images/'.$val['image2'];
                          $val['image3']=SITE_URL.'uploads/images/'.$val['image3'];
                          $val['image4']=SITE_URL.'uploads/images/'.$val['image4'];
                                           
                          $data[] = $val;
        
        }

                          $ressult['result']=$data;
                          $ressult['message']='successful';
                          $ressult['status']='1';
                          $json = $ressult;
      }
        else
      {
                          $ressult['result']='Data Not Found';
                          $ressult['message']='unsuccessful';
                          $ressult['status']='0';
                          $json = $ressult;                              
        
      }

        
                     
      header('Content-type: application/json');
      echo json_encode($json);
    }



                /************* get_restaurant_item *************/
    public

    function get_restaurant_item()
    {
       $list = $this->webservice_model->get_where('restaurant_sub_cat',"price <= $price");

      //print_r($lis);

      if ($list)
      {
        foreach($list as $val)
        {
                                
                                
                          $val['image']=SITE_URL.'uploads/images/'.$val['image'];            
                          $data[] = $val;
        
        }

                          $ressult['result']=$data;
                          $ressult['message']='successful';
                          $ressult['status']='1';
                          $json = $ressult;
      }
        else
      {
                          $ressult['result']='Data Not Found';
                          $ressult['message']='unsuccessful';
                          $ressult['status']='0';
                          $json = $ressult;                              
        
      }

        
                     
      header('Content-type: application/json');
      echo json_encode($json);
    }

                /************* delete_cart_item *************/
    public

    function delete_cart_item()
    {
                  $id = $this->input->get_post('cart_id');
                  $list = $this->webservice_model->get_where('add_to_cart',['id'=>$id]);

      if ($list)
      {
        $this->webservice_model->delete_data('add_to_cart',['id'=>$id]);

                          $ressult['result']="Item delete successfull";
                          $ressult['message']='successful';
                          $ressult['status']='1';
                          $json = $ressult;
      }
        else
      {
                          $ressult['result']='Data Not Found';
                          $ressult['message']='unsuccessful';
                          $ressult['status']='0';
                          $json = $ressult;                              
        
      }

        
                     
      header('Content-type: application/json');
      echo json_encode($json);
    }

                /*************  place_order *************/
    public

    function place_order()
    {                     
                          
      $arr_data = array(
        'user_id' => $this->input->get_post('user_id'),
        'full_name' => $this->input->get_post('full_name'), 
        'address' => $this->input->get_post('address'), 
        'mobile' => $this->input->get_post('mobile'),
        'country' => $this->input->get_post('country'), 
        'state' => $this->input->get_post('state'), 
        'city' => $this->input->get_post('city'),
        'zip_code' => $this->input->get_post('zip_code')                                     
      );

                        $where = ['user_id'=>$arr_data['user_id']];
                        
                        $fetch = $this->webservice_model->get_where('user_address',$where);

                        if($fetch){
                         
                          $this->webservice_model->update_data('user_address',$arr_data,$where);
                          $address_id = $fetch[0]['id'];

                        }else{

                          $address_id = $this->webservice_model->insert_data('user_address', $arr_data);

                        }

       $order_id = $this->webservice_model->generateRandomString(8);
       $delivery_date = date('Y-m-d', strtotime("+3 days"));

       $arr_ord = array(
        'user_id' => $this->input->get_post('user_id'),
        'cart_id' => $this->input->get_post('cart_id'), 
        'address_id' => $address_id,  
        'order_id' => $order_id,  
        'delivery_date' => $delivery_date                                
      );

       $type = "COD";
       $cart_ids = explode(",",$arr_ord['cart_id']);
       foreach($cart_ids as $ids){

          $arr_ord['cart_id'] = $ids;

          $order = $this->webservice_model->insert_data('place_order', $arr_ord);
                           
          $cart = $this->webservice_model->get_where('add_to_cart',['id'=>$ids]);
          if($cart[0]['type']=='shop'){
              $get = $this->webservice_model->get_where('shop_sub_cat',['id'=>$cart[0]['item_id']]);
          }else{
              $get = $this->webservice_model->get_where('restaurant_sub_cat',['id'=>$cart[0]['item_id']]);
          }

          $admin = $this->webservice_model->get_where('admin',['id'=>$get[0]['user_id']]);
          $cntry = $this->webservice_model->get_where('country',['currency'=>$get[0]['currancy']]);
          
          if($cntry[0]['country']!=$arr_data['country']){
            $type = "PAYBLE";
          }


        /* start code for send email */

        $to = $admin[0]['email'];
        $subject = "Your product is sell out";
        $body = "<div style='max-width: 600px; width: 100%; margin-left: auto; margin-right: auto;'>
        <header style='color: #fff; width: 100%;'>
           <img alt='' src='".SITE_URL."uploads/images/logo.png' width ='120' height='120'/>
        </header>
        
        <div style='margin-top: 10px; padding-right: 10px; 
      padding-left: 125px;
      padding-bottom: 20px;'>
          <hr>
          <h3 style='color: #232F3F;'>Hello ".$admin[0]['name'].",</h3>
          <p>You product of ".$get[0]['name']." is purchase by user ".$arr_data['full_name'].".</p>
          <p>Its mobile number is <span style='background:#2196F3;color:white;padding:0px 5px'>".$arr_data['mobile']."</span></p>
          <hr>
          
            <p>Warm Regards<br>SNIFF<br>Support Team</p>
            
          </div>
        </div>

    </div>";

        $headers = "From: info@technorizen.com" . "\r\n";
        $headers.= "MIME-Version: 1.0" . "\r\n";
        $headers.= "Content-type:text/html;charset=UTF-8" . "\r\n";

        mail($to, $subject, $body, $headers);
        /* end code for send email */



                             
      }

            
      if ($order != "") {

                          $single_data = ['order_id' => $order_id];

                          $fetch_order = $this->webservice_model->get_where('place_order',$single_data); 
                         
                          $ressult['result']=$fetch_order;
                          $ressult['pay_method']=$type;
                          $ressult['message']='successful';
                          $ressult['status']='1';
                          $json = $ressult;                      
                         

      }
      else {
                          $ressult['result']='Data Not Found';
                          $ressult['message']='unsuccessful';
                          $ressult['status']='0';
                          $json = $ressult;
      }

      header('Content-type: application/json');
      echo json_encode($json);
    }

                /*************  payment *************/
    public

    function payment()
    {                     
                          
      $arr_data = array(
        'user_id' => $this->input->get_post('user_id'),
        'order_id' => $this->input->get_post('order_id'), 
        'payment_method' => $this->input->get_post('payment_method'), 
        'total_amount' => $this->input->get_post('total_amount')                           
      );

                        

      $pay = $this->webservice_model->insert_data('payment', $arr_data);

                        $this->webservice_model->update_data('place_order',['status'=>'Complete'],['order_id'=>$arr_data['order_id']]);
                  
                        $get_order = $this->webservice_model->get_where('place_order',['order_id'=>$arr_data['order_id']]);
                        
                        $cart_ids = explode(",",$get_order[0]['cart_id']);
                        foreach($cart_ids as $ids){
                           
                           $this->webservice_model->update_data('add_to_cart',['status'=>'Complete'],['id'=>$ids]);
                        }
      
      if ($pay != "") {

        $single_data = ['id' => $pay];

                          $fetch_order = $this->webservice_model->get_where('payment',$single_data); 
                         
                          $ressult['result']=$fetch_order[0];
                          $ressult['message']='successful';
                          $ressult['status']='1';
                          $json = $ressult;
      }
      else {
                          $ressult['result']='Data Not Found';
                          $ressult['message']='unsuccessful';
                          $ressult['status']='0';
                          $json = $ressult;
      }

      header('Content-type: application/json');
      echo json_encode($json);
    }

                /************* get_order *************/
    public

    function get_order()
    {
 
                        $user_id = $this->input->get_post('user_id');
                        $list = $this->webservice_model->get_where('place_order',['user_id' => $user_id]);

      //print_r($lis);

      if ($list)
      {
        foreach($list as $val)
        {
                                
                                $item_data = $item = [];
                                $cart_ids = explode(",",$val['cart_id']);
                                foreach($cart_ids as $ids){
 
                                  $fetch = $this->webservice_model->get_where('add_to_cart',['id'=>$ids]);
                                  
                                  if($fetch[0]['type']=='shop'){
                                     $get = $this->webservice_model->get_where('shop_sub_cat',['id'=>$fetch[0]['item_id']]);
                                  }else{
                                     $get = $this->webservice_model->get_where('restaurant_sub_cat',['id'=>$fetch[0]['item_id']]);
                                  }
                              
                                  $item['id'] = $ids;
                                  $item['item_name'] = $get[0]['name'];
                                  $item['image'] = SITE_URL.'uploads/images/'.$get[0]['image'];            
                                  $item_data[] = $item;


                                }
                                
                          $val['item_data'] = $item_data;   
                          $data[] = $val;
        
        }

                          $ressult['result']=$data;
                          $ressult['message']='successful';
                          $ressult['status']='1';
                          $json = $ressult;
      }
        else
      {
                          $ressult['result']='Data Not Found';
                          $ressult['message']='unsuccessful';
                          $ressult['status']='0';
                          $json = $ressult;                              
        
      }

        
                     
      header('Content-type: application/json');
      echo json_encode($json);
    }
 

                /************* get_search_list *************/
    public

    function get_search_list()
    {
                  $type = $this->input->get_post('type'); 
                  $lat = $this->input->get_post('lat');
                  $lon = $this->input->get_post('lon');
                  $search = $this->input->get_post('search');

                        $data = array();
                        if($type=='restaurant'){
                             $list = $this->webservice_model->get_where('restaurant',"name LIKE '%$search%'");
                             $return = $this->get_restaurant_search($search);
                             if($return){
                               $data = $return;
                             }
                        }else{
                             $list = $this->webservice_model->get_where('shop',"name LIKE '%$search%'");
                             $return = $this->get_shop_search($search);
                             if($return){
                               $data = $return;
                             }
                        }
  //print_r($data); die;
      if ($list)
      {
        foreach($list as $val)
        {
                                
                                $distance = $this->webservice_model->distance($lat, $lon, $val['lat'], $val['lon'], $miles = false);
                                $videos = $reviews = array();
                                if($type=='restaurant'){
                                    $get = $this->db->select_avg("rating", "rating")->where(['restaurant_id'=>$val['id']])->get('restaurant_review')->result_array();
                                    $get_review = $this->db->where(['restaurant_id'=>$val['id']])->get('restaurant_review')->result_array();
                                }else{
                                   $get = $this->db->select_avg("rating", "rating")->where(['shop_id'=>$val['id']])->get('shop_review')->result_array();
                                   $get_review = $this->db->where(['shop_id'=>$val['id']])->get('shop_review')->result_array();
                                   
                                   $get_video = $this->db->where(['item_id'=>$val['id']])->get('shop_video')->result_array();                                
                                   
                                   foreach($get_video as $vid)
                                   {
                                       $vid['video']=SITE_URL.'uploads/images/'.$vid['video'];
                                       $videos[] = $vid;                     
                                   }

                                   $val['image1']=SITE_URL.'uploads/images/'.$val['image1'];
                                   $val['image2']=SITE_URL.'uploads/images/'.$val['image2'];
                                   $val['image3']=SITE_URL.'uploads/images/'.$val['image3'];
                                   $val['image4']=SITE_URL.'uploads/images/'.$val['image4'];
                                                                      
                                   
                                }
                                
                                $val['discount_img']=SITE_URL.'uploads/images/'.$val['discount_img'];
                                
                                foreach($get_review as $rev)
                                {
                                  
                                  if($rev['review']!=''){
                                    $user_id = $rev['user_id'];
                                    $users = $this->webservice_model->get_where('users',['id'=>$user_id]);
                                    $reviews[] = ['username'=>$users[0]['username'],'review'=>$rev['review']];
                                  }
                                }
        
                                $rating = ($get[0]['rating']=='') ?  0 : $get[0]['rating'];  
 
                                $val['videos'] = $videos;
                                $val['rating'] = $rating;
                                $val['review'] = $reviews;
                                $val['distance'] = number_format($distance,2);
                                $val['image']=SITE_URL.'uploads/images/'.$val['image'];            
                                $data[] = $val;
        
          }
       }

       if($data){

                          
                          $arr = [];
                          foreach($data as $items){
                            if(!in_array($items['id'],$arr)){
                               $array[] = $items;
                               $arr[] = $items['id'];
                            }                            
                          }

                          
                          $ressult['result']=$array;
                          $ressult['message']='successful';
                          $ressult['status']='1';
                          $json = $ressult;
      }
      else
      {
                          $ressult['result']='Data Not Found';
                          $ressult['message']='unsuccessful';
                          $ressult['status']='0';
                          $json = $ressult;                              
        
      }

        
                     
      header('Content-type: application/json');
      echo json_encode($json);
    }


    /************* get_shop_search *************/
    public

    function get_shop_search($search)
    {
                  $list = $this->webservice_model->get_where('shop_sub_cat',"name LIKE '%$search%' GROUP BY shop_id");

                  //print_r($lis);

                  if ($list)
                  {
                                $ids = "";
                                foreach($list as $vals){
                                  if($ids==""){
                                     $ids = $vals['shop_id'];
                                  }else{
                                     $ids = $ids.",".$vals['shop_id'];
                                   }
                                }
                                $shopList = $this->webservice_model->get_where('shop',"id IN($ids)");

                                foreach($shopList as $val){
                                
                                     $videos = $reviews = array();
                                  
                                     $get = $this->db->select_avg("rating", "rating")->where(['shop_id'=>$val['id']])->get('shop_review')->result_array();
                                     $get_review = $this->db->where(['shop_id'=>$val['id']])->get('shop_review')->result_array();
                                     
                                     $get_video = $this->db->where(['item_id'=>$val['id']])->get('shop_video')->result_array();                                
                                     
                                     foreach($get_video as $vid)
                                     {
                                         $vid['video']=SITE_URL.'uploads/images/'.$vid['video'];
                                         $videos[] = $vid;                     
                                     }

                                     $val['image1']=SITE_URL.'uploads/images/'.$val['image1'];
                                     $val['image2']=SITE_URL.'uploads/images/'.$val['image2'];
                                     $val['image3']=SITE_URL.'uploads/images/'.$val['image3'];
                                     $val['image4']=SITE_URL.'uploads/images/'.$val['image4'];
                                     $val['discount_img']=SITE_URL.'uploads/images/'.$val['discount_img'];                                   
                                     
                                                                  
                                  
                                    foreach($get_review as $rev){
                                      
                                        if($rev['review']!=''){
                                          $user_id = $rev['user_id'];
                                          $users = $this->webservice_model->get_where('users',['id'=>$user_id]);
                                          $reviews[] = ['username'=>$users[0]['username'],'review'=>$rev['review']];
                                        }
                                    }
          
                                    $rating = ($get[0]['rating']=='') ?  0 : $get[0]['rating'];  
     
                                    $val['videos'] = $videos;
                                    $val['rating'] = $rating;
                                    $val['review'] = $reviews;
                                    $val['distance'] = '';
                                    $val['image']=SITE_URL.'uploads/images/'.$val['image'];            
                                    $data[] = $val;
        
                              }                               


                

                                return $data;
                                

                  }else{ return false; }
              
                     
      
    }

 

    /************* get_restaurant_search *************/
    public

    function get_restaurant_search($search)
    {
                  $list = $this->webservice_model->get_where('restaurant_sub_cat',"name LIKE '%$search%' GROUP BY restaurant_id");

                  //print_r($lis);

                  if ($list)
                  {
                                $ids = "";
                                foreach($list as $vals){
                                  if($ids==""){
                                     $ids = $vals['restaurant_id'];
                                  }else{
                                     $ids = $ids.",".$vals['restaurant_id'];
                                   }
                                }
                                $restaurantList = $this->webservice_model->get_where('restaurant',"id IN($ids)");

                                foreach($restaurantList as $val){
                                
                                     $reviews = array();
                                  
                                     $get = $this->db->select_avg("rating", "rating")->where(['restaurant_id'=>$val['id']])->get('restaurant_review')->result_array();
                                     $get_review = $this->db->where(['restaurant_id'=>$val['id']])->get('restaurant_review')->result_array();                     
                                                                  
                                    $val['discount_img']=SITE_URL.'uploads/images/'.$val['discount_img'];

                                    foreach($get_review as $rev){
                                      
                                        if($rev['review']!=''){
                                          $user_id = $rev['user_id'];
                                          $users = $this->webservice_model->get_where('users',['id'=>$user_id]);
                                          $reviews[] = ['username'=>$users[0]['username'],'review'=>$rev['review']];
                                        }
                                    }
          
                                    $rating = ($get[0]['rating']=='') ?  0 : $get[0]['rating'];       
                                    
                                    $val['rating'] = $rating;
                                    $val['review'] = $reviews;
                                    $val['distance'] = '';
                                    $val['image']=SITE_URL.'uploads/images/'.$val['image'];            
                                    $data[] = $val;
        
                              }                               


                

                                return $data;
                                

                  }else{ return false; }
              
                     
      
    }


    /*************  get_my_order *************/
    public

    function get_my_order()
    {                     
                          
      $user_id = $this->input->get_post('user_id');
      $where = "(user_id = '$user_id') AND (status = 'Complete' OR status = 'Waiting' OR status = 'Way') ";
                        
      $fetch = $this->webservice_model->get_where('place_order',$where);

      
            
      if ($fetch) {

                          foreach($fetch as $val)
                          {
                                   
                            $cart = $this->webservice_model->get_where('add_to_cart',['id'=>$val['cart_id']]);

                            if($cart[0]['type']=='shop'){
                                $get = $this->webservice_model->get_where('shop_sub_cat',['id'=>$cart[0]['item_id']]);
                                $get[0]['image1']=SITE_URL.'uploads/images/'.$get[0]['image1'];
                                $get[0]['image2']=SITE_URL.'uploads/images/'.$get[0]['image2'];
                                $get[0]['image3']=SITE_URL.'uploads/images/'.$get[0]['image3'];
                                $get[0]['image4']=SITE_URL.'uploads/images/'.$get[0]['image4'];

                                $get_data = $this->db->where('item_id',$cart[0]['item_id'])->get('shop_color')->result_array();
                                $val['cours'] = $get_data;
                                $get_data = $this->db->where('item_id',$cart[0]['item_id'])->get('shop_size')->result_array();
                                $val['size'] = $get_data;

                            }else{
                                $get = $this->webservice_model->get_where('restaurant_sub_cat',['id'=>$cart[0]['item_id']]);
                            }

                            $get[0]['image']=SITE_URL.'uploads/images/'.$get[0]['image'];
                                
                            $total[] = ($get[0]['price']*$cart[0]['quantity']);                            
                            $val['product']=$get[0];                           
                            $val['quantity']=$cart[0]['quantity'];                                        
                            $data[] = $val;
        
                          }
                         
                          $ressult['total'] = array_sum($total);
                          $ressult['result']=$data;
                          $ressult['message']='successful';
                          $ressult['status']='1';
                          $json = $ressult;                      
                         

      }
      else {
                          $ressult['result']='Data Not Found';
                          $ressult['message']='unsuccessful';
                          $ressult['status']='0';
                          $json = $ressult;
      }

      header('Content-type: application/json');
      echo json_encode($json);

    }


    /*************  contact_info *************/
    public

    function contact_info()
    {                     
                          
      $arr_data = array(
        'email' => $this->input->get_post('email'),
        'message' => $this->input->get_post('message'), 
        'phone' => $this->input->get_post('phone')                           
      );

                        

      $fetch = $this->webservice_model->insert_data('contact_info', $arr_data);

                         
                        
      
      if ($fetch != "") {

        $single_data = ['id' => $fetch];

                          $fetch_order = $this->webservice_model->get_where('contact_info',$single_data); 
                         
                          $ressult['result']=$fetch_order[0];
                          $ressult['message']='successful';
                          $ressult['status']='1';
                          $json = $ressult;
      }
      else {
                          $ressult['result']='Data Not Found';
                          $ressult['message']='unsuccessful';
                          $ressult['status']='0';
                          $json = $ressult;
      }

      header('Content-type: application/json');
      echo json_encode($json);
    }


   

    /************* get_offer_list *************/
    public

    function get_offer_list()
    {
                  $list = $this->webservice_model->get_where('shop_sub_cat',['offer'=>'YES']);

                 
                  if ($list)
                  {                              
                               
                                foreach($list as $val){
                                
                                     $videos = array();                                  
                                    
                                     $get_video = $this->db->where(['item_id'=>$val['id']])->get('shop_video')->result_array();                                
                                     
                                     foreach($get_video as $vid)
                                     {
                                         $vid['video']=SITE_URL.'uploads/images/'.$vid['video'];
                                         $videos[] = $vid;                     
                                     }

                                     $val['image1']=SITE_URL.'uploads/images/'.$val['image1'];
                                     $val['image2']=SITE_URL.'uploads/images/'.$val['image2'];
                                     $val['image3']=SITE_URL.'uploads/images/'.$val['image3'];
                                     $val['image4']=SITE_URL.'uploads/images/'.$val['image4'];
                                     
     
                                    $val['videos'] = $videos;
                                    $val['distance'] = '';
                                    $val['image']=SITE_URL.'uploads/images/'.$val['image'];            
                                    $data[] = $val;
        
                               }                               


                

                          $ressult['result']=$data;
                          $ressult['message']='successful';
                          $ressult['status']='1';
                          $json = $ressult;  
                                

                  }else{ 
                      
                          $ressult['result']='Data Not Found';
                          $ressult['message']='unsuccessful';
                          $ressult['status']='0';
                          $json = $ressult;
 
                  }

                  header('Content-type: application/json');
                  echo json_encode($json);
              
                     
      
    }






    function get_token_key() {

   $uri = "https://api.stripe.com\Stripe\Charge::create(array(
  'amount' => 2000,
  'currency' => 'usd',
  'source' => 'tok_189gKA2eZvKYlo2CfUDZuPeT', 
  'metadata' => array('order_id' => '6735')))";

    
    
      
	$curl = curl_init();

	curl_setopt_array($curl, array(
	  CURLOPT_URL => $uri
	));

	$response = curl_exec($curl);
	$err = curl_error($curl);

	curl_close($curl);

	if ($err) {
	  echo "cURL Error #:" . $err;
	} else {
	  echo $response;
	}


  }





    

    


    // end class
    }

?>
