<!DOCTYPE html>
<html>
<?php include 'include/head.php'; ?>
<body class="hold-transition skin-blue sidebar-mini" id="home">
<div class="wrapper">
<?php 
$res = $this->db->query("SELECT count(id) AS id,date_time FROM `users`  GROUP BY DATE_FORMAT(date_time, '%Y-%m')")->result_array();

foreach($res AS $val){
 
 $date = date('Y-m', strtotime($val['date_time'])); 
 $users[] = ['y'=>$date, 'item1'=>$val['id']];

}

$users = json_encode($users);

$res = $this->db->query("SELECT count(id) AS id,date_time FROM `users` GROUP BY DATE_FORMAT(date_time, '%Y-%m')")->result_array();

foreach($res AS $val){
 
 $date = date('Y-m', strtotime($val['date_time'])); 
 $drivers[] = ['y'=>$date, 'item1'=>$val['id']];

}

$drivers = json_encode($drivers);

 include 'include/header.php'; ?>
  
  <link rel="stylesheet" href="<?=base_url('assets/admin/dist/css/styles.css');?>"> 

<style>

.dashboard-bg{
border:1px solid #ccc;
margin:20px 0;
}
.main-heading20 h1{
    font-size: 19px;
    margin: 0;
    color: #fff;
    font-weight: 600;
}

.main-heading20{
 background-color: #31bffc;
    padding: 9px;
}
.boxg20{
    background-color: #00c0ef;
    padding: 15px;
    margin: 11px 0px;
    border-radius: 4px;
   box-shadow: 2px 4px 9px #0000002b;
}
.new-yellow{
background-color:#53E082;
}
.new-yellow-1{
background-color:#e04c4b;
}

.new-yellow-2{
background-color:#7d6aa0;
}
.new-yellow-3{
background-color:#d81b60;
}
.new-yellow-4{
background-color:#abd037;
}

.boxg20 svg{
      color: rgba(255, 255, 255, 0.25);
    font-size: 78px;
}
.boxg20 p{
        display: inline-block;
    float: left;
    color: #fff;
    font-size: 32px;
    font-weight: 600;
}
.boxg20 p span{
      font-size: 17px;
    font-weight: 400;
    margin-top: 0px;
    display: block;
    text-align: right;
    margin-right: 8px;
}
.highcharts-title{
display:none;
}
.highcharts-button-symbol , .highcharts-credits{
display:none;
}
.chat-tile{
border:1px solid #ccc;
margin-bottom: 11px;
}
.chat-tile h1{
    font-size: 19px;
    margin: 0;
    color: #fff;
    background-color: #fbc40d;
    font-weight: 600;
    padding: 6px;
}

</style>


  <div class="content-wrapper">
    <!-- Main content -->
    <section class="content">
     <div class="box box-info">
            <div class="box-header " >

              <!-- tools box -->
              <div class="pull-right box-tools">
                <button type="button" class="btn clg btnclose" data-widget="remove" data-toggle="tooltip" title="" data-original-title="Remove">
                  <img src="<?=base_url();?>uploads/images/close.png" alt="" class="mt-2 "> Dismiss</button>
              </div>
              <!-- /. tools -->
            </div>


            <div class="box-body cdG">

              <div class="col-sm-12">
                 
                   <a href="<?=base_url('admin/view_page/addAdmin');?>"><button type="button" class=" btn  btn-infoicutom btn-lg cw">Create Sub Admin</button></a>
                 

              </div><!-- /.col-sm-12 -->
              
              <div class="col-sm-6 ">
                <h1 >Welcome to  <?= $this->db->get('setting')->row()->name;?></h1>
                <!--<p class="fontOSL fs22">We’ve assembled some links to get you started:</p>
                <h3 class="fw600">Get Started</h3>-->
              </div> <!-- /.col-sm-6 -->

              <div class="col-sm-6">
                 
                <?php if($admin->type=='ADMIN'){ ?>

                 <div class="col-sm-6" onclick="location.href='<?=base_url('admin/view_page/userList');?>'" style="cursor:pointer">
                   <div class="panel panel-blue panel-widget ">
                      <div class="row no-padding">
                         <div class="col-sm-3 widget-left">
                            <i class="fa fa-user-plus" aria-hidden="true" style="font-size:3em"></i>
                         </div>
                         <div class="col-sm-9 widget-right">
                            <div class="large">
                              <?= $this->db->where("MONTH( date_time ) = MONTH( CURRENT_DATE( ) )")->get('users')->num_rows();?>
                            </div>
                            <div class="text-muted">New Users</div>
                         </div>
                      </div>
                   </div>
                </div>

                <div class="col-sm-6" onclick="location.href='<?=base_url('admin/view_page/userList');?>'" style="cursor:pointer">
                   <div class="panel panel-blue panel-widget ">
                      <div class="row no-padding">
                         <div class="col-sm-3 widget-left">
                            <i class="fa fa-user" aria-hidden="true" style="font-size:3em"></i>
                         </div>
                         <div class="col-sm-9 widget-right">
                            <div class="large">
                              <?= $this->db->get('users')->num_rows();?>
                            </div>
                            <div class="text-muted">All Users</div>
                         </div>
                      </div>
                   </div>
                </div>
               <?php } ?>
                             
             
              </div><!-- /.col-sm-6 -->

              

            </div>
            
          </div>



		
		<div class="clearfix">
        <div class="dashboard-new">
		<div class="dashboard-bg">
   <div class="main-heading20">
   <h1>Dashboard</h1>   
   </div>

<div class="new-box">
<div class="clearfix">

<div class="col-md-4">
<div class="boxg20">
<div class="clearfix">
<p>3221<br> <span>User</span></p>
<i class="user_icon_font fa fa-user-plus pull-right"></i>
</div>
</div>
</div>



<div class="col-md-4">
<div class="boxg20 new-yellow">
<div class="clearfix">
<p>1813<br> <span>Drivers</span></p>
<i class="user_icon_font fa fa-address-card pull-right"></i>
</div>
</div>
</div>

<div class="col-md-4">
<div class="boxg20 new-yellow-1">
<div class="clearfix">
<p>25<br> <span>Coupon Codes</span></p>
<i class="user_icon_font fa fa-ticket pull-right"></i>
</div>
</div>
</div>

<div class="col-md-4">
<div class="boxg20 new-yellow-2">
<div class="clearfix">
<p>923<br> <span>Locations</span></p>
<i class="user_icon_font fa fa-location-arrow pull-right"></i>
</div>
</div>
</div>

<div class="col-md-4">
<div class="boxg20 new-yellow-3">
<div class="clearfix">
<p>$ 28348847<br> <span>Total Earnings</span></p>
<i class="user_icon_font fa fa-money pull-right"></i>
</div>
</div>
</div>


<div class="col-md-4">
<div class="boxg20 new-yellow-4">
<div class="clearfix">
<p>3221<br> <span>User</span></p>
<i class="user_icon_font fa fa-user-plus pull-right"></i>
</div>
</div>
</div>



</div>
</div>

    </div>
		</div>		
		</div>
		
		
		<div class="clearfix">
        <div class="dashboard-new">
		<div class="dashboard-bg">
   <div class="main-heading20">
   <h1>Dashboard</h1>   
   </div>

<div class="new-box">
<div class="clearfix">

<div class="col-md-4">
<div class="boxg20">
<div class="clearfix">
<p>3221<br> <span>User</span></p>
<i class="user_icon_font fa fa-user-plus pull-right"></i>
</div>
</div>
</div>



<div class="col-md-4">
<div class="boxg20 new-yellow">
<div class="clearfix">
<p>1813<br> <span>Drivers</span></p>
<i class="user_icon_font fa fa-address-card pull-right"></i>
</div>
</div>
</div>

<div class="col-md-4">
<div class="boxg20 new-yellow-1">
<div class="clearfix">
<p>25<br> <span>Coupon Codes</span></p>
<i class="user_icon_font fa fa-ticket pull-right"></i>
</div>
</div>
</div>

<div class="col-md-4">
<div class="boxg20 new-yellow-2">
<div class="clearfix">
<p>923<br> <span>Locations</span></p>
<i class="user_icon_font fa fa-location-arrow pull-right"></i>
</div>
</div>
</div>

<div class="col-md-4">
<div class="boxg20 new-yellow-3">
<div class="clearfix">
<p>$ 28348847<br> <span>Total Earnings</span></p>
<i class="user_icon_font fa fa-money pull-right"></i>
</div>
</div>
</div>


<div class="col-md-4">
<div class="boxg20 new-yellow-4">
<div class="clearfix">
<p>3221<br> <span>User</span></p>
<i class="user_icon_font fa fa-user-plus pull-right"></i>
</div>
</div>
</div>



</div>
</div>

    </div>
		</div>		
		</div>
		
		
		

      <div class="row">
         <?php /* <div class="col-sm-6">
          <div class="box box-info">
            <div class="box-header with-border">
              <h3 class="box-title">Activity</h3>
              
              <div class="box-tools pull-right">
                <button type="button" class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i> </button>               
              </div>
            </div>
            <!-- /.box-header -->
            <div class="box-body">
              <div class="table-responsive">
              
                <table class="table no-margin">
                 
                  <tbody>
                  <tr>  
                    <td style="border-top: 0px;"> <p class="box-title">Publishing Soon</p> </td>
                  </tr>                  
                  <tr class="clg">
                    <td>Today, 15:30</td>
                    <td><a>De kracht van sociale media</a></td>
                  </tr>
                  <tr class="clg">
                    <td>Tomorrow, 15:30</td>
                    <td><a>De kracht van sociale media</a></td>
                  </tr>
                  <tr>  <td> <p class="box-title">Recently Published</p> </td></tr>
                    <tr class="clg">
                    <td>Today, 15:30</td>
                    <td><a>De kracht van sociale media</a></td>
                  </tr>
                  <tr class="clg">
                    <td>Tomorrow, 15:30</td>
                    <td><a>De kracht van sociale media</a></td>
                  </tr>
                  <tr class="clg">
                    <td>Tomorrow, 15:30</td>
                    <td><a>De kracht van sociale media</a></td>
                  </tr>

                  </tbody>


                </table>
              </div>
              <!-- /.table-responsive -->
            </div>
            <!-- /.box-body -->
        
            <!-- /.box-footer -->
          </div>
          </div> */?>

       
          <!-- /.box -->

        <!-- /.col (RIGHT) -->
      </div>
      <!-- /.row -->

    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->



  <!-- /.control-sidebar -->
  <!-- Add the sidebar's background. This div must be placed
       immediately after the control sidebar -->
  <div class="control-sidebar-bg"></div>
</div>
<!-- ./wrapper -->

<?php include 'include/script.php' ?>
<script src="<?=base_url('assets/admin');?>/plugins/morris/morris.min.js"></script>

<script>
  $(function () {
    "use strict";

    // AREA CHART
    var area = new Morris.Area({
      element: 'user-chart',
      resize: true,
      data: <?=$users;?>,
      xkey: 'y',
      ykeys: ['item1'],
      labels: ['Users'],
      lineColors: ['#a0d0e0'],
      hideHover: 'auto'
    });

 
  });
</script>

<script>
  $(function () {
    "use strict";

    // AREA CHART
    var area = new Morris.Area({
      element: 'driver-chart',
      resize: true,
      data: <?=$drivers;?>,
      xkey: 'y',
      ykeys: ['item1'],
      labels: ['Drivers'],
      lineColors: ['#a0d0e0'],
      hideHover: 'auto'
    });

 
  });
</script>

</body>
</html>
